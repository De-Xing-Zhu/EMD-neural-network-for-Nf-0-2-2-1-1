#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
plot_nf0.py -- push the trained A(z), f(z) through the EMD forward model and
compare the resulting EOS with the pure-gauge lattice table.

Reads   results/Nf0_A_f.npz            (from train_nf0.py)
        data/pure_gauge_Borsanyi2012.csv  (full lattice table, 48 points)
Writes  figures/eos_compare.png        I/T^4, e/T^4, s/T^3, p/T^4: EMD vs lattice
        figures/loss_history.png       raw + EMA loss, training points marked
        figures/A_f_background.png     the trained A(z), f(z), G
and prints a residual table (mean/std/rms/max |dev| in %).

The pressure reference is the lattice value at the first training point
(T = 0.2703 GeV); p(T) = p_ref + int s dT, e/T^4 = s/T^3 - p/T^4,
I/T^4 = s/T^3 - 4 p/T^4.
"""

import os
import sys
import json

import numpy as np
import torch

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from emd_free import load_trained, emd_mu0_curve   # noqa: E402

RESULTS = os.path.join(BASE, "results")
DATA = os.path.join(BASE, "data")
FIGS = os.path.join(BASE, "figures")

TRAIN_CSV = os.path.join(DATA, "Nf0_train.csv")
MODEL_NPZ = os.path.join(RESULTS, "Nf0_A_f.npz")
HIST_JSON = os.path.join(RESULTS, "Nf0_history.json")


# ------------------------------------------------------------------ lattice data
def load_full_table():
    """Full pure-gauge table (48 rows)."""
    d = np.genfromtxt(os.path.join(DATA, "pure_gauge_Borsanyi2012.csv"),
                      delimiter=",", names=True)
    return d


def load_train_points():
    T, y, s = [], [], []
    with open(TRAIN_CSV) as f:
        for line in f:
            if line.startswith("#") or not line.strip():
                continue
            t, v, sg = line.split(",")[:3]
            T.append(float(t)); y.append(float(v)); s.append(float(sg))
    return np.array(T), np.array(y), np.array(s)


# ------------------------------------------------------------------------ EOS
def eos_from_s(T, s_over_T3, T_ref, p_ref_over_T4):
    """p(T) = p(T_ref) + int s dT; e/T^4 = s/T^3 - p/T^4; I/T^4 = s/T^3 - 4p/T^4."""
    m = T >= T_ref
    T, s = T[m], s_over_T3[m]
    p = np.empty_like(T)
    p[0] = p_ref_over_T4 * T_ref ** 4
    if len(T) > 1:
        integ = np.concatenate([[0.0], np.cumsum(
            0.5 * (s[1:] * T[1:] ** 3 + s[:-1] * T[:-1] ** 3) * np.diff(T))])
        p = p[0] + integ
    pT4 = p / T ** 4
    return dict(T=T, p_over_T4=pT4, s_over_T3=s,
                e_over_T4=s - pT4, I_over_T4=s - 4 * pT4)


def main():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    os.makedirs(FIGS, exist_ok=True)

    model = load_trained(MODEL_NPZ)
    d = np.load(MODEL_NPZ, allow_pickle=True)
    G = float(d["G"])

    Tm, sm, _ = emd_mu0_curve(model)
    Ttr, ytr, _ = load_train_points()
    T_ref = float(Ttr[0])                       # anchor p at the first point
    tab = load_full_table()
    i_ref = int(np.argmin(np.abs(tab["T"] - T_ref)))
    p_ref = float(tab["p_over_T4"][i_ref])

    eos = eos_from_s(Tm, sm, T_ref, p_ref)
    T_hi = float(Ttr.max())                     # comparison window = training span

    # ------------------------------------------------ residual table (all rows)
    m = (tab["T"] >= T_ref) & (tab["T"] <= T_hi)
    rows = []
    for key, nm in [("I_over_T4", "I/T^4"), ("e_over_T4", "e/T^4"),
                    ("s_over_T3", "s/T^3"), ("p_over_T4", "p/T^4")]:
        pred = np.interp(tab["T"][m], eos["T"], eos[key])
        dev = 100 * (pred / tab[key][m] - 1)
        rows.append((nm, np.nanmean(dev), np.nanstd(dev),
                     np.sqrt(np.nanmean(dev ** 2)), np.nanmax(np.abs(dev))))

    print("model: G = %.4f, black-hole branch T = %.4f .. %.4f GeV"
          % (G, Tm.min(), Tm.max()))
    print("p anchored at T=%.4f GeV (lattice p/T^4=%.4f)" % (T_ref, p_ref))
    print("%-8s %8s %8s %8s %9s" % ("obs", "mean", "std", "rms", "max|dev|"))
    for nm, mu, sd, rms, mx in rows:
        print("  %-8s %7.2f%% %7.2f%% %7.2f%% %8.2f%%" % (nm, mu, sd, rms, mx))

    # ---------------------------------------------------------- figure 1: EOS
    n_plot = 60
    ii = np.arange(int(m.sum()))
    if len(ii) > n_plot:
        ii = np.unique(np.linspace(0, len(ii) - 1, n_plot).astype(int))
    fig, axes = plt.subplots(1, 4, figsize=(20, 4.4))
    for ax, (key, ylab) in zip(axes, [
            ("I_over_T4", r"$(\epsilon-3p)/T^4$"),
            ("e_over_T4", r"$\epsilon/T^4$"),
            ("s_over_T3", r"$s/T^3$"),
            ("p_over_T4", r"$p/T^4$")]):
        dkey = "d" + key
        axes_err = tab[dkey][m][ii] if dkey in tab.dtype.names else None
        ax.errorbar(tab["T"][m][ii], tab[key][m][ii], yerr=axes_err,
                    fmt="s", color="k", ms=4, capsize=2, lw=1,
                    label="LQCD (Borsanyi 2012)")
        mm = (eos["T"] >= T_ref) & (eos["T"] <= T_hi)
        ax.plot(eos["T"][mm], eos[key][mm], "-", color="#d62728", lw=2.5,
                zorder=5, label="EMD from trained $A,f$")
        ax.set_xlabel("T [GeV]"); ax.set_ylabel(ylab); ax.grid(alpha=0.3)
        ax.set_title("Nf=0   %s" % ylab)
    axes[0].legend(fontsize=8)
    fig.suptitle("Nf=0 : EOS from the trained $A(z), f(z)$ vs lattice "
                 "(G=%.3f; p anchored at T=%.3f GeV; T $\\leq$ %.3f GeV)"
                 % (G, T_ref, T_hi), fontsize=12)
    fig.tight_layout(rect=[0, 0, 1, 0.93])
    fig.savefig(os.path.join(FIGS, "eos_compare.png"), dpi=140)
    plt.close(fig)

    # ------------------------------------------------- figure 2: loss history
    if os.path.exists(HIST_JSON):
        h = json.load(open(HIST_JSON))["history"]
        meta = json.load(open(HIST_JSON))["meta"]
        fig, ax = plt.subplots(figsize=(8, 4.4))
        ax.semilogy([r["epoch"] for r in h], [r["total_raw"] for r in h],
                    lw=0.8, alpha=0.35, color="#1f77b4", label="raw")
        ax.semilogy([r["epoch"] for r in h], [r["total_ema"] for r in h],
                    lw=1.6, color="#d62728",
                    label="EMA (best=%.3f)" % meta["best_ema"])
        ax.set_xlabel("epoch"); ax.set_ylabel("loss")
        tr = meta.get("train_T", [])
        ax.set_title("Nf=0 training loss (trained on %d points: %s)"
                     % (len(tr), ", ".join("%.3f" % t for t in tr)))
        ax.legend(fontsize=9); ax.grid(alpha=0.3, which="both")
        fig.tight_layout()
        fig.savefig(os.path.join(FIGS, "loss_history.png"), dpi=140)
        plt.close(fig)

    # ----------------------------------------------- figure 3: A(z), f(z), G
    z, A, f = d["z"], d["A"], d["f"]
    zCH = np.linspace(1e-4, 8.0, 500)
    ACH = -0.584 * np.log1p(0.072 * zCH ** 4)
    fCH = (1.0 + 0.072 * zCH ** 4) ** 0.584
    fig, ax = plt.subplots(1, 2, figsize=(11, 4.2))
    ax[0].plot(zCH, ACH, "--", color="0.4", label="CH Table-1 analytic")
    ax[0].plot(z, A, "-", color="#d62728", lw=2, label="trained $A(z)$")
    ax[0].set_xlabel("z [GeV$^{-1}$]"); ax[0].set_ylabel("A(z)")
    ax[1].plot(zCH, fCH, "--", color="0.4", label="CH Table-1 analytic")
    ax[1].plot(z, f, "-", color="#1f77b4", lw=2, label="trained $f(z)$")
    ax[1].set_xlabel("z [GeV$^{-1}$]"); ax[1].set_ylabel("f(z)")
    for a in ax:
        a.set_xlim(0, 6); a.legend(fontsize=9); a.grid(alpha=0.3)
    fig.suptitle("Nf=0 trained background (G = 8$\\pi$G$_5$ = %.4f)" % G)
    fig.tight_layout(rect=[0, 0, 1, 0.94])
    fig.savefig(os.path.join(FIGS, "A_f_background.png"), dpi=140)
    plt.close(fig)

    print("figures written to", FIGS)


if __name__ == "__main__":
    main()
