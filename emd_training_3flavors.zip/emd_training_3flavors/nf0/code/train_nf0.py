#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
train_nf0.py -- train A(z), f(z) of the EMD model on Nf=0 (pure-gauge) lattice
data, then the trained background is pushed back through the EMD to obtain the
full EOS (see plot_nf0.py).

INPUT   data/Nf0_train.csv : T[GeV], s_over_T3, sigma  (16 pure-gauge lattice
                             points, Borsanyi et al. 2012, arXiv:1204.6184)

MODEL   A(z) = A_net(z)  (A(0)=0, A<0, ~linear at large z)
        f(z) = F_net(z)  (f > 0)
        G    scalar (8 pi G_5), clamped to [0.05, 2.0]

LOSS    L = L_s + 1e-6 * L_reg + 1e-3 * L_phi
        L_s   = mean( ((s_EMD(T_i) - s_i)/sigma_i)^2 )   inverse-variance chi^2
        L_reg = mean (d2A/dz2)^2 + mean (d2 log f/dz2)^2  smoothness
        L_phi = mean relu(-phi'^2)                        dilaton reality

OPTIMISATION
        * warm start: pretrain A,f to the Chen-Huang Table-1 Nf=0 analytic
          background  A = -0.584 ln(1+0.072 z^4), f = (1+0.072 z^4)^0.584
        * Adam, cosine LR 1e-3 -> 1e-6, grad clip 1
        * EMA (decay 0.999) weights are used for evaluation / best selection
        * several seeds, the best-EMA run is kept
        * --n-points K trains on K evenly spaced points only; the rest of the
          table is then used as a held-out prediction test

OUTPUT  results/Nf0_A_f.npz     z, A(z), f(z) grids + G + meta   (trained model)
        results/Nf0_history.json  loss history
        (figures are made by plot_nf0.py)

Usage:  python3 code/train_nf0.py                 # default: 3 points, 3 seeds
        python3 code/train_nf0.py --n-points 16 --seeds 3
"""

import os
import sys
import json
import time
import math
import argparse

import numpy as np
import torch

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from emd_free import EMD, A_net, F_net, emd_mu0_curve   # noqa: E402

DATA = os.path.join(BASE, "data")
RESULTS = os.path.join(BASE, "results")

CH_NF0 = dict(b=0.072, d=-0.584)   # Chen & Huang Table 1, Nf=0


# ------------------------------------------------------------------- warm start
def pretrain_background(a_net, f_net, device, steps=1500, lr=1e-3, n=512):
    """Fit A_net, F_net to the analytic Nf=0 background (c = k = 0):
    A = d ln(1 + b z^4),  f = exp(-A)."""
    z = torch.exp(torch.linspace(np.log(1e-3), np.log(20.0), n, device=device))
    A_tgt = CH_NF0["d"] * torch.log1p(CH_NF0["b"] * z ** 4)
    opt = torch.optim.Adam(list(a_net.parameters()) + list(f_net.parameters()),
                           lr=lr)
    for _ in range(steps):
        opt.zero_grad(set_to_none=True)
        loss = ((a_net(z) - A_tgt) ** 2).mean() \
             + ((torch.log(f_net(z).clamp_min(1e-12)) + A_tgt) ** 2).mean()
        loss.backward()
        opt.step()
    return float(loss.detach())


# ---------------------------------------------------------------------- targets
def load_targets(device, n_points=3):
    """Training table + held-out split.  Returns tensors and the full table."""
    T_all, y_all, sig_all = [], [], []
    with open(os.path.join(DATA, "Nf0_train.csv")) as f:
        for line in f:
            if line.startswith("#") or not line.strip():
                continue
            t, y, s = line.split(",")[:3]
            T_all.append(float(t)); y_all.append(float(y)); sig_all.append(float(s))
    T_all = np.array(T_all); y_all = np.array(y_all); sig_all = np.abs(np.array(sig_all))
    idx = np.unique(np.linspace(0, len(T_all) - 1, n_points).astype(int))
    T = torch.tensor(T_all[idx], dtype=torch.float32, device=device)
    y = torch.tensor(y_all[idx], dtype=torch.float32, device=device)
    sig = torch.tensor(sig_all[idx], dtype=torch.float32, device=device).clamp_min(1e-4)
    full = dict(T=T_all, y=y_all, sig=sig_all, idx=[int(i) for i in idx])
    return T, y, sig, full


def _interp(Tg, yg, Tq):
    """Differentiable linear interpolation of yg(Tg) onto Tq."""
    Tq = Tq.clamp(Tg[0], Tg[-1])
    idx = torch.searchsorted(Tg.detach(), Tq.detach()).clamp(1, Tg.numel() - 1)
    x0, x1 = Tg[idx - 1], Tg[idx]
    y0, y1 = yg[idx - 1], yg[idx]
    w = ((Tq - x0) / (x1 - x0).clamp_min(1e-12)).clamp(0.0, 1.0)
    return y0 + w * (y1 - y0)


# ---------------------------------------------------------------------- training
def train(epochs=8000, lr=1e-3, lr_min=1e-6, device="cpu", seed=0, n_points=3,
          n_zh=400, zh_max=20.0, n_int=200, G_init=1.326, G_range=(0.05, 2.0),
          w_reg=1e-6, w_phi=1e-3, ema_decay=0.999, eval_every=25,
          pretrain_steps=1500, verbose=True, hidden=64, depth=4,
          data_seed=None):
    torch.manual_seed(seed)
    np.random.seed(seed)
    t0 = time.time()

    a_net = A_net(hidden=hidden, depth=depth, act="tanh", form="constrained").to(device)
    f_net = F_net(hidden=hidden, depth=depth, act="tanh").to(device)
    model = EMD(a_net, f_net, G=G_init, G_range=G_range, n_int=n_int).to(device)

    pt_loss = pretrain_background(a_net, f_net, device, steps=pretrain_steps)
    if verbose:
        print("warm start: pretrain loss %.3e" % pt_loss, flush=True)

    T_s, y_s, sig_s, full = load_targets(device, n_points=n_points)
    if data_seed is not None:
        rng = np.random.default_rng(data_seed)
        noise = torch.as_tensor(rng.standard_normal(len(y_s)), dtype=y_s.dtype,
                                device=y_s.device)
        y_s = y_s + sig_s * noise
    if verbose:
        print("training on %d/%d points: T = %s"
              % (len(full["idx"]), len(full["T"]),
                 ", ".join("%.4f" % t for t in full["T"][full["idx"]])), flush=True)

    zh_grid = torch.exp(torch.linspace(np.log(0.02), np.log(zh_max), n_zh,
                                       device=device))
    zz_smooth = torch.linspace(0.02, zh_max, 200, device=device)

    def losses():
        o = model.observables_mu0(zh_grid)
        T, s = o["T"], o["s_over_T3"]
        m = torch.isfinite(T) & torch.isfinite(s) & (T > 0)
        Tg, sg = T[m], s[m]
        order = torch.argsort(Tg)
        Tg, sg = Tg[order], sg[order]
        dup = torch.cat([torch.tensor([True], device=device),
                         torch.diff(Tg) > 1e-9])
        Tg, sg = Tg[dup], sg[dup]
        s_p = _interp(Tg, sg, T_s)
        L_s = (((s_p - y_s) / sig_s) ** 2).mean()
        L_phi = torch.relu(-model.phi_prime_sq(zz_smooth)).mean()
        Ag = a_net(zh_grid.unsqueeze(-1)).squeeze(-1)
        L_reg = ((Ag[2:] - 2 * Ag[1:-1] + Ag[:-2]) ** 2).mean()
        return L_s, L_reg, L_phi

    params = list(a_net.parameters()) + [model.G]
    opt = torch.optim.Adam(params, lr=lr)
    ema = {k: v.detach().clone() for k, v in model.state_dict().items()}

    def ema_eval():
        raw = {k: v.detach().clone() for k, v in model.state_dict().items()}
        model.load_state_dict(ema)
        L_s, L_reg, L_phi = losses()      # grad stays on: L_phi uses autograd
        tot = L_s + w_reg * L_reg + w_phi * L_phi
        model.load_state_dict(raw)
        return float(tot.detach()), float(L_s.detach())

    hist, best, best_state = [], float("inf"), None
    L_s0, _, _ = losses()
    if verbose:
        print("initial (warm-start) loss: L_s=%.4e" % float(L_s0), flush=True)

    for ep in range(epochs):
        model.train()
        opt.zero_grad(set_to_none=True)
        L_s, L_reg, L_phi = losses()
        tot = L_s + w_reg * L_reg + w_phi * L_phi
        cur = float(tot.detach())
        if not math.isfinite(cur):          # spike guard
            opt.zero_grad(set_to_none=True)
            continue
        tot.backward()
        torch.nn.utils.clip_grad_norm_(params, 1.0)
        opt.step()
        model.clamp_G()
        frac = ep / max(epochs - 1, 1)      # cosine decay
        for g in opt.param_groups:
            g["lr"] = lr_min + 0.5 * (lr - lr_min) * (1.0 + math.cos(math.pi * frac))
        with torch.no_grad():               # EMA update
            msd = model.state_dict()
            for k, v in ema.items():
                v.mul_(ema_decay).add_(msd[k], alpha=1.0 - ema_decay)
        if ep % eval_every == 0 or ep == epochs - 1:
            tot_e, Ls_e = ema_eval()
            if tot_e < best:
                best = tot_e
                best_state = {k: v.clone() for k, v in ema.items()}
            hist.append(dict(epoch=ep, total_raw=cur, L_s_raw=float(L_s.detach()),
                             total_ema=tot_e, L_s_ema=Ls_e,
                             lr=opt.param_groups[0]["lr"],
                             G=float(model.G.detach())))
            if verbose and (ep % (eval_every * 40) == 0 or ep == epochs - 1):
                print("  ep %5d  raw=%.4e  ema=%.4e  lr=%.2e  G=%.4f"
                      % (ep, cur, tot_e, opt.param_groups[0]["lr"],
                         float(model.G.detach())), flush=True)

    model.load_state_dict(best_state)
    res = dict(model=model, history=hist,
               meta=dict(method="mu=0 only (pure gauge)",
                         warm_start="CH Table1 Nf=0 analytic",
                         pretrain_loss=pt_loss, best_ema=best,
                         w_mode="inv", w_reg=w_reg, w_phi=w_phi,
                         n_zh=n_zh, n_int=n_int, hidden=hidden, depth=depth,
                         data_seed=data_seed,
                         A_parameterization="-z sigmoid(n_A(z))",
                         wall=time.time() - t0,
                         n_points=int(len(full["idx"])),
                         train_idx=full["idx"],
                         train_T=[float(full["T"][i]) for i in full["idx"]]))
    if verbose:
        print("best EMA loss %.4e (%.0fs)" % (best, time.time() - t0), flush=True)
    return res


def save(res):
    os.makedirs(RESULTS, exist_ok=True)
    z = torch.linspace(1e-4, 20.0, 4000)
    A, f, G = res["model"].export_functions(z)
    meta = {k: v for k, v in res["meta"].items()
            if isinstance(v, (int, float, str, type(None)))}
    p = os.path.join(RESULTS, "Nf0_A_f.npz")
    np.savez(p, z=z.numpy(), A=A, f=f, G=G, **meta)
    json.dump(dict(meta=res["meta"], history=res["history"]),
              open(os.path.join(RESULTS, "Nf0_history.json"), "w"), indent=1)
    return p


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--epochs", type=int, default=8000)
    ap.add_argument("--seeds", type=int, default=3)
    ap.add_argument("--n-points", type=int, default=3,
                    help="train on this many evenly spaced points (rest = test)")
    ap.add_argument("--device", default=None)
    a = ap.parse_args()
    dev = a.device or ("cuda" if torch.cuda.is_available() else "cpu")
    print("device:", dev, flush=True)

    winner, winner_seed = None, None
    for seed in range(a.seeds):
        print("=== run seed %d ===" % seed, flush=True)
        res = train(epochs=a.epochs, device=dev, seed=seed, n_points=a.n_points)
        print("seed %d: best EMA %.4e" % (seed, res["meta"]["best_ema"]), flush=True)
        if winner is None or res["meta"]["best_ema"] < winner["meta"]["best_ema"]:
            winner, winner_seed = res, seed
    print("winner: seed %d (best EMA %.4e)" % (winner_seed,
                                               winner["meta"]["best_ema"]))
    winner["meta"]["seed"] = winner_seed
    winner["meta"]["n_seeds"] = a.seeds
    p = save(winner)
    print("saved:", p, "(G=%.4f)" % float(winner["model"].G.detach()), flush=True)

    # quick held-out s/T^3 prediction test
    idx = set(winner["meta"]["train_idx"])
    Tm, sm, _ = emd_mu0_curve(winner["model"])
    _, _, _, full = load_targets(dev, n_points=16)   # full table for the test
    test_i = [i for i in range(len(full["T"])) if i not in idx]
    devs = []
    for i in test_i:
        pred = float(np.interp(full["T"][i], Tm, sm))
        devs.append(100.0 * (pred / full["y"][i] - 1.0))
    if devs:
        devs = np.array(devs)
        print("held-out (%d pts): rms = %.2f%%, max |dev| = %.2f%%"
              % (len(devs), np.sqrt((devs ** 2).mean()), np.abs(devs).max()))
    print("now run: python3 code/plot_nf0.py", flush=True)


if __name__ == "__main__":
    main()
