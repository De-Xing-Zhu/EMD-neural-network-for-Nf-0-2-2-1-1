#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
emd_free.py -- self-contained EMD forward model with FREE A(z), f(z).

Neural-network parameterisation of the holographic Einstein-Maxwell-Dilaton
background (generalisation of Chen & Huang, arXiv:2405.06179, whose analytic
ansatz A(z) = d ln(1+a z^2) + d ln(1+b z^4), f(z) = exp(c z^2 - A + k) is the
special case realised when the networks are trained to it).

Metric:  ds^2 = e^{2A(z)} (-f(z) dt^2 + dx^2) + dz^2/(f(z) e^{2A(z)})
Charge:  A_t(z) = mu (1 - F(z)/F(zh)),   F'(z) = z/(e^{A(z)} f(z))

The three integrals behind all mu=0 observables:

    I1(zh) = int_0^zh z^3 e^{-3A(z)} dz
    I2(zh) = int_0^zh z / (e^{A(z)} f(z)) dz
    I4(zh) = int_0^zh z^3 e^{-3A(z)} [int_0^z t/(e^{A(t)} f(t)) dt] dz

    T(zh)    = zh^3 e^{-3A(zh)} / (4 pi I1)
    s/T^3    = [e^{3A(zh)} / (4 G zh^3)] / T^3
    chi_2^B  = 1 / (16 pi G I2 T^2)
    T(zh,mu) = T(zh,0) [1 - (mu/I2)^2 (I1 I2 - I4)]     (exact in mu^2)
"""

import numpy as np
import torch
import torch.nn as nn

PI = float(np.pi)


# ===================================================================== networks
class A_net(nn.Module):
    """A(z): A(0)=0, A<0, with an unconstrained IR slope.

    form='constrained'/'sigmoid':  A(z) = -sigmoid(net(z)) * z   (default)
    form='uvsafe':                A(z) = -sigmoid(net(z)) * z * z^2/(z^2+z_UV^2),
        which enforces A = O(z^2) and a finite phi'^2 at z -> 0
    form='softplus':              A(z) = -softplus(net(z)) * z**2
    form='free':                  A(z) =  net(z) * z**2
    """

    def __init__(self, hidden=32, depth=3, act="tanh", form="constrained"):
        super().__init__()
        Act = {"tanh": nn.Tanh, "silu": nn.SiLU, "gelu": nn.GELU}[act]
        layers, d = [], 1
        for _ in range(depth):
            layers += [nn.Linear(d, hidden), Act()]
            d = hidden
        layers += [nn.Linear(d, 1)]
        self.net = nn.Sequential(*layers)
        self.softplus = nn.Softplus()
        self.form = form

    def forward(self, z):
        squeeze = z.dim() == 1
        zz = z.unsqueeze(-1) if squeeze else z
        if self.form == "uvsafe":
            z_uv = 0.05
            out = -torch.sigmoid(self.net(zz)) * zz * zz**2 / (zz**2 + z_uv**2)
        elif self.form in ("constrained", "sigmoid"):
            out = -torch.sigmoid(self.net(zz)) * zz
        elif self.form == "softplus":
            out = -self.softplus(self.net(zz)) * zz**2
        else:
            out = self.net(zz) * zz**2
        return out.squeeze(-1) if squeeze else out


class F_net(nn.Module):
    """f(z) > 0 by construction:  f = exp(net(z))."""

    def __init__(self, hidden=32, depth=3, act="tanh"):
        super().__init__()
        Act = {"tanh": nn.Tanh, "silu": nn.SiLU, "gelu": nn.GELU}[act]
        layers, d = [], 1
        for _ in range(depth):
            layers += [nn.Linear(d, hidden), Act()]
            d = hidden
        layers += [nn.Linear(d, 1)]
        self.net = nn.Sequential(*layers)

    def forward(self, z):
        squeeze = z.dim() == 1
        zz = z.unsqueeze(-1) if squeeze else z
        out = torch.exp(self.net(zz))
        return out.squeeze(-1) if squeeze else out


# ==================================================================== the model
class EMD(nn.Module):
    def __init__(self, a_net, f_net, G=1.326, G_range=(0.05, 2.0),
                 z0=0.0, n_int=200):
        super().__init__()
        self.a_net = a_net
        self.f_net = f_net
        self.G = nn.Parameter(torch.tensor(float(G)))
        self.G_range = G_range
        self.z0 = float(z0)
        self.n_int = int(n_int)

    def clamp_G(self):
        with torch.no_grad():
            self.G.clamp_(*self.G_range)

    def device(self):
        return self.G.device

    def _grid(self, zh):
        t = torch.linspace(0.0, 1.0, self.n_int,
                           device=zh.device, dtype=zh.dtype).unsqueeze(0)
        return zh.unsqueeze(1) * t

    @staticmethod
    def _cumtrapz(y, dz):
        inc = 0.5 * (y[:, 1:] + y[:, :-1]) * dz.unsqueeze(1)
        out = torch.zeros_like(y)
        out[:, 1:] = torch.cumsum(inc, dim=1)
        return out

    def integrals(self, zh):
        """I1, I2, I4, A(zh) as [B] tensors."""
        zh = zh.to(self.device())
        B = zh.shape[0]
        z = self._grid(zh)
        dz = (zh - self.z0 * torch.ones_like(zh)) / (self.n_int - 1)
        zf = z.reshape(-1, 1)
        A = self.a_net(zf).reshape(B, self.n_int)
        f = self.f_net(zf).reshape(B, self.n_int).clamp_min(1e-8)
        g1 = z ** 3 * torch.exp(-3.0 * A)
        g2 = z / (torch.exp(A) * f)
        u1 = self._cumtrapz(g1, dz)
        u2 = self._cumtrapz(g2, dz)
        u3 = self._cumtrapz(g1 * u2, dz)
        return u1[:, -1].clamp_min(1e-14), u2[:, -1].clamp_min(1e-14), \
            u3[:, -1], A[:, -1]

    def observables_mu0(self, zh):
        """T, s/T^3, chi_2^B from ONE integral evaluation."""
        I1, I2, _, Azh = self.integrals(zh)
        T = (zh ** 3 * torch.exp(-3.0 * Azh) / (4.0 * PI * I1)).clamp_min(1e-8)
        S = torch.exp(3.0 * Azh) / (4.0 * self.G * zh ** 3)
        return dict(T=T, s_over_T3=S / T ** 3,
                    chi2B=(1.0 / (16.0 * PI * self.G * I2 * T ** 2))
                    .clamp_min(1e-14))

    def phi_prime_sq(self, z):
        """phi'^2 = 6 (A'^2 - A'' - 2 A'/z), must be >= 0."""
        z = z.to(self.device()).detach().clone().requires_grad_(True)
        A = self.a_net(z)
        A1 = torch.autograd.grad(A.sum(), z, create_graph=True)[0]
        A2 = torch.autograd.grad(A1.sum(), z, create_graph=True)[0]
        return 6.0 * (A1 ** 2 - A2 - 2.0 * A1 / z)

    @torch.no_grad()
    def export_functions(self, z):
        zz = torch.as_tensor(z, dtype=torch.float32, device=self.device())
        return (self.a_net(zz).cpu().numpy().ravel(),
                self.f_net(zz).cpu().numpy().ravel(),
                float(self.G.detach().cpu()))


# ------------------------------------------------- loading a trained model
class InterpNet(nn.Module):
    """Linear-interpolation wrapper around a saved (z, y) table."""

    def __init__(self, z, y):
        super().__init__()
        self.register_buffer("z", torch.as_tensor(z, dtype=torch.float32))
        self.register_buffer("y", torch.as_tensor(y, dtype=torch.float32))

    def forward(self, x):
        xx = x.reshape(-1).clamp(self.z[0], self.z[-1])
        i = torch.searchsorted(self.z.detach(), xx.detach()).clamp(
            1, self.z.numel() - 1)
        w = ((xx - self.z[i - 1]) / (self.z[i] - self.z[i - 1])
             .clamp_min(1e-12)).clamp(0, 1)
        return self.y[i - 1] + w * (self.y[i] - self.y[i - 1])


def load_trained(npz_path, n_int=1500):
    """Rebuild the EMD model from a saved results/<flavor>_A_f.npz file."""
    d = np.load(npz_path, allow_pickle=True)
    m = EMD(InterpNet(d["z"], d["A"]), InterpNet(d["z"], d["f"]),
            G=float(d["G"]), n_int=n_int)
    m.eval()
    return m


@torch.no_grad()
def emd_mu0_curve(model, zmin=0.02, zmax=30.0, n=4000):
    """The STABLE black-hole branch: (T, s/T^3, zh), T ascending.

    Walks zh from small to large and stops at the first turning point of
    T(zh), so the unstable branch is never spliced in.
    """
    dev = model.device()
    zh = torch.exp(torch.linspace(np.log(zmin), np.log(zmax), n, device=dev))
    o = model.observables_mu0(zh)
    T = o["T"].detach().cpu().numpy()
    s = o["s_over_T3"].detach().cpu().numpy()
    zhn = zh.detach().cpu().numpy()
    good = np.isfinite(T) & np.isfinite(s) & (T > 0)
    if not good.all():
        i0 = int(np.argmax(good)) if good.any() else 0
        T, s, zhn = T[i0:], s[i0:], zhn[i0:]
    dT = np.diff(T)
    turn = np.where(dT > 0)[0]           # T must decrease along the branch
    if len(turn):
        k = turn[0] + 1
        T, s, zhn = T[:k], s[:k], zhn[:k]
    return T[::-1], s[::-1], zhn[::-1]
