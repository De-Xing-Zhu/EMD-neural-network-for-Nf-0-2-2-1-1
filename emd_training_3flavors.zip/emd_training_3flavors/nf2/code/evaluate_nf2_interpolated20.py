#!/usr/bin/env python3
"""Compare the original and PCHIP20 Nf=2 fits on both target sets."""

import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
from scipy.signal import find_peaks

BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE / "code"))
from emd_free import load_trained
from train_nf2 import _interp, load_targets

MODELS = {
    "original": BASE / "results/Nf2_A_f_nohrg_smooth.npz",
    "pchip20_base": BASE / "results/Nf2_A_f_interpolated20_seed50.npz",
    "pchip20_refined": BASE / "results/Nf2_A_f_interpolated20_smooth.npz",
}
TARGETS = {
    "original10": ("Nf2_train_chi_verified.csv", "Nf2_nB_muhat1_verified.csv"),
    "pchip20": ("Nf2_train_chi_interpolated20.csv",
                "Nf2_nB_muhat1_interpolated20.csv"),
}


def rms(values):
    return float(np.sqrt(np.mean(np.asarray(values)**2)))


def stable(t, y):
    good = np.isfinite(t) & np.isfinite(y) & (t > 0)
    order = np.argsort(t[good])
    return t[good][order], y[good][order]


@torch.enable_grad()
def evaluate(path, target_sets):
    model = load_trained(str(path), n_int=400)
    zh = torch.exp(torch.linspace(np.log(0.02), np.log(20.0), 4000))
    obs = model.observables_mu0(zh)
    t, s = stable(obs["T"].detach().numpy(), obs["s_over_T3"].detach().numpy())
    tc, chi = stable(obs["T"].detach().numpy(), obs["chi2B"].detach().numpy())
    nb, tn, _ = model.nB_over_T3(zh, muhat=1.0)
    tn, nb = stable(tn.detach().numpy(), nb.detach().numpy())
    reports = {}
    for label, (chi_file, rho_file) in target_sets.items():
        data = load_targets("cpu", no_hrg=True, s_boost=4.0,
                            s_boost_win=(0.19, 0.24),
                            chi_file=chi_file, rho_file=rho_file)
        rs = ((_interp(torch.tensor(t), torch.tensor(s), data["T_s"]) -
               data["y_s"]) / data["sig_s"]).detach().numpy()
        rc = ((_interp(torch.tensor(tc), torch.tensor(chi), data["T_c"]) -
               data["y_c"]) / data["sig_c"]).detach().numpy()
        delta = (_interp(torch.tensor(tn), torch.tensor(nb), data["T_r"]) -
                 _interp(torch.tensor(tc), torch.tensor(chi), data["T_r"]))
        rn = ((delta - (data["y_r"] - data["y_r_chi2"])) /
              data["sig_r_cond"]).detach().numpy()
        reports[label] = {
            "entropy_rms_pull": rms(rs),
            "chi2B_rms_pull": rms(rc),
            "chi2B_max_abs_pull": float(np.max(np.abs(rc))),
            "density_increment_rms_pull": rms(rn),
            "density_increment_max_abs_pull": float(np.max(np.abs(rn))),
        }
    with np.load(path, allow_pickle=False) as saved:
        z, A, f = saved["z"], saved["A"], saved["f"]
    selected = (z >= 0.02) & (z <= 2.5)
    zz, ff = z[selected], f[selected]
    maxima = find_peaks(ff)[0]
    minima = find_peaks(-ff)[0]
    a1 = np.gradient(A, z)
    a2 = np.gradient(a1, z)
    phi2 = 6.0 * (a1**2 - a2 - 2.0*a1/z)
    return {
        "model": str(path),
        "metrics": reports,
        "f_extrema": len(maxima) + len(minima),
        "f_maxima": [[float(zz[i]), float(ff[i])] for i in maxima],
        "min_phi_prime_sq": float(np.min(phi2)),
        "finite_observables": bool(np.isfinite(t).all() and
                                   np.isfinite(chi).all() and
                                   np.isfinite(nb).all()),
    }, (t, tc, chi, tn, nb, z, f)


def main():
    missing = [str(path) for path in MODELS.values() if not path.is_file()]
    if missing:
        raise FileNotFoundError("Missing models: " + ", ".join(missing))
    report, curves = {}, {}
    for label, path in MODELS.items():
        report[label], curves[label] = evaluate(path, TARGETS)
    out = BASE / "results/interpolated20_evaluation.json"
    out.write_text(json.dumps(report, indent=2) + "\n")

    plt.rcParams.update({"font.size": 9, "axes.labelsize": 10,
                         "legend.fontsize": 8, "figure.dpi": 150})
    fig, axes = plt.subplots(1, 3, figsize=(12, 3.5), constrained_layout=True)
    styles = {
        "original": ("Original 10-point fit", "black", "--"),
        "pchip20_base": ("PCHIP20, before refinement", "tab:blue", ":"),
        "pchip20_refined": ("PCHIP20, refined", "tab:red", "-"),
    }
    for label, (name, color, ls) in styles.items():
        _, _, _, _, _, z, f = curves[label]
        axes[0].plot(z, f, ls=ls, color=color, lw=1.5, label=name)
    axes[0].set(xlabel="$z$ [GeV$^{-1}$]", ylabel="$f(z)$", xlim=(0, 3))
    axes[0].legend(frameon=False)

    with (BASE / "data/Nf2_train_chi_verified.csv").open() as stream:
        original = np.genfromtxt(stream, delimiter=",", names=True)
    with (BASE / "data/Nf2_train_chi_interpolated20.csv").open() as stream:
        interpolated = np.genfromtxt(stream, delimiter=",", names=True)
    with (BASE / "data/Nf2_nB_muhat1_verified.csv").open() as stream:
        original_nb = np.genfromtxt(stream, delimiter=",", names=True)
    with (BASE / "data/Nf2_nB_muhat1_interpolated20.csv").open() as stream:
        interpolated_nb = np.genfromtxt(stream, delimiter=",", names=True)
    for ax, original_y, interpolated_y, curve_index, ylabel in [
        (axes[1], original["chi2B"], interpolated["chi2B"], 2, r"$\chi_2^B$"),
        (axes[2], original_nb["nB_over_T3"], interpolated_nb["nB_over_T3"], 4,
         r"$n_B/T^3\;(\mu_B/T=1)$"),
    ]:
        if original_y is not None:
            ax.plot(original["T"], original_y, "o", color="black", ms=4,
                    label="Original 10 points")
            ax.plot(interpolated["T"], interpolated_y, "s", color="tab:orange",
                    ms=3, label="PCHIP20 targets")
        for label, (name, color, ls) in styles.items():
            curve = curves[label]
            t = curve[1] if curve_index == 2 else curve[3]
            y = curve[curve_index]
            ax.plot(t, y, ls=ls, color=color, lw=1.4, label=name)
        ax.set(xlabel="$T$ [GeV]", ylabel=ylabel, xlim=(0.18, 0.435))
        ax.grid(alpha=0.2)
    axes[1].legend(frameon=False, loc="lower right")
    fig.savefig(BASE / "figures/interpolated20_comparison.png", dpi=180)
    fig.savefig(BASE / "figures/interpolated20_comparison.pdf")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
