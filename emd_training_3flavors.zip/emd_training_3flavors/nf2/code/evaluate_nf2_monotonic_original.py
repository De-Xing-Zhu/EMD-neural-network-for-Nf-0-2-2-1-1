#!/usr/bin/env python3
"""Evaluate the joint monotonic Nf=2 refit on the original 10 points."""

import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE / "code"))
from evaluate_nf2_interpolated20 import evaluate

MODELS = {
    "original_free": BASE / "results/Nf2_A_f_nohrg_smooth.npz",
    "frozen_monotonic": BASE / "results/monotonic_f_scan/Nf2_A_f_monotonic_chi4.npz",
    "warm_monotonic": BASE / "results/Nf2_A_f_monotonic_warm20k_seed50.npz",
}
TARGET = {
    "original10": ("Nf2_train_chi_verified.csv", "Nf2_nB_muhat1_verified.csv"),
}


def main():
    missing = [str(path) for path in MODELS.values() if not path.is_file()]
    if missing:
        raise FileNotFoundError("Missing models: " + ", ".join(missing))
    report, curves = {}, {}
    for label, path in MODELS.items():
        report[label], curves[label] = evaluate(path, TARGET)
        with np.load(path, allow_pickle=False) as saved:
            f = saved["f"]
        report[label].update(
            f_min=float(np.min(f)),
            max_positive_f_step=float(np.max(np.diff(f))),
            hard_shape_check_passed=bool(np.min(f) > 0 and
                                         np.max(np.diff(f)) <= 1e-7),
        )
    out = BASE / "results/monotonic_original_evaluation.json"
    out.write_text(json.dumps(report, indent=2) + "\n")

    plt.rcParams.update({"font.size": 9, "axes.labelsize": 10,
                         "legend.fontsize": 8, "figure.dpi": 150})
    fig, axes = plt.subplots(1, 3, figsize=(12, 3.5), constrained_layout=True)
    styles = {
        "original_free": ("Original free fit", "black", "--"),
        "frozen_monotonic": ("Monotonic, frozen $A,G$", "tab:blue", ":"),
        "warm_monotonic": ("Warm-started joint monotonic", "tab:red", "-"),
    }
    for label, (name, color, ls) in styles.items():
        _, _, _, _, _, z, f = curves[label]
        axes[0].plot(z, f, ls=ls, color=color, lw=1.5, label=name)
    axes[0].set(xlabel="$z$ [GeV$^{-1}$]", ylabel="$f(z)$", xlim=(0, 3))
    axes[0].legend(frameon=False)

    with (BASE / "data/Nf2_train_chi_verified.csv").open() as stream:
        chi_data = np.genfromtxt(stream, delimiter=",", names=True)
    with (BASE / "data/Nf2_nB_muhat1_verified.csv").open() as stream:
        nb_data = np.genfromtxt(stream, delimiter=",", names=True)
    for ax, data, y, curve_index, ylabel in [
        (axes[1], chi_data, chi_data["chi2B"], 2, r"$\chi_2^B$"),
        (axes[2], nb_data, nb_data["nB_over_T3"], 4,
         r"$n_B/T^3\;(\mu_B/T=1)$"),
    ]:
        ax.plot(data["T"], y, "o", color="black", ms=4,
                label="Original lattice points")
        for label, (name, color, ls) in styles.items():
            curve = curves[label]
            t = curve[1] if curve_index == 2 else curve[3]
            ax.plot(t, curve[curve_index], ls=ls, color=color, lw=1.4,
                    label=name)
        ax.set(xlabel="$T$ [GeV]", ylabel=ylabel, xlim=(0.18, 0.435))
        ax.grid(alpha=0.2)
    axes[1].legend(frameon=False, loc="lower right")
    fig.savefig(BASE / "figures/monotonic_original_comparison.png", dpi=180)
    fig.savefig(BASE / "figures/monotonic_original_comparison.pdf")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
