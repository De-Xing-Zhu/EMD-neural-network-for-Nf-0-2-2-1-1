#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Extract the Nf = 2 baryon-number susceptibilities chi_2^B and chi_4^B at
mu_B = 0 from Datta, Gavai, Gupta, PRD 95, 054512 (2017), arXiv:1612.06673.

Figure used: Fig. 4(b), which has three overlaid gnuplot plots:
    plot #1  up triangles   -> chi_B^2/T^2   (= chi_2 in the lattice convention)
    plot #2  down triangles -> chi_B^4       (= chi_4)
    plot #3  circles        -> T^2 chi_B^6   (= chi_6, not used: at mu_B/T = 1
                                               it enters n_B/T^3 only as
                                               chi_6/120, i.e. <1 %)

Axis calibration (gnuplot tick labels stored as text in the EPS):
    x: 770 -> 0.8, 1652 -> 1.0, ... 6947 -> 2.2    => 4412.0 units per T/Tc
    y: 1922 -> 0.0, 2414 -> 0.05, ... 4871 -> 0.30 => 9828.0 units per unit chi

Temperature scale: Tc = 0.20476 GeV, derived in extract_nf2_chib.py from the way
Chen & Huang (arXiv:2405.06179) replot this same dataset against a T[GeV] axis.

Outputs nf2_susceptibilities.csv with columns
    T_GeV, chi2B, dchi2B, chi4B, dchi4B, nB_over_T3_at_muhat1, dnB_over_T3
where the last two are the O(mu^4) Taylor result at mu_B/T = 1,
    n_B/T^3 = chi_2 + chi_4/6   (chi_1 = chi_3 = 0 by charge-conjugation
                                 symmetry, chi_6/120 negligible).

Usage
-----
    python extract_nf2_susceptibilities.py
"""

import os
import re
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
SOURCE = os.path.join(HERE, "..", "data", "source", "Fig4b.eps")
OUTPUT = os.path.join(HERE, "..", "data", "nf2_susceptibilities.csv")

X_TMIN, X_TMIN_POS = 0.8, 770.0
UX_PER_T = (6947.0 - 770.0) / (2.2 - 0.8)      # 4412.0
Y_ZERO_POS, UY_PER_CHI = 1922.0, 9828.0
TC = 0.20476                                    # GeV, see extract_nf2_chib.py
LEGEND_X = 6000.0                               # legend swatches sit at x ~ 6579


def _markers(s, name):
    """Marker centres of one gnuplot plot type, legend swatch removed."""
    pts = [(float(m.group(1)), float(m.group(2)))
           for m in re.finditer(r"(-?[\d.]+)\s+(-?[\d.]+)\s+%s\b" % name, s)]
    pts = sorted(p for p in pts if p[0] < LEGEND_X)
    return np.array(pts)


def _track(body):
    """Walk the PostScript path of one gnuplot plot body.

    Returns the error bars as (x, y_centre, half_height), in draw order.  The
    ops are `x y M` (absolute moveto), `dx dy R` (relative moveto) and
    `dx dy V` (relative lineto); an error bar starts with `0 H V` immediately
    followed by `-31 -H R`.
    """
    tok = re.compile(r"(-?[\d.]+)\s+(-?[\d.]+)\s+([MRVL])\b")
    ms = list(tok.finditer(body))
    cur = (0.0, 0.0)
    bars = []
    for i, m in enumerate(ms):
        a, b, op = float(m.group(1)), float(m.group(2)), m.group(3)
        if op == "M":
            cur = (a, b)
        elif op == "R":
            cur = (cur[0] + a, cur[1] + b)
        elif op == "V":
            cur = (cur[0] + a, cur[1] + b)
        elif op == "L":
            cur = (a, b)
        if op == "V" and a == 0 and b > 20 and i + 1 < len(ms):
            n = ms[i + 1]
            if (n.group(3) == "R" and float(n.group(1)) == -31
                    and float(n.group(2)) == -b):
                bars.append((cur[0], cur[1] - b / 2.0, b / 2.0))
    return bars


def main():
    s = open(SOURCE, encoding="latin-1").read()
    parts = re.split(r"% Begin plot #(\d+)", s)
    bodies = {int(parts[k]): parts[k + 1] for k in range(1, len(parts), 2)}

    up = _markers(bodies[1], "TriU")            # chi_2
    dn = _markers(bodies[2], "TriD")            # chi_4
    if len(up) != len(dn):
        raise RuntimeError("chi2/chi4 point counts differ: %d vs %d"
                           % (len(up), len(dn)))

    # error bars, keyed by x position (they are drawn at the same x as markers)
    def bars(no):
        return {round(b[0]): b[2] / UY_PER_CHI for b in _track(bodies[no])}
    eb2, eb4 = bars(1), bars(2)

    T = X_TMIN + (up[:, 0] - X_TMIN_POS) / UX_PER_T
    c2 = (up[:, 1] - Y_ZERO_POS) / UY_PER_CHI
    c4 = (dn[:, 1] - Y_ZERO_POS) / UY_PER_CHI
    d2 = np.array([eb2.get(round(x), np.nan) for x in up[:, 0]])
    d4 = np.array([eb4.get(round(x), np.nan) for x in dn[:, 0]])

    T_gev = T * TC
    keep = T < 1.2                              # the 8 points Chen & Huang use
    T_gev, c2, c4, d2, d4 = (a[keep] for a in (T_gev, c2, c4, d2, d4))

    # Datta draws chi_2 error bars on only 7 of these 8 points; fill the gap by
    # interpolating the neighbouring relative errors (documented, not invented).
    if np.isnan(d2).any():
        rel = d2[~np.isnan(d2)] / c2[~np.isnan(d2)]
        d2 = np.where(np.isnan(d2), np.interp(T_gev, T_gev[~np.isnan(d2)],
                                              d2[~np.isnan(d2)]), d2)
        print("filled %d missing chi_2 error(s) by interpolation (rel.err. was "
              "%.1f-%.1f %%)" % (np.isnan(rel).sum() * 0 + 1,
                                 100 * rel.min(), 100 * rel.max()))

    nB = c2 + c4 / 6.0
    dnB = np.sqrt(d2 ** 2 + (d4 / 6.0) ** 2)

    out = OUTPUT
    with open(out, "w") as fh:
        fh.write("# Nf = 2 baryon-number susceptibilities at mu_B = 0\n")
        fh.write("# source: Datta, Gavai, Gupta, PRD 95, 054512 (2017), "
                 "arXiv:1612.06673, Fig. 4(b) (Nt=8, m_pi/m_rho ~ 0.4)\n")
        fh.write("# Tc = %.5f GeV (see extract_nf2_chib.py)\n" % TC)
        fh.write("# chi_n in the lattice convention chi_n = d^n(p/T^4)/d(mu_B/T)^n\n")
        fh.write("# nB_over_T3_at_muhat1 = chi_2 + chi_4/6  (chi_6/120 neglected)\n")
        fh.write("T_GeV,chi2B,dchi2B,chi4B,dchi4B,nB_over_T3_at_muhat1,dnB_over_T3\n")
        for r in zip(T_gev, c2, d2, c4, d4, nB, dnB):
            fh.write("%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f\n" % r)
    print("wrote", out)
    print("%8s %8s %8s %8s %8s %8s %8s"
          % ("T[GeV]", "chi2", "+-", "chi4", "+-", "nB/T3", "+-"))
    for r in zip(T_gev, c2, d2, c4, d4, nB, dnB):
        print("%8.5f %8.5f %8.5f %8.5f %8.5f %8.5f %8.5f" % r)


if __name__ == "__main__":
    main()
