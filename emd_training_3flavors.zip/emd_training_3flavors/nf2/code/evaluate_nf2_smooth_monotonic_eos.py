#!/usr/bin/env python3
"""Compare the selected smooth-monotonic Nf=2 EOS with the original LQCD table."""

import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE / "code"))
from emd_free import emd_mu0_curve, load_trained

MODELS = {
    "Original free fit": BASE / "results/Nf2_A_f_nohrg_smooth.npz",
    "Smooth monotonic B-spline": BASE / "results/Nf2_A_f_smooth_monotonic_warm20k_phi10_seed50.npz",
}


def complete(path, anchor=(0.174, 0.302)):
    model = load_trained(str(path), n_int=1500)
    t, s, _ = emd_mu0_curve(model, zmax=30.0, n=6000)
    order = np.argsort(t)
    t, s = np.asarray(t)[order], np.asarray(s)[order]
    t, unique = np.unique(t, return_index=True)
    s = s[unique]
    integral = np.r_[0.0, np.cumsum(
        0.5*(s[1:]*t[1:]**3+s[:-1]*t[:-1]**3)*np.diff(t))]
    constant = anchor[1]*anchor[0]**4-np.interp(anchor[0], t, integral)
    p = (integral+constant)/t**4
    return t, {"s_over_T3": s, "p_over_T4": p,
               "e_over_T4": s-p, "I_over_T4": s-4*p}


def main():
    table = np.genfromtxt(BASE / "data/newSEXP_eos.csv", delimiter=",", names=True)
    p0 = 0.302
    td = table["T_GeV"]
    observed = {"s_over_T3": table["s_over_T3"]+4*p0,
                "p_over_T4": table["p_over_T4"]+p0,
                "e_over_T4": table["e_over_T4"]+3*p0,
                "I_over_T4": table["I_over_T4"]}
    errors = {"s_over_T3": table["ds"], "p_over_T4": table["dp"],
              "e_over_T4": table["de"], "I_over_T4": table["dI"]}
    curves = {label: complete(path) for label, path in MODELS.items()}
    report = {}
    for label, (t, predicted) in curves.items():
        report[label] = {}
        for key in observed:
            pull = (np.interp(td, t, predicted[key])-observed[key])/errors[key]
            report[label][key] = {
                "rms_pull": float(np.sqrt(np.mean(pull**2))),
                "max_abs_pull": float(np.max(np.abs(pull))),
            }
    (BASE / "results/Nf2_eos_smooth_monotonic_warm20k_phi10_seed50.json").write_text(
        json.dumps(report, indent=2)+"\n")

    labels = {"s_over_T3": "$s/T^3$", "p_over_T4": "$p/T^4$",
              "e_over_T4": "$\\epsilon/T^4$", "I_over_T4": "$(\\epsilon-3p)/T^4$"}
    fig, axes = plt.subplots(2, 2, figsize=(11, 7.4), constrained_layout=True)
    for ax, (key, ylabel) in zip(axes.flat, labels.items()):
        for label, color, ls in (("Original free fit", "black", "--"),
                                 ("Smooth monotonic B-spline", "tab:red", "-")):
            t, predicted = curves[label]
            shown = (t >= 0.17) & (t <= 0.435)
            ax.plot(t[shown], predicted[key][shown], color=color, ls=ls,
                    lw=1.7, label=label)
        ax.errorbar(td, observed[key], yerr=errors[key], fmt="o", color="tab:blue",
                    ms=4.5, capsize=2.5, label="LQCD (Burger 2015)")
        ax.set(xlim=(0.17, 0.435), xlabel="$T$ [GeV]", ylabel=ylabel)
        ax.grid(alpha=0.2)
    axes.flat[0].legend(frameon=False, fontsize=9)
    fig.suptitle("$N_f=2$ LQCD-only EOS: smooth monotonic $f(z)$", fontsize=13)
    stem = BASE / "figures/smooth_monotonic_lqcd_eos_comparison"
    fig.savefig(stem.with_suffix(".png"), dpi=190)
    fig.savefig(stem.with_suffix(".pdf"))
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
