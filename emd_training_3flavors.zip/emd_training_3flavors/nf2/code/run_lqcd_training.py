#!/usr/bin/env python3
"""Reproduce the selected Nf=2 LQCD-only smooth-monotonic fit and diagnostics."""
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent


def main():
    commands = [
        [sys.executable, str(HERE / "train_nf2_smooth_monotonic_warm.py"),
         "--seed", "50", "--pretrain-steps", "20000",
         "--phase1", "6000", "--phase2", "3000", "--w-phi", "10",
         "--tag", "_smooth_monotonic_warm20k_phi10_seed50", "--device", "cuda"],
        [sys.executable, str(HERE / "evaluate_nf2_smooth_monotonic_original.py")],
        [sys.executable, str(HERE / "evaluate_nf2_smooth_monotonic_eos.py")],
        [sys.executable, str(HERE / "evaluate_nf2_smooth_monotonic_cep.py")],
    ]
    for command in commands:
        subprocess.run(command, check=True)


if __name__ == "__main__":
    main()
