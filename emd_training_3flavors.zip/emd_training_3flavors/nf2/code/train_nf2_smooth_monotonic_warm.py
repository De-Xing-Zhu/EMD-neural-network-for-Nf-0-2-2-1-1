#!/usr/bin/env python3
"""Warm-start an LQCD-only Nf=2 fit with a smooth monotonic cubic-spline f."""

import argparse
import sys
from pathlib import Path

import numpy as np
import torch

BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE / "code"))
from emd_free import A_net, EMD
from monotonic_f import SmoothMonotonicF, pava_decreasing
from train_nf2 import save, train


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path,
                        default=BASE/"results/monotonic_f_scan/Nf2_A_f_monotonic_chi4.npz")
    parser.add_argument("--tag", default="_smooth_monotonic_warm20k_seed50")
    parser.add_argument("--seed", type=int, default=50)
    parser.add_argument("--phase1", type=int, default=6000)
    parser.add_argument("--phase2", type=int, default=3000)
    parser.add_argument("--pretrain-steps", type=int, default=20000)
    parser.add_argument("--f-knots", type=int, default=56)
    parser.add_argument("--w_reg", type=float, default=1e-5)
    parser.add_argument("--w-phi", type=float, default=1e-3)
    parser.add_argument("--device", default="cuda")
    args = parser.parse_args()

    with np.load(args.source, allow_pickle=False) as saved:
        z_saved, A_saved = saved["z"].copy(), saved["A"].copy()
        f_saved, G_saved = saved["f"].copy(), float(saved["G"])
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    a_net = A_net(hidden=64, depth=4, act="tanh", form="constrained").to(args.device)
    z_knots = np.geomspace(1e-4, 20.0, args.f_knots)
    log_f_init = np.interp(np.log(z_knots), np.log(z_saved),
                           np.log(np.clip(f_saved, 1e-35, None)))
    f_net = SmoothMonotonicF(np.log(z_knots),
                             pava_decreasing(log_f_init)).to(args.device)
    model = EMD(a_net, f_net, G=G_saved, n_int=200).to(args.device)

    z = torch.as_tensor(z_saved, dtype=torch.float32, device=args.device)
    target = torch.as_tensor(A_saved, dtype=torch.float32, device=args.device)
    optimizer = torch.optim.Adam(a_net.parameters(), lr=1e-3)
    for step in range(args.pretrain_steps):
        optimizer.zero_grad(set_to_none=True)
        prediction = a_net(z.unsqueeze(-1)).squeeze(-1)
        loss = (prediction - target).square().mean()
        loss.backward()
        optimizer.step()
    print("source", args.source, "A pretrain loss", float(loss.detach()), flush=True)

    result = train(
        phase1=args.phase1, phase2=args.phase2, lr=1e-4, lr2=3e-5,
        device=args.device, seed=args.seed, hidden=64, depth=4,
        n_zh=400, n_int=200, no_hrg=True, s_boost=4.0, w_reg=args.w_reg,
        w_phi=args.w_phi,
        smooth_monotonic_f=True, f_knots=len(z_knots), G_init=G_saved,
        initial_state=model.state_dict(),
    )
    result["meta"].update(
        seed=args.seed, n_seeds=1, warm_start=args.source.name,
        initial_npz=str(args.source), A_pretrain_loss=float(loss.detach()),
    )
    print("saved:", save(result, tag=args.tag), flush=True)


if __name__ == "__main__":
    main()
