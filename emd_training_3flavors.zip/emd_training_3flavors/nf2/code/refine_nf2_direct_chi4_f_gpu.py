#!/usr/bin/env python3
import json
import math
from pathlib import Path

import numpy as np
import torch

from emd_free import EMD, InterpNet
from refine_nf2_nohrg_smooth_f_gpu import SmoothF, branch
from train_nf2 import _interp, load_targets

BASE = Path(__file__).resolve().parents[1]
SOURCE = BASE / "results/Nf2_A_f_nohrg_smooth.npz"
OUT = BASE / "results/prd_direct_chi4"


def main():
    if not torch.cuda.is_available():
        raise SystemExit("CUDA unavailable")
    with np.load(SOURCE, allow_pickle=False) as data:
        z, A, f, G = (data[k].copy() for k in ("z", "A", "f", "G"))
    D = load_targets("cuda", no_hrg=True, s_boost=4.0,
                     s_boost_win=(0.19, 0.24), p_anch=(0.174, 0.302), chi4_fit=True)
    zh = torch.exp(torch.linspace(math.log(0.02), math.log(20.0), 700, device="cuda"))
    report = {"source": str(SOURCE), "A_and_G_frozen": True,
              "weights": [1.0, 4.0, 16.0], "fits": {}}
    for weight in report["weights"]:
        model = EMD(InterpNet(z, A), SmoothF(z, f), G=float(G), n_int=300).cuda()
        model.G.requires_grad_(False)
        opt = torch.optim.Adam([model.f_net.coeff], lr=0.006)
        best, best_coeff = None, None
        history = []
        normalizer = None
        for epoch in range(2601):
            opt.zero_grad(set_to_none=True)
            o = model.observables_mu0(zh)
            tc, chi = branch(o["T"], o["chi2B"])
            rc = (_interp(tc, chi, D["T_c"])-D["y_c"])/D["sig_c"]
            nb, tnb, _ = model.nB_over_T3(zh, muhat=1.0)
            tn, nb = branch(tnb, nb)
            delta = _interp(tn, nb, D["T_r"])-_interp(tc, chi, D["T_r"])
            rn = (delta-(D["y_r"]-D["y_r_chi2"]))/D["sig_r_cond"]
            t4, _, c4 = model.susceptibilities_mu0(zh)
            t4, c4 = branch(t4, c4)
            r4 = (_interp(t4, c4, D["T_4"])-D["y_4"])/D["sig_4"]
            raw4 = r4.square().mean()
            if normalizer is None:
                normalizer = max(float(raw4.detach()), 1e-12)
            mc = (tc[:-1] >= 0.185) & (tc[1:] <= 0.435)
            mn = (tn[:-1] >= 0.185) & (tn[1:] <= 0.435)
            sc = (chi[1:]-chi[:-1])/(tc[1:]-tc[:-1]).clamp_min(1e-7)
            sn = (nb[1:]-nb[:-1])/(tn[1:]-tn[:-1]).clamp_min(1e-7)
            mono = torch.relu(-sc[mc]).square().mean() + torch.relu(-sn[mn]).square().mean()
            coeff = model.f_net.coeff
            smooth = (coeff[2:]-2*coeff[1:-1]+coeff[:-2]).square().mean()
            reg = 0.02*coeff.square().mean() + 0.15*smooth
            loss = rc.square().mean() + 2*rn.square().mean() + weight*raw4/normalizer + 50*mono + reg
            values = [float(x.detach()) for x in (rc.square().mean(), rn.square().mean(),
                      raw4, rc.abs().max(), rn.abs().max(), r4.abs().max(), mono, smooth)]
            score = values[0] + values[1] + values[2] + 0.02*(values[3]**2+values[4]**2+values[5]**2) + 0.05*values[7]
            if np.isfinite(score) and (best is None or score < best[0]):
                best = (score, values)
                best_coeff = coeff.detach().clone()
            if epoch % 400 == 0 or epoch == 2600:
                row = dict(epoch=epoch, score=score, chi2_mse=values[0], density_mse=values[1],
                           chi4_mse=values[2], monotonic_penalty=values[6])
                history.append(row)
                print(weight, row, flush=True)
            if epoch < 2600:
                loss.backward()
                torch.nn.utils.clip_grad_norm_([model.f_net.coeff], 2.0)
                opt.step()
        model.f_net.coeff.data.copy_(best_coeff)
        path = OUT / f"Nf2_direct_f_w{weight:g}.npz"
        with torch.no_grad():
            zz = torch.linspace(0.001, 20.0, 4001, device="cuda")
            aa, ff = model.a_net(zz), model.f_net(zz)
            np.savez(path, z=zz.cpu().numpy(), A=aa.cpu().numpy(), f=ff.cpu().numpy(),
                     G=float(model.G), A_parameterization="central frozen", f_refinement="SmoothF direct chi4")
        report["fits"][str(weight)] = {"model": str(path), "score": best[0],
            "chi2_rms": math.sqrt(best[1][0]), "density_rms": math.sqrt(best[1][1]),
            "chi4_rms": math.sqrt(best[1][2]), "chi2_max": best[1][3],
            "density_max": best[1][4], "chi4_max": best[1][5], "history": history}
    (OUT / "f_refinement_report.json").write_text(json.dumps(report, indent=2) + "\n")


if __name__ == "__main__":
    main()
