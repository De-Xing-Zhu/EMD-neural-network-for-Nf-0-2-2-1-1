#!/usr/bin/env python3
"""Regenerate the Nf=2 lattice-only targets; no HRG or bridge rows."""
import csv
import re
from pathlib import Path

import numpy as np

from extract_nf2_susceptibilities import _track

DATA = Path(__file__).resolve().parents[1] / "data"
TC = 0.20476  # Datta temperature calibration used by the original analysis
P0 = 0.302    # Burger p/T^4 at 174 MeV, correlated 20% uncertainty


def write_csv(name, header, comment, rows):
    with (DATA / name).open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(header)
        stream.write("# " + comment + "\n")
        writer.writerows(rows)


def datta_points():
    source = (DATA / "source/Fig4b.eps").read_text(encoding="latin-1")
    parts = re.split(r"% Begin plot #(\d+)", source)
    bodies = {int(parts[k]): parts[k + 1] for k in range(1, len(parts), 2)}

    def markers(body, symbol):
        found = re.finditer(r"(-?[\d.]+)\s+(-?[\d.]+)\s+" + symbol + r"\b", body)
        return np.array(sorted((float(m[1]), float(m[2])) for m in found
                               if float(m[1]) < 6500))

    up, down = markers(bodies[1], "TriU"), markers(bodies[2], "TriD")
    assert len(up) == len(down) == 10 and np.array_equal(up[:, 0], down[:, 0])

    def errors(body):
        return {round(x): half_height / 9828.0 for x, _, half_height in _track(body)}

    e2, e4 = errors(bodies[1]), errors(bodies[2])
    x = up[:, 0]
    t = TC * (0.8 + (x - 770.0) / 4412.0)
    c2, c4 = (up[:, 1] - 1922.0) / 9828.0, (down[:, 1] - 1922.0) / 9828.0
    d2 = np.array([max(e2.get(round(v), 0.0), 0.02 * y)
                   for v, y in zip(x, c2)])
    d4 = np.array([max(e4.get(round(v), 0.0), 0.10 * abs(y))
                   for v, y in zip(x, c4)])
    return t, c2, d2, c4, d4


def main():
    eos = np.genfromtxt(DATA / "newSEXP_eos.csv", delimiter=",", names=True)
    assert len(eos) == 12
    write_csv("Nf2_train_s_verified.csv",
              ["T", "s_over_T3", "sigma", "kind"],
              "Burger 2015 Fig. 12(a); p0/T0^4=0.302 adds 4*p0 to s/T^3.",
              [[t, s+4*P0, ds, "lattice:Burger2015-fig12a-digitised-p0corrected"]
               for t, s, ds in zip(eos["T_GeV"], eos["s_over_T3"], eos["ds"])])
    t, c2, d2, c4, d4 = datta_points()
    write_csv("Nf2_train_chi_verified.csv",
              ["T", "chi2B", "sigma", "kind"],
              "Datta 2017 Fig. 4(b) digitised; 2% analysis error floor.",
              [[x, y, e, "lattice:Datta2017-fig4b-digitised"]
               for x, y, e in zip(t, c2, d2)])
    write_csv("Nf2_train_chi4_verified.csv",
              ["T", "chi4B", "sigma", "kind"],
              "Datta 2017 Fig. 4(b) digitised; 10% analysis error floor.",
              [[x, y, e, "lattice:Datta2017-fig4b-digitised"]
               for x, y, e in zip(t, c4, d4)])
    nb = c2 + c4/6
    dnb = np.hypot(np.hypot(d2, d4/6), .1*nb)
    write_csv("Nf2_nB_muhat1_verified.csv",
              ["T", "nB_over_T3", "dnB_tot", "method", "chi2B", "chi4B", "dchi4B"],
              "Taylor estimate at muB/T=1 from zero-mu lattice chi2 and chi4; not a direct finite-mu measurement.",
              [[x, y, e, "taylor:Datta2017-chi2+chi4/6", a, b, db]
               for x, y, e, a, b, db in zip(t, nb, dnb, c2, c4, d4)])
    print("Saved 12 EOS and 10 susceptibility LQCD targets")


if __name__ == "__main__":
    main()
