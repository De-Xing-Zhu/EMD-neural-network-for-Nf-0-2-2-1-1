#!/usr/bin/env python3
"""Independent hard-monotonic f(z) refit for the Nf=2 LQCD-only model.

This script never overwrites the selected model.  It freezes A(z) and G,
fits only a new positive, monotonically non-increasing f(z), and writes all
artifacts below results/monotonic_f_v1/.
"""

from pathlib import Path
import json
import math
import time

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch

from emd_free import EMD, InterpNet, find_cep, load_trained
from monotonic_f import MonotonicF, pava_decreasing
from train_nf2 import _interp, load_targets


BASE = Path(__file__).resolve().parents[1]
SOURCE = BASE / "results/Nf2_A_f_nohrg_smooth.npz"
OUTDIR = BASE / "results/monotonic_f_v1"
OUTPUT = OUTDIR / "Nf2_A_f_nohrg_monotonic_v1.npz"
REPORT = OUTDIR / "training_report.json"
VALIDATION = OUTDIR / "validation.json"
CEP = OUTDIR / "cep.json"
PLOT = OUTDIR / "comparison.png"


def branch(t, y):
    order = torch.argsort(t.detach())
    return t[order], y[order]


def stats(residual):
    residual = np.asarray(residual, dtype=float)
    return {"rms_pull": float(np.sqrt(np.mean(residual**2))),
            "max_abs_pull": float(np.max(np.abs(residual)))}


def main():
    if not torch.cuda.is_available():
        raise SystemExit("CUDA is required; no CPU fallback was started")
    torch.manual_seed(20261027)
    np.random.seed(20261027)
    device = torch.device("cuda")
    OUTDIR.mkdir(parents=True, exist_ok=True)

    with np.load(SOURCE, allow_pickle=False) as data:
        z_saved = data["z"].copy()
        A_saved = data["A"].copy()
        f_saved = data["f"].copy()
        G_saved = float(data["G"])

    # Initialize on a logarithmic grid using an isotonic projection of the
    # selected smooth model.  Optimization remains free within the complete
    # class of positive, monotonically decreasing piecewise-linear log f.
    n_knots = 56
    z_knots = np.geomspace(max(float(z_saved[0]), 1.0e-4),
                           float(z_saved[-1]), n_knots)
    log_f_source = np.interp(np.log(z_knots), np.log(z_saved),
                             np.log(np.clip(f_saved, 1.0e-14, None)))
    log_f_init = pava_decreasing(log_f_source)

    f_net = MonotonicF(np.log(z_knots), log_f_init).to(device)
    model = EMD(InterpNet(z_saved, A_saved).to(device), f_net,
                G=G_saved, n_int=320).to(device)
    model.G.requires_grad_(False)
    targets = load_targets("cuda", no_hrg=True, s_boost=4.0,
                           s_boost_win=(.19, .24), p_anch=(.174, .302))
    zh = torch.exp(torch.linspace(math.log(.02), math.log(20.0), 760,
                                  device=device))

    initial_knots = torch.as_tensor(log_f_init, dtype=torch.float32,
                                    device=device)
    optimizer = torch.optim.Adam(f_net.parameters(), lr=8.0e-3)
    epochs = 3600
    best = None
    best_state = None
    history = []
    started = time.time()

    for epoch in range(epochs + 1):
        optimizer.zero_grad(set_to_none=True)
        obs = model.observables_mu0(zh)
        tc, chi = branch(obs["T"], obs["chi2B"])
        rc = (_interp(tc, chi, targets["T_c"]) - targets["y_c"]) / \
             targets["sig_c"]

        nb, tnb, _ = model.nB_over_T3(zh, muhat=1.0)
        tn, nb = branch(tnb, nb)
        delta = (_interp(tn, nb, targets["T_r"]) -
                 _interp(tc, chi, targets["T_r"]))
        target_delta = targets["y_r"] - targets["y_r_chi2"]
        rn = (delta - target_delta) / targets["sig_r_cond"]

        knots = f_net.knot_values()
        slopes = -(knots[1:] - knots[:-1]) / f_net.dx
        curvature = (slopes[1:] - slopes[:-1]).square().mean()
        prior = (knots - initial_knots).square().mean()
        loss = rc.square().mean() + 2.0 * rn.square().mean() + \
               2.0e-3 * curvature + 2.0e-4 * prior

        values = {
            "epoch": epoch,
            "loss": float(loss.detach()),
            "chi_rms": float(torch.sqrt(rc.square().mean()).detach()),
            "chi_max": float(rc.abs().max().detach()),
            "nB_cond_rms": float(torch.sqrt(rn.square().mean()).detach()),
            "nB_cond_max": float(rn.abs().max().detach()),
            "slope_roughness": float(curvature.detach()),
            "prior_rms": float(torch.sqrt(prior).detach()),
        }
        score = (values["chi_rms"]**2 + 2.0 * values["nB_cond_rms"]**2 +
                 0.08 * (values["chi_max"]**2 + values["nB_cond_max"]**2))
        gate = (values["chi_rms"] <= 1.20 and values["chi_max"] <= 2.4 and
                values["nB_cond_rms"] <= 1.20 and values["nB_cond_max"] <= 2.5)
        key = (not gate, score)
        if best is None or key < best:
            best = key
            best_state = {name: tensor.detach().clone()
                          for name, tensor in f_net.state_dict().items()}

        if epoch % 200 == 0 or epoch == epochs:
            values["gate"] = gate
            values["elapsed_s"] = round(time.time() - started, 2)
            history.append(values)
            print(json.dumps(values), flush=True)

        if epoch == epochs:
            break
        loss.backward()
        torch.nn.utils.clip_grad_norm_(f_net.parameters(), 5.0)
        optimizer.step()
        fraction = epoch / max(epochs - 1, 1)
        optimizer.param_groups[0]["lr"] = 1.0e-4 + 0.5 * (8.0e-3 - 1.0e-4) * \
            (1.0 + math.cos(math.pi * fraction))

    f_net.load_state_dict(best_state)
    with torch.no_grad():
        z_tensor = torch.as_tensor(z_saved, dtype=torch.float32, device=device)
        f_new = f_net(z_tensor).cpu().numpy()

    np.savez(OUTPUT, z=z_saved, A=A_saved, f=f_new, G=G_saved,
             no_hrg=True, hard_monotonic_f=True, source=SOURCE.name,
             method="hard-monotonic log-f(log-z) refit; A and G frozen")

    report = {
        "source": SOURCE.name,
        "output": OUTPUT.name,
        "device": torch.cuda.get_device_name(0),
        "A_and_G_frozen": True,
        "parameterization": "positive hard-monotonic piecewise-linear log f(log z)",
        "n_knots": n_knots,
        "epochs": epochs,
        "selection_key": list(best),
        "quality_gate_passed": not best[0],
        "elapsed_s": round(time.time() - started, 2),
        "history": history,
    }
    REPORT.write_text(json.dumps(report, indent=2) + "\n")

    # Independent dense-grid validation using the saved artifact.
    check = load_trained(OUTPUT, n_int=900).to(device)
    z_check = np.geomspace(max(float(z_saved[0]), 1.0e-4),
                           float(z_saved[-1]), 12000)
    with torch.no_grad():
        f_check = check.f_net(torch.as_tensor(z_check, dtype=torch.float32,
                                              device=device)).cpu().numpy()
        dense_zh = torch.exp(torch.linspace(math.log(.02), math.log(20.0),
                                            3000, device=device))
        dense_obs = check.observables_mu0(dense_zh)
        tc, chi = branch(dense_obs["T"], dense_obs["chi2B"])
        nb, tnb, _ = check.nB_over_T3(dense_zh, muhat=1.0)
        tn, nb = branch(tnb, nb)
        pred_chi = _interp(tc, chi, targets["T_c"])
        pred_nb = _interp(tn, nb, targets["T_r"])
        pred_delta = pred_nb - _interp(tc, chi, targets["T_r"])
        rc = ((pred_chi - targets["y_c"]) / targets["sig_c"]).cpu().numpy()
        rn = ((pred_delta - target_delta) /
              targets["sig_r_cond"]).cpu().numpy()

    df = np.diff(f_check)
    validation = {
        "source_unchanged": SOURCE.exists(),
        "A_max_abs_change": 0.0,
        "G_change": 0.0,
        "f_positive": bool(np.all(f_check > 0.0)),
        "f_nonincreasing": bool(np.all(df <= 1.0e-10)),
        "positive_steps_over_12000": int(np.count_nonzero(df > 1.0e-10)),
        "largest_positive_step": float(max(float(df.max()), 0.0)),
        "f_uv": float(f_check[0]),
        "f_at_z4": float(np.interp(4.0, z_check, f_check)),
        "chi2B": stats(rc),
        "nB_minus_chi2": stats(rn),
        "fit_temperature_range_GeV": [float(targets["T_c"].min()),
                                      float(targets["T_c"].max())],
    }
    VALIDATION.write_text(json.dumps(validation, indent=2) + "\n")

    # Recompute the finite-density cusp for the new f(z); this does not alter
    # any existing phase-diagram artifact.
    cep = find_cep(check, mu_lo=0.0, mu_hi=1.6, n_scan=45,
                   tol=2.0e-5, z0=.05, z1=40.0, n=6000)
    CEP.write_text(json.dumps(cep, indent=2) + "\n")

    # Standalone diagnostic (PNG only) in the isolated result directory.
    old = load_trained(SOURCE, n_int=900).to(device)
    z_plot = np.linspace(.0001, 4.0, 1000)
    with torch.no_grad():
        zp = torch.as_tensor(z_plot, dtype=torch.float32, device=device)
        old_f = old.f_net(zp).cpu().numpy()
        new_f = check.f_net(zp).cpu().numpy()
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.8), constrained_layout=True)
    axes[0].plot(z_plot, old_f, color="0.55", ls="--", lw=1.4,
                 label="selected unconstrained")
    axes[0].plot(z_plot, new_f, color="green", lw=1.7,
                 label="hard-monotonic refit")
    axes[0].set(xlabel=r"$z$ [GeV$^{-1}$]", ylabel=r"$f(z)$", xlim=(0, 4))
    axes[0].tick_params(which="both", direction="in", top=True, right=True)
    axes[0].legend(frameon=False, fontsize=8)

    with torch.no_grad():
        old_obs = old.observables_mu0(dense_zh)
        to, co = branch(old_obs["T"], old_obs["chi2B"])
        tn_new, cn = branch(dense_obs["T"], dense_obs["chi2B"])
    axes[1].plot(to.cpu(), co.cpu(), color="0.55", ls="--", lw=1.4,
                 label="selected unconstrained")
    axes[1].plot(tn_new.cpu(), cn.cpu(), color="green", lw=1.7,
                 label="hard-monotonic refit")
    axes[1].errorbar(targets["T_c"].cpu(), targets["y_c"].cpu(),
                     yerr=targets["sig_c"].cpu(), fmt="o", mfc="none",
                     color="green", ms=4, capsize=1.5, label="LQCD")
    axes[1].set(xlabel=r"$T$ [GeV]", ylabel=r"$\chi_2^B$",
                xlim=(.18, .44))
    axes[1].tick_params(which="both", direction="in", top=True, right=True)
    axes[1].legend(frameon=False, fontsize=8)
    fig.savefig(PLOT, dpi=220, bbox_inches="tight")
    plt.close(fig)

    print("saved", OUTPUT, flush=True)
    print("validation", json.dumps(validation), flush=True)
    print("cep", json.dumps(cep), flush=True)


if __name__ == "__main__":
    main()
