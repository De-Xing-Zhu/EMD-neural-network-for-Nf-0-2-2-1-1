#!/usr/bin/env python3
"""Low-capacity smooth f(z) refinement for the HRG-free Nf=2 fit."""

from pathlib import Path
import argparse
import json
import math

import numpy as np
import torch
from torch import nn

from emd_free import EMD, InterpNet
from train_nf2 import _interp, load_targets

BASE = Path(__file__).resolve().parents[1]


class SmoothF(nn.Module):
    def __init__(self, z, f, n_centers=28):
        super().__init__()
        self.base = InterpNet(z, f)
        centers = torch.linspace(math.log(.45), math.log(8.), n_centers)
        self.register_buffer("centers", centers)
        self.width = 1.8 * float(centers[1] - centers[0])
        self.coeff = nn.Parameter(torch.zeros(n_centers))

    def forward(self, z):
        x = z.reshape(-1).clamp_min(1e-8)
        b = torch.exp(-.5*((torch.log(x)[:, None]-self.centers[None, :]) /
                           self.width)**2)
        return self.base(x) * torch.exp(.50*torch.tanh(b @ self.coeff))


def branch(t, y):
    order = torch.argsort(t.detach())
    return t[order], y[order]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path,
                        default=BASE/"results/Nf2_A_f_nohrg_fast_seed50.npz")
    parser.add_argument("--output", type=Path,
                        default=BASE/"results/Nf2_A_f_nohrg_smooth.npz")
    parser.add_argument("--selection", type=Path,
                        default=BASE/"results/nohrg_smooth_selection.json")
    parser.add_argument("--chi-file", default="Nf2_train_chi_verified.csv")
    parser.add_argument("--rho-file", default="Nf2_nB_muhat1_verified.csv")
    parser.add_argument("--epochs", type=int, default=2600)
    args = parser.parse_args()
    if not torch.cuda.is_available():
        raise SystemExit("CUDA unavailable; no CPU refinement started")
    with np.load(args.source, allow_pickle=False) as d:
        z, A, f, G = (d[k].copy() for k in ("z", "A", "f", "G"))
    model = EMD(InterpNet(z, A), SmoothF(z, f), G=float(G),
                n_int=300).cuda()
    model.G.requires_grad_(False)
    D = load_targets("cuda", no_hrg=True, s_boost=4.,
                     s_boost_win=(.19, .24), p_anch=(.174, .302),
                     chi_file=args.chi_file, rho_file=args.rho_file)
    zh = torch.exp(torch.linspace(math.log(.02), math.log(20.), 700,
                                  device="cuda"))
    opt = torch.optim.Adam([model.f_net.coeff], lr=.006)
    history, best, best_coeff = [], (True, float("inf")), None
    epochs = args.epochs
    for ep in range(epochs+1):
        opt.zero_grad(set_to_none=True)
        o = model.observables_mu0(zh)
        tc, chi = branch(o["T"], o["chi2B"])
        rc = (_interp(tc, chi, D["T_c"])-D["y_c"])/D["sig_c"]
        nb, tnb, _ = model.nB_over_T3(zh, muhat=1.)
        tn, nb = branch(tnb, nb)
        delta = _interp(tn, nb, D["T_r"])-_interp(tc, chi, D["T_r"])
        rn = (delta-(D["y_r"]-D["y_r_chi2"]))/D["sig_r_cond"]

        # Monotonicity is imposed only over the measured interval.  It rules
        # out point-to-point waves without assuming an extrapolation outside.
        mc = (tc[:-1] >= .185) & (tc[1:] <= .435)
        mn = (tn[:-1] >= .185) & (tn[1:] <= .435)
        sc = (chi[1:]-chi[:-1])/(tc[1:]-tc[:-1]).clamp_min(1e-7)
        sn = (nb[1:]-nb[:-1])/(tn[1:]-tn[:-1]).clamp_min(1e-7)
        mono = torch.relu(-sc[mc]).square().mean() + \
            torch.relu(-sn[mn]).square().mean()
        c = model.f_net.coeff
        smooth = (c[2:]-2*c[1:-1]+c[:-2]).square().mean()
        reg = .02*c.square().mean() + .15*smooth
        loss = rc.square().mean() + 2.*rn.square().mean() + 50.*mono + reg

        vals = (float(torch.sqrt(rc.square().mean()).detach()),
                float(rc.abs().max().detach()),
                float(torch.sqrt(rn.square().mean()).detach()),
                float(rn.abs().max().detach()), float(mono.detach()),
                float(smooth.detach()))
        gate = (vals[0] <= 1.05 and vals[1] <= 2.0 and
                vals[2] <= 1.10 and vals[3] <= 2.2 and vals[4] <= 1e-8)
        score = vals[0]**2 + vals[2]**2 + .08*(vals[1]**2+vals[3]**2) + \
            2.*vals[4] + .05*vals[5]
        key = (not gate, score)
        if key < best:
            best, best_coeff = key, c.detach().clone()
        if ep % 200 == 0 or ep == epochs:
            row = dict(epoch=ep, chi_rms=vals[0], chi_max=vals[1],
                       nB_cond_rms=vals[2], nB_cond_max=vals[3],
                       monotonic_penalty=vals[4], coeff_roughness=vals[5],
                       gate=gate)
            history.append(row); print(row, flush=True)
        if ep == epochs:
            break
        loss.backward()
        torch.nn.utils.clip_grad_norm_([c], 2.)
        opt.step()
        frac = ep/max(epochs-1, 1)
        opt.param_groups[0]["lr"] = 1e-4+.5*(.006-1e-4)*(
            1+math.cos(math.pi*frac))

    with torch.no_grad():
        model.f_net.coeff.copy_(best_coeff)
        fnew = model.f_net(torch.tensor(z, device="cuda")).cpu().numpy()
    np.savez(args.output, z=z, A=A, f=fnew, G=G, no_hrg=True,
             source=args.source.name,
             method="low-capacity monotonic smooth f refinement")
    report = dict(source=args.source.name, model=args.output.name,
                  chi_file=args.chi_file, rho_file=args.rho_file,
                  quality_gate_passed=not best[0], selected_key=best,
                  history=history)
    args.selection.write_text(json.dumps(report, indent=2)+"\n")
    print("saved", args.output, "gate", not best[0], flush=True)


if __name__ == "__main__":
    main()
