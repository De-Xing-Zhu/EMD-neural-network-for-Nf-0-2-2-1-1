#!/usr/bin/env python3
"""Select the isolated 140 MeV HRG-cutoff experiment."""

from pathlib import Path
import argparse
import json
import shutil
import subprocess
import sys

from evaluate_nf2_eosfit import evaluate
from plot_nf2_eos_verified import load_hrg, load_lattice
from train_nf2 import load_targets

BASE = Path(__file__).resolve().parents[1]
RESULTS = BASE / "results"
HRG_END = .140


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, nargs="+", required=True)
    args = ap.parse_args()
    hrg, lat = load_hrg(HRG_END), load_lattice()
    target = load_targets(
        "cpu", bridge_s_frac=.02, s_boost=4.0,
        p_anch=(float(hrg["T"][0]), float(hrg["p"][0])),
        eos_fit=True, hrg_end=HRG_END)
    paths = [RESULTS / f"Nf2_A_f_hrg140_seed{seed}.npz"
             for seed in args.seeds]
    for path in paths:
        if not path.is_file():
            raise FileNotFoundError(path)
    ranking = sorted((evaluate(path, target, lat, hrg) for path in paths),
                     key=lambda x: (not x["quality_gate_passed"], x["score"]))
    for item in ranking:
        print(item["file"], f"score={item['score']:.3f}",
              "EOS RMS", {k: round(item[f"{k}_rms_pull"], 3)
                          for k in ("s", "p", "e", "I")},
              "HRG max", {k: round(item[f"{k}_hrg_max_rel"], 3)
                           for k in ("s", "p", "e", "I")},
              "bridge max", {k: round(item[f"{k}_bridge_max_rel"], 3)
                              for k in ("s", "p", "e", "I")},
              "gate", item["quality_gate_passed"], flush=True)
    winner = ranking[0]
    seed = int(winner["file"].split("_seed")[-1].split(".")[0])
    for stem, ext in (("Nf2_A_f", ".npz"),
                      ("Nf2_A_f_mu0only", ".npz"),
                      ("Nf2_history", ".json")):
        shutil.copy2(RESULTS / f"{stem}_hrg140_seed{seed}{ext}",
                     RESULTS / f"{stem}_hrg140{ext}")
    payload = {"winning_seed": seed, "hrg_end_GeV": HRG_END,
               "quality_gate_passed": winner["quality_gate_passed"],
               "ranking": ranking}
    (RESULTS / "hrg140_selection.json").write_text(
        json.dumps(payload, indent=2) + "\n")
    subprocess.run([sys.executable, str(BASE / "code" /
                                    "plot_nf2_eos_verified.py"),
                    "--tag", "_hrg140", "--hrg-end", str(HRG_END)],
                   cwd=BASE, check=True)
    subprocess.run([sys.executable, str(BASE.parent / "paper_3flavors" /
                                    "notebooks" / "plot_eos_nf2_verified.py"),
                    "--tag", "_hrg140", "--hrg-end", str(HRG_END)],
                   cwd=BASE, check=True)
    print("selected seed", seed, "quality gate",
          winner["quality_gate_passed"], flush=True)


if __name__ == "__main__":
    main()
