#!/usr/bin/env python3
"""Interpolate the Nf=2 susceptibility targets onto 20 PCHIP nodes."""

import csv
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy.interpolate import PchipInterpolator

BASE = Path(__file__).resolve().parents[1]
DATA = BASE / "data"
FIGURES = BASE / "figures"
N_NODES = 20


def read_csv(path):
    with path.open(newline="") as stream:
        reader = csv.reader(line for line in stream if not line.startswith("#"))
        header = next(reader)
        rows = list(reader)
    values = np.asarray(rows, dtype=str)
    return header, np.asarray(values[:, 0], dtype=float), values


def write_csv(name, header, comment, rows):
    with (DATA / name).open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(header)
        stream.write("# " + comment + "\n")
        writer.writerows(rows)


def main():
    _, t2, raw2 = read_csv(DATA / "Nf2_train_chi_verified.csv")
    _, t4, raw4 = read_csv(DATA / "Nf2_train_chi4_verified.csv")
    if not np.array_equal(t2, t4):
        raise ValueError("chi2 and chi4 source temperatures differ")
    c2 = np.asarray(raw2[:, 1], dtype=float)
    d2 = np.asarray(raw2[:, 2], dtype=float)
    c4 = np.asarray(raw4[:, 1], dtype=float)
    d4 = np.asarray(raw4[:, 2], dtype=float)

    t = np.linspace(t2[0], t2[-1], N_NODES)
    c2i = PchipInterpolator(t2, c2)(t)
    c4i = PchipInterpolator(t4, c4)(t)
    d2i = PchipInterpolator(t2, d2)(t)
    d4i = PchipInterpolator(t4, d4)(t)
    nbi = c2i + c4i / 6.0
    dnbi = np.hypot(np.hypot(d2i, d4i / 6.0), 0.1 * nbi)

    scale2 = np.sqrt(np.sum(d2i**-2) / np.sum(d2**-2))
    scale4 = np.sqrt(np.sum(d4i**-2) / np.sum(d4**-2))
    scalen = np.sqrt(np.sum(dnbi**-2) /
                     np.sum((np.hypot(np.hypot(d2, d4/6.0),
                                      0.1*(c2+c4/6.0)))**-2))
    d2i *= scale2
    d4i *= scale4
    dnbi *= scalen

    comment = (
        "20 synthetic PCHIP nodes interpolated from 10 Datta 2017 points; "
        "not independent lattice data; uncertainties rescaled to preserve total weight."
    )
    write_csv(
        "Nf2_train_chi_interpolated20.csv",
        ["T", "chi2B", "sigma", "kind"], comment,
        zip(t, c2i, d2i, ["lattice:interpolated-pchip20-Datta2017"] * N_NODES),
    )
    write_csv(
        "Nf2_train_chi4_interpolated20.csv",
        ["T", "chi4B", "sigma", "kind"], comment,
        zip(t, c4i, d4i, ["lattice:interpolated-pchip20-Datta2017"] * N_NODES),
    )
    write_csv(
        "Nf2_nB_muhat1_interpolated20.csv",
        ["T", "nB_over_T3", "dnB_tot", "method", "chi2B", "chi4B", "dchi4B"],
        comment + " nB=chi2B+chi4B/6 at muB/T=1.",
        zip(t, nbi, dnbi,
            ["taylor-pchip20:chi2+chi4/6"] * N_NODES, c2i, c4i, d4i),
    )

    metadata = {
        "source_points": len(t2),
        "interpolated_nodes": N_NODES,
        "method": "PCHIP on a uniform temperature grid within the measured range",
        "independent_lattice_points": len(t2),
        "temperature_range_GeV": [float(t[0]), float(t[-1])],
        "uncertainty_scale_factors": {
            "chi2B": float(scale2), "chi4B": float(scale4), "nB": float(scalen),
        },
        "note": "Synthetic interpolation adds no independent lattice information.",
    }
    (DATA / "Nf2_interpolation20.json").write_text(
        json.dumps(metadata, indent=2) + "\n")

    plt.rcParams.update({"font.size": 9, "axes.labelsize": 10,
                         "legend.fontsize": 8, "figure.dpi": 150})
    fig, axes = plt.subplots(1, 3, figsize=(12, 3.4), constrained_layout=True)
    panels = [
        (axes[0], c2, c2i, r"$\chi_2^B$"),
        (axes[1], c4, c4i, r"$\chi_4^B$"),
        (axes[2], c2+c4/6.0, nbi, r"$n_B/T^3\;(\mu_B/T=1)$"),
    ]
    for ax, original, interpolated, ylabel in panels:
        ax.plot(t2, original, "o", color="black", ms=5,
                label="Original lattice points (10)")
        ax.plot(t, interpolated, "-", color="tab:blue", lw=1.4,
                label="PCHIP trend")
        ax.plot(t, interpolated, "s", color="tab:red", ms=4,
                label="Interpolated nodes (20)")
        ax.set(xlabel="$T$ [GeV]", ylabel=ylabel, xlim=(0.184, 0.432))
        ax.grid(alpha=0.2)
    axes[0].legend(frameon=False, loc="lower right")
    fig.suptitle("$N_f=2$ susceptibility interpolation; no new independent data")
    fig.savefig(FIGURES / "susceptibility_interpolation20.png", dpi=180)
    fig.savefig(FIGURES / "susceptibility_interpolation20.pdf")
    print(json.dumps(metadata, indent=2))


if __name__ == "__main__":
    main()
