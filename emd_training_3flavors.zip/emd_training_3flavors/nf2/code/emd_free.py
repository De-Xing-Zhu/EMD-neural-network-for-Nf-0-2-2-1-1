#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
emd_free.py -- self-contained EMD forward model with FREE A(z), f(z),
including the finite-baryon-density sector and the CEP (swallow-tail) tools.

Neural-network parameterisation of the holographic Einstein-Maxwell-Dilaton
background (generalisation of Chen & Huang, arXiv:2405.06179).  Everything the
training and the plots need lives here: networks, thermodynamics at mu=0 and at
mu != 0, and the phase-boundary machinery.

mu = 0 observables (I1, I2 below):
    T(zh)   = zh^3 e^{-3A(zh)} / (4 pi I1)
    s/T^3   = [e^{3A(zh)} / (4 G zh^3)] / T^3
    chi_2^B = 1 / (16 pi G I2 T^2)

finite mu (exact in mu^2 in this model):
    T(zh,mu) = T(zh,0) [1 - (mu/I2)^2 (I1 I2 - I4)]
    rho      = mu / (16 pi G I2)     => n_B/T^3 = rho / T^3
The line mu_B = muhat * T needs a scalar fixed point per zh (damped iteration).

CEP: at fixed mu the curve T(zh,mu) develops a swallow tail above the CEP;
coexistence is where the two stable branches have equal omega = -int s dT.
"""

import numpy as np
import torch
import torch.nn as nn

PI = float(np.pi)


# ===================================================================== networks
class A_net(nn.Module):
    """A(z): A(0)=0, A<0, with an unconstrained IR slope.

    form='constrained'/'sigmoid':  A(z) = -sigmoid(net(z)) * z   (default)
    form='uvsafe':                A(z) = -sigmoid(net(z)) * z * z^2/(z^2+z_UV^2),
        which enforces A = O(z^2) and a finite phi'^2 at z -> 0
    form='softplus':              A(z) = -softplus(net(z)) * z**2
    form='free':                  A(z) =  net(z) * z**2
    """

    def __init__(self, hidden=32, depth=3, act="tanh", form="constrained"):
        super().__init__()
        Act = {"tanh": nn.Tanh, "silu": nn.SiLU, "gelu": nn.GELU}[act]
        layers, d = [], 1
        for _ in range(depth):
            layers += [nn.Linear(d, hidden), Act()]
            d = hidden
        layers += [nn.Linear(d, 1)]
        self.net = nn.Sequential(*layers)
        self.softplus = nn.Softplus()
        self.form = form

    def forward(self, z):
        squeeze = z.dim() == 1
        zz = z.unsqueeze(-1) if squeeze else z
        if self.form == "uvsafe":
            z_uv = 0.05
            out = -torch.sigmoid(self.net(zz)) * zz * zz**2 / (zz**2 + z_uv**2)
        elif self.form in ("constrained", "sigmoid"):
            out = -torch.sigmoid(self.net(zz)) * zz
        elif self.form == "softplus":
            out = -self.softplus(self.net(zz)) * zz**2
        else:
            out = self.net(zz) * zz**2
        return out.squeeze(-1) if squeeze else out


class F_net(nn.Module):
    """f(z) > 0 by construction:  f = exp(net(z))."""

    def __init__(self, hidden=32, depth=3, act="tanh"):
        super().__init__()
        Act = {"tanh": nn.Tanh, "silu": nn.SiLU, "gelu": nn.GELU}[act]
        layers, d = [], 1
        for _ in range(depth):
            layers += [nn.Linear(d, hidden), Act()]
            d = hidden
        layers += [nn.Linear(d, 1)]
        self.net = nn.Sequential(*layers)

    def forward(self, z):
        squeeze = z.dim() == 1
        zz = z.unsqueeze(-1) if squeeze else z
        out = torch.exp(self.net(zz))
        return out.squeeze(-1) if squeeze else out


class ClosureF(nn.Module):
    def __init__(self, a_net, f0=1.0, zmin=1e-4, zmax=20.0, n_grid=2048):
        super().__init__()
        self.a_net = a_net
        self.log_f0 = nn.Parameter(torch.tensor(float(np.log(f0))))
        self.register_buffer("z_grid", torch.linspace(zmin, zmax, n_grid))

    def forward(self, z):
        with torch.enable_grad():
            zg = self.z_grid.detach().clone().requires_grad_(True)
            A = self.a_net(zg)
            A1 = torch.autograd.grad(A.sum(), zg, create_graph=True)[0]
        q1 = zg**3 * torch.exp(-3*A)
        h = zg[1]-zg[0]
        inc = torch.empty_like(q1[1:])
        inc[0:-1:2] = h/3*(1.25*q1[:-3:2]+2*q1[1:-2:2]-0.25*q1[2:-1:2])
        inc[1:-1:2] = h/3*(1.25*q1[2:-1:2]+2*q1[1:-2:2]-0.25*q1[:-3:2])
        inc[-1] = h/3*(1.25*q1[-1]+2*q1[-2]-0.25*q1[-3])
        I1 = torch.cat([torch.zeros(1, device=zg.device), torch.cumsum(inc, dim=0)])
        denominator = (1-zg*A1).clamp_min(1e-6)
        values = 4*torch.exp(self.log_f0+5*A)*I1/(zg**4*denominator)
        values = torch.cat([torch.exp(self.log_f0).reshape(1), values[1:]])
        xx = z.reshape(-1).clamp(self.z_grid[0], self.z_grid[-1])
        idx = torch.searchsorted(self.z_grid.detach(), xx.detach()).clamp(1, self.z_grid.numel()-1)
        weight = ((xx-self.z_grid[idx-1])/(self.z_grid[idx]-self.z_grid[idx-1])).clamp(0, 1)
        return values[idx-1]+weight*(values[idx]-values[idx-1])


# ==================================================================== the model
class EMD(nn.Module):
    def __init__(self, a_net, f_net, G=0.885, G_range=(0.05, 2.0),
                 z0=0.0, n_int=200):
        super().__init__()
        self.a_net = a_net
        self.f_net = f_net
        self.G = nn.Parameter(torch.tensor(float(G)))
        self.G_range = G_range
        self.z0 = float(z0)
        self.n_int = int(n_int)

    def clamp_G(self):
        with torch.no_grad():
            self.G.clamp_(*self.G_range)

    def device(self):
        return self.G.device

    def _grid(self, zh):
        t = torch.linspace(0.0, 1.0, self.n_int,
                           device=zh.device, dtype=zh.dtype).unsqueeze(0)
        return zh.unsqueeze(1) * t

    @staticmethod
    def _cumtrapz(y, dz):
        inc = 0.5 * (y[:, 1:] + y[:, :-1]) * dz.unsqueeze(1)
        out = torch.zeros_like(y)
        out[:, 1:] = torch.cumsum(inc, dim=1)
        return out

    def integrals(self, zh):
        """I1, I2, I4, A(zh) as [B] tensors."""
        zh = zh.to(self.device())
        B = zh.shape[0]
        z = self._grid(zh)
        dz = (zh - self.z0 * torch.ones_like(zh)) / (self.n_int - 1)
        zf = z.reshape(-1, 1)
        A = self.a_net(zf).reshape(B, self.n_int)
        f = self.f_net(zf).reshape(B, self.n_int).clamp_min(1e-8)
        g1 = z ** 3 * torch.exp(-3.0 * A)
        g2 = z / (torch.exp(A) * f)
        u1 = self._cumtrapz(g1, dz)
        u2 = self._cumtrapz(g2, dz)
        u3 = self._cumtrapz(g1 * u2, dz)
        return u1[:, -1].clamp_min(1e-14), u2[:, -1].clamp_min(1e-14), \
            u3[:, -1], A[:, -1]

    def observables_mu0(self, zh):
        """T, s/T^3, chi_2^B from ONE integral evaluation."""
        I1, I2, _, Azh = self.integrals(zh)
        T = (zh ** 3 * torch.exp(-3.0 * Azh) / (4.0 * PI * I1)).clamp_min(1e-8)
        S = torch.exp(3.0 * Azh) / (4.0 * self.G * zh ** 3)
        return dict(T=T, s_over_T3=S / T ** 3,
                    chi2B=(1.0 / (16.0 * PI * self.G * I2 * T ** 2))
                    .clamp_min(1e-14))

    def susceptibilities_mu0(self, zh):
        """chi_2^B and chi_4^B at fixed T on a z_h grid.

        If T(z,mu)=T0(z)[1-C(z)mu^2] and rho=mu*q(z), the horizon shift at
        fixed T is z2=T0*C/T0'.  Thus chi4/6=q'*z2.  q' follows exactly
        from I2'=z/(exp(A)f).  Only T0' is differenced on the supplied grid.
        """
        I1, I2, I4, Azh = self.integrals(zh)
        T = zh ** 3 * torch.exp(-3.0 * Azh) / (4.0 * PI * I1)
        q = 1.0 / (16.0 * PI * self.G * I2)
        fzh = self.f_net(zh).reshape(-1).clamp_min(1e-8)
        I2prime = zh / (torch.exp(Azh) * fzh)
        qprime = -q * I2prime / I2
        Tprime = torch.cat(((T[1:2] - T[:1]) / (zh[1:2] - zh[:1]),
                            (T[2:] - T[:-2]) / (zh[2:] - zh[:-2]),
                            (T[-1:] - T[-2:-1]) / (zh[-1:] - zh[-2:-1])))
        C = (I1 * I2 - I4) / I2 ** 2
        chi4 = 6.0 * qprime * T * C / Tprime
        return T, q / T ** 2, chi4

    # ---------------------------------------------------------------- finite mu
    def T_mu(self, zh, mu):
        """T(zh, mu) = T(zh,0) [1 - (mu/I2)^2 (I1 I2 - I4)].  Exact in mu^2."""
        mu = torch.as_tensor(mu, dtype=torch.float32, device=self.device())
        I1, I2, I4, Azh = self.integrals(zh)
        base = zh ** 3 * torch.exp(-3.0 * Azh) / (4.0 * PI * I1)
        return (base * (1.0 - (mu / I2) ** 2 * (I1 * I2 - I4))).clamp_min(1e-8)

    def solve_mu_eq_T(self, zh, muhat=1.0, n_iter=40, tol=1e-10):
        """Solve mu_B = muhat * T(zh, mu_B) per zh.  Returns (mu, T, I2)."""
        I1, I2, I4, Azh = self.integrals(zh)
        base = zh ** 3 * torch.exp(-3.0 * Azh) / (4.0 * PI * I1)
        corr = (I1 * I2 - I4) / I2 ** 2
        mu = (muhat * base).clamp_min(1e-9)
        for _ in range(n_iter):
            T = (base * (1.0 - corr * mu ** 2)).clamp_min(1e-8)
            new = (muhat * T).clamp_min(1e-9)
            if torch.max(torch.abs(new - mu)) < tol:
                mu = new
                break
            mu = 0.5 * mu + 0.5 * new
        T = (base * (1.0 - corr * mu ** 2)).clamp_min(1e-8)
        return mu, T, I2

    def nB_over_T3(self, zh, muhat=1.0):
        """n_B/T^3 on the mu_B = muhat * T line."""
        mu, T, I2 = self.solve_mu_eq_T(zh, muhat)
        rho = mu / (16.0 * PI * self.G * I2)
        return (rho / T ** 3).clamp_min(1e-14), T, mu

    # ------------------------------------------------------------- consistency
    def phi_prime_sq(self, z):
        """phi'^2 = 6 (A'^2 - A'' - 2 A'/z), must be >= 0."""
        z = z.to(self.device()).detach().clone().requires_grad_(True)
        A = self.a_net(z)
        A1 = torch.autograd.grad(A.sum(), z, create_graph=True)[0]
        A2 = torch.autograd.grad(A1.sum(), z, create_graph=True)[0]
        return 6.0 * (A1 ** 2 - A2 - 2.0 * A1 / z)

    @torch.no_grad()
    def export_functions(self, z):
        zz = torch.as_tensor(z, dtype=torch.float32, device=self.device())
        return (self.a_net(zz).cpu().numpy().ravel(),
                self.f_net(zz).cpu().numpy().ravel(),
                float(self.G.detach().cpu()))


# ------------------------------------------------- loading a trained model
class InterpNet(nn.Module):
    """Linear-interpolation wrapper around a saved (z, y) table."""

    def __init__(self, z, y):
        super().__init__()
        self.register_buffer("z", torch.as_tensor(z, dtype=torch.float32))
        self.register_buffer("y", torch.as_tensor(y, dtype=torch.float32))

    def forward(self, x):
        xx = x.reshape(-1).clamp(self.z[0], self.z[-1])
        i = torch.searchsorted(self.z.detach(), xx.detach()).clamp(
            1, self.z.numel() - 1)
        w = ((xx - self.z[i - 1]) / (self.z[i] - self.z[i - 1])
             .clamp_min(1e-12)).clamp(0, 1)
        return self.y[i - 1] + w * (self.y[i] - self.y[i - 1])


def load_trained(npz_path, n_int=1500):
    """Rebuild the EMD model from a saved results/<flavor>_A_f.npz file."""
    d = np.load(npz_path, allow_pickle=True)
    m = EMD(InterpNet(d["z"], d["A"]), InterpNet(d["z"], d["f"]),
            G=float(d["G"]), n_int=n_int)
    m.eval()
    return m


@torch.no_grad()
def emd_mu0_curve(model, zmin=0.02, zmax=30.0, n=4000):
    """The STABLE black-hole branch: (T, s/T^3, zh), T ascending."""
    dev = model.device()
    zh = torch.exp(torch.linspace(np.log(zmin), np.log(zmax), n, device=dev))
    o = model.observables_mu0(zh)
    T = o["T"].detach().cpu().numpy()
    s = o["s_over_T3"].detach().cpu().numpy()
    zhn = zh.detach().cpu().numpy()
    good = np.isfinite(T) & np.isfinite(s) & (T > 0)
    if not good.all():
        i0 = int(np.argmax(good)) if good.any() else 0
        T, s, zhn = T[i0:], s[i0:], zhn[i0:]
    dT = np.diff(T)
    turn = np.where(dT > 0)[0]           # T must decrease along the branch
    if len(turn):
        k = turn[0] + 1
        T, s, zhn = T[:k], s[:k], zhn[:k]
    return T[::-1], s[::-1], zhn[::-1]


# ============================================================ CEP / phase line
T_FLOOR = 0.02          # GeV; below this T(zh) turning points are numerical


@torch.no_grad()
def curve_mu(model, mu, z0=0.05, z1=40.0, n=4000):
    """zh, T, s, rho along the fixed-mu curve (ALL branches kept)."""
    dev = model.device()
    zh = torch.exp(torch.linspace(np.log(z0), np.log(z1), n, device=dev))
    I1, I2, I4, Azh = model.integrals(zh)
    mu_t = torch.as_tensor([float(mu)], device=dev)
    base = zh ** 3 * torch.exp(-3.0 * Azh) / (4.0 * np.pi * I1)
    T = base * (1.0 - (mu_t / I2) ** 2 * (I1 * I2 - I4))
    s = torch.exp(3.0 * Azh) / (4.0 * model.G * zh ** 3)
    rho = mu_t / (16.0 * np.pi * model.G * I2)
    # float64: omega = -int s dT accumulates a large constant (the curve starts
    # at T ~ 16 GeV), and the coexistence signal is ~1e-4 -- float32 cumsum
    # rounds it away entirely (ulp(3e3) ~ 2e-4 in fp32).
    return (zh.detach().cpu().numpy().astype(np.float64),
            T.detach().cpu().numpy().astype(np.float64),
            s.detach().cpu().numpy().astype(np.float64),
            rho.detach().cpu().numpy().astype(np.float64))


def turning_points(T, T_floor=T_FLOOR):
    """Indices where dT/dz_h changes sign, ignoring the T<floor artefact."""
    m = T > T_floor
    idx = np.where(m)[0]
    if len(idx) < 3:
        return np.array([], dtype=int)
    Ti = T[idx]
    sgn = np.sign(np.diff(Ti))
    ch = np.where(np.diff(sgn) != 0)[0]
    return idx[ch + 1]


def omega_of_curve(T, s):
    """omega = -int s dT along the curve, cumulative (constant irrelevant)."""
    w = np.zeros_like(T)
    w[1:] = -np.cumsum(0.5 * (s[1:] + s[:-1]) * np.diff(T))
    return w


def coexistence(mu, model, **kw):
    """(T_coex, T_upper, T_lower, dS) at given mu, or None (crossover)."""
    zh, T, s, rho = curve_mu(model, mu, **kw)
    tp = turning_points(T)
    if len(tp) < 2:
        return None
    i1, i2 = tp[0], tp[1]
    w = omega_of_curve(T, s)
    TA, wA, sA = T[:i1 + 1], w[:i1 + 1], s[:i1 + 1]
    TC, wC, sC = T[i2:], w[i2:], s[i2:]
    lo = max(TA.min(), TC.min())
    hi = min(TA.max(), TC.max())
    if not (hi > lo):
        return None
    Tgrid = np.linspace(lo, hi, 800)
    oA = np.interp(Tgrid, TA[::-1], wA[::-1])
    oC = np.interp(Tgrid, TC[::-1], wC[::-1])   # TC is zh-ordered (T descending)
    dd = oA - oC
    k = np.where(np.diff(np.sign(dd)) != 0)[0]
    if len(k) == 0:
        return None
    k = k[0]
    x0, x1 = Tgrid[k], Tgrid[k + 1]
    y0, y1 = dd[k], dd[k + 1]
    Tco = x0 - y0 * (x1 - x0) / (y1 - y0) if y1 != y0 else 0.5 * (x0 + x1)
    sA_T = np.interp(Tco, TA[::-1], sA[::-1])
    sC_T = np.interp(Tco, TC[::-1], sC[::-1])
    return dict(T_coex=float(Tco), T_upper=float(T[i1]), T_lower=float(T[i2]),
                dS=float(abs(sA_T - sC_T) / Tco ** 3), mu=float(mu))


def find_cep(model, mu_lo=0.0, mu_hi=1.6, n_scan=40, tol=1e-4, **kw):
    """Smallest mu at which the T(zh) swallow tail appears (the CEP)."""
    def has_pair(mu):
        return len(turning_points(curve_mu(model, mu, **kw)[1])) >= 2

    mu_a, mu_b = None, None
    for mu in np.linspace(mu_lo, mu_hi, n_scan):
        if has_pair(mu):
            mu_b = float(mu)
            break
    if mu_b is None:
        return dict(cep_found=False,
                    note="no swallow tail up to mu_B = %.2f GeV" % mu_hi)
    mu_a = mu_b - (mu_hi - mu_lo) / (n_scan - 1)
    while mu_b - mu_a > tol:
        mu_m = 0.5 * (mu_a + mu_b)
        if has_pair(mu_m):
            mu_b = mu_m
        else:
            mu_a = mu_m
    zh, T, s, rho = curve_mu(model, mu_b, **kw)
    tp = turning_points(T)
    T_cep = float(np.mean(T[tp[:2]])) if len(tp) >= 2 else float("nan")
    return dict(cep_found=True, mu_CEP=float(mu_b), T_CEP=T_cep,
                mu_bracket=(float(mu_a), float(mu_b)),
                coexistence=coexistence(mu_b, model, **kw))
