#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
train_nf2.py -- train A(z), f(z), G of the EMD model on Nf=2 lattice data
(s/T^3 + chi_B^2 at mu=0, then n_B/T^3 at mu_B/T = 1), for the standalone
Nf=2 package.  See plot_nf2.py for the EOS comparison and the CEP.

INPUT   data/Nf2_train_s_verified.csv      T, s_over_T3, sigma, kind
                                  kind 'adapted-HRG...' = low-T model anchor
                                  (treated with a 5 % model tolerance, not as
                                  exact data); kind 'lattice:tmfT...' = data
        data/Nf2_train_chi_verified.csv    T, chi2B, sigma, kind   (Datta 2017 lattice
                                  + adapted-HRG anchor)
        data/Nf2_nB_muhat1_verified.csv    T, n_B/T^3, dnB_tot at mu_B/T = 1
                                  (Taylor extrapolation of Datta 2017 chi_2,
                                  chi_4 -- NOT a finite-mu simulation)

MODEL   A(z) = A_net(z), f(z) = F_net(z), scalar G (8 pi G_5), clamp [0.05, 2]
        --monotonic_f instead uses positive, non-increasing log f(log z)

LOSS    phase 1 (mu = 0):  L = L_s + L_c + w_reg L_reg + 1e-3 L_phi
        optional phase 1b: add w_I L_I with --phase1b > 0
        phase 2 (+ n_B):   L += w(ep) * L_r / L_r(0)   (normalised self-ramp,
                           w ramps 0 -> 1 over rho_warmup of the phase)
        L_s, L_c : squared pulls of s/T^3 and chi_B^2 against digitised
                   band/bar widths and declared model tolerances
                   (EMD forward on a fixed z_h grid, differentiable interp)
        L_I      : chi^2 of I/T^4 = s - 4p against the digitised tmfT band
                   (p from trapezoid integration of the model s, anchored
                   to the published p0 = 0.302 at 174 MeV; --wI 0 disables)
                   With --eos_fit, this logged term is a weighted p, epsilon,
                   I objective; --p_anch can instead anchor p to HRG at 80 MeV.
        L_r      : conditional squared pull of n_B/T^3-chi_2^B on the
                   mu_B = T line, isolating chi_4/6 and avoiding double count
        L_reg    : second-difference smoothness of A and log f
        L_phi    : mean relu(-phi'^2), phi'^2 = 6(A'^2 - A'' - 2A'/z) >= 0

OPTIMISATION  warm start to the CH Table-1 Nf=2 analytic background
              (a,b,c,d,k = 0.067, 0.023, -0.377, -0.382, 0), Adam, cosine LR,
              EMA best-state selection, --seeds independent runs (best kept).

OUTPUT  results/Nf2_A_f_verified.npz          final model
        results/Nf2_A_f_mu0only_verified.npz  phase-1 model
        results/Nf2_history_verified.json     loss history

Usage:  python3 code/train_nf2.py                 # 3 seeds, 6000 + 3000 epochs
        python3 code/train_nf2.py --phase1 4000 --phase2 1500 --seeds 1
"""

import os
import sys
import json
import time
import math
import argparse

import numpy as np
import torch
from scipy.interpolate import PchipInterpolator

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from emd_free import EMD, A_net, F_net, ClosureF           # noqa: E402
from monotonic_f import MonotonicF, SmoothMonotonicF, pava_decreasing  # noqa: E402

DATA = os.path.join(BASE, "data")
RESULTS = os.path.join(BASE, "results")

# Chen & Huang Table 1, Nf=2 (arXiv:2405.06179)
CH_NF2 = dict(a=0.067, b=0.023, c=-0.377, d=-0.382, k=0.0)
HRG_END = 0.150

HRG_PREFIXES = ("hrg", "adapted", "glueball")


def _is_hrg(kind):
    return str(kind).lower().startswith(HRG_PREFIXES)


# ------------------------------------------------------------------- warm start
def pretrain_background(a_net, f_net, device, steps=1500, lr=1e-3, n=512):
    """Fit A_net, F_net to the analytic CH Nf=2 background."""
    z = torch.exp(torch.linspace(np.log(1e-3), np.log(20.0), n, device=device))
    A_tgt = CH_NF2["d"] * (torch.log1p(CH_NF2["a"] * z ** 2)
                           + torch.log1p(CH_NF2["b"] * z ** 4))
    logf_tgt = CH_NF2["c"] * z ** 2 - A_tgt + CH_NF2["k"]
    params = list({id(p): p for p in list(a_net.parameters()) + list(f_net.parameters())}.values())
    opt = torch.optim.Adam(params, lr=lr)
    for _ in range(steps):
        opt.zero_grad(set_to_none=True)
        loss = ((a_net(z) - A_tgt) ** 2).mean() \
             + ((torch.log(f_net(z).clamp_min(1e-12)) - logf_tgt) ** 2).mean()
        loss.backward()
        opt.step()
    return float(loss.detach())


# ---------------------------------------------------------------------- targets
def load_csv(path):
    T, y, sig, kind = [], [], [], []
    with open(path) as f:
        for line in f:
            if line.startswith("#") or not line.strip() or line.startswith("T,"):
                continue
            p = line.strip().split(",")
            T.append(float(p[0])); y.append(float(p[1])); sig.append(float(p[2]))
            kind.append(p[3] if len(p) > 3 else "")
    return (np.array(T), np.array(y), np.abs(np.array(sig)),
            np.array(kind, dtype=str))


def dense_low_temperature_eos(Ts, ys, ks, p_anch, hrg_end=HRG_END,
                              step=0.0005):
    """Build the labelled HRG/bridge model constraint on a dense grid.

    The sparse CSV bridge is useful for provenance, but it is too sparse to
    prevent a flexible EMD background from developing a dip between rows.
    This helper reconstructs the same PCHIP entropy bridge used in the paper
    plot and derives p, epsilon and I thermodynamically from it.
    """
    hrg = np.genfromtxt(os.path.join(DATA, "hrg_adapted_Burger2015.csv"),
                        delimiter=",", names=True)
    lattice = np.flatnonzero(np.char.startswith(ks, "lattice"))
    if len(lattice) < 2:
        raise ValueError("at least two lattice entropy points are required")
    first, second = lattice[:2]
    first_t = float(Ts[first])
    bridge_t = np.arange(hrg_end, first_t, step)
    bridge_t = np.r_[bridge_t, first_t]
    knots_t = np.array([hrg_end - .010, hrg_end, Ts[first], Ts[second]])
    knots_s = np.array([np.interp(hrg_end - .010, hrg["TGeV"], hrg["sT3"]),
                        np.interp(hrg_end, hrg["TGeV"], hrg["sT3"]),
                        ys[first], ys[second]])
    bridge_s = PchipInterpolator(knots_t, knots_s)(bridge_t)

    # Use the source HRG at 1 MeV spacing up to 150 MeV, then the dense bridge.
    mh = (hrg["TGeV"] >= p_anch[0] - 1e-12) & \
         (hrg["TGeV"] < hrg_end - 1e-12)
    full_t = np.r_[hrg["TGeV"][mh], bridge_t]
    full_s = np.r_[hrg["sT3"][mh], bridge_s]
    integrand = full_s * full_t ** 3
    pressure_dimful = np.r_[0.0, np.cumsum(
        .5 * (integrand[1:] + integrand[:-1]) * np.diff(full_t))]
    anchor_integral = np.interp(p_anch[0], full_t, pressure_dimful)
    pressure_dimful += p_anch[1] * p_anch[0] ** 4 - anchor_integral
    full_p = pressure_dimful / full_t ** 4
    full_e = full_s - full_p
    full_I = full_s - 4.0 * full_p
    mb = full_t >= hrg_end - 1e-12
    return dict(T=full_t[mb], s=full_s[mb], p=full_p[mb],
                e=full_e[mb], I=full_I[mb])


def load_targets(device, hrg_frac=0.05, no_hrg=False,
                 s_boost=1.0, s_boost_win=(0.19, 0.24),
                 bridge_s_frac=None, eos_fit=False,
                 chi4_fit=False, datta_t_scale=1.0,
                 s_file="Nf2_train_s_verified.csv",
                 chi_file="Nf2_train_chi_verified.csv",
                 rho_file="Nf2_nB_muhat1_verified.csv",
                 i_file="newSEXP_eos.csv",
                 p_anch=(0.174, 0.302), hrg_end=HRG_END):
    Ts, ys, ss, ks = load_csv(os.path.join(DATA, s_file))
    Tc, yc, sc, kc = load_csv(os.path.join(DATA, chi_file))
    Tn, yn, sn, _ = load_csv(os.path.join(DATA, rho_file))
    if abs(hrg_end - HRG_END) > 1e-12:
        hrg = np.genfromtxt(os.path.join(DATA, "hrg_adapted_Burger2015.csv"),
                            delimiter=",", names=True)

        def rebuild_bridge(T, y, sig, kind, hrg_column, bridge_floor):
            lat = np.flatnonzero(np.char.startswith(kind, "lattice"))
            if len(lat) < 2:
                raise ValueError("at least two lattice points are required")
            first, second = lat[:2]
            th = np.arange(.080, hrg_end + 1e-9, .005)
            tb = np.arange(hrg_end + .005, T[first] - 1e-9, .005)
            hy = np.interp(th, hrg["TGeV"], hrg[hrg_column])
            by = PchipInterpolator(
                [hrg_end - .010, hrg_end, T[first], T[second]],
                [np.interp(hrg_end - .010, hrg["TGeV"], hrg[hrg_column]),
                 hy[-1], y[first], y[second]])(tb)
            lt, ly, ls, lk = T[lat], y[lat], sig[lat], kind[lat]
            ht = np.full(len(th), "adapted-HRG:m_pi360", dtype="U64")
            bt = np.full(len(tb), "bridge:PCHIP-model", dtype="U64")
            return (np.r_[th, tb, lt], np.r_[hy, by, ly],
                    np.r_[np.maximum(.05 * abs(hy), .01),
                          np.maximum(.25 * abs(by), bridge_floor), ls],
                    np.r_[ht, bt, lk])

        Ts, ys, ss, ks = rebuild_bridge(Ts, ys, ss, ks, "sT3", .01)
        Tc, yc, sc, kc = rebuild_bridge(Tc, yc, sc, kc, "chi2B", .005)
    is_lattice_c = np.char.startswith(kc, "lattice")
    is_bridge_c = np.char.startswith(kc, "bridge")
    if datta_t_scale != 1.0:
        first_nominal = float(Tc[is_lattice_c][0])
        Tc[is_bridge_c] = (hrg_end + (Tc[is_bridge_c] - hrg_end) *
                           (first_nominal * datta_t_scale - hrg_end) /
                           (first_nominal - hrg_end))
        Tc[is_lattice_c] *= datta_t_scale
    Tn = Tn * datta_t_scale
    rho_table = np.genfromtxt(os.path.join(DATA, rho_file), delimiter=",",
                              names=True)
    if no_hrg:
        # keep only genuine lattice rows: drop HRG anchors and the
        # HRG<->lattice interpolation/blend segment
        ms = np.array([str(k).lower().startswith("lattice") for k in ks])
        mc = np.array([str(k).lower().startswith("lattice") for k in kc])
        Ts, ys, ss, ks = Ts[ms], ys[ms], ss[ms], ks[ms]
        Tc, yc, sc, kc = Tc[mc], yc[mc], sc[mc], kc[mc]
    # Digitised trace anomaly is invariant under the constant p/T^4 shift.
    dig = np.genfromtxt(os.path.join(DATA, i_file),
                        delimiter=",", names=True)
    mI = dig["T_GeV"] >= 0.174

    is_h_s = np.array([_is_hrg(k) for k in ks])
    is_h_c = np.array([_is_hrg(k) for k in kc])
    # Lattice errors are digitised bands/bars with documented analysis floors;
    # bridge sigmas are model tolerances.  Only HRG rows use hrg_frac.
    sig_s = np.where(is_h_s, hrg_frac * np.abs(ys), np.maximum(ss, 1e-4))
    if bridge_s_frac is not None:
        is_bridge_s = np.char.startswith(ks, "bridge")
        sig_s[is_bridge_s] = np.maximum(
            bridge_s_frac * np.abs(ys[is_bridge_s]), 1e-4)
    if s_boost != 1.0:
        # extra loss weight s_boost on the entropy in s_boost_win
        mb = (Ts >= s_boost_win[0]) & (Ts <= s_boost_win[1])
        sig_s = sig_s / np.sqrt(np.where(mb, s_boost, 1.0))
    sig_c = np.where(is_h_c, np.maximum(hrg_frac * np.abs(yc), 1e-4),
                     np.maximum(sc, 1e-5))
    # nB and chi2 share the same lattice measurements.  The conditional
    # nB-chi2 residual isolates the finite-mu Taylor information (chi4/6)
    # and avoids counting chi2 twice as independent data.
    if "chi2B" in rho_table.dtype.names and "dchi4B" in rho_table.dtype.names:
        y_r_chi2 = np.asarray(rho_table["chi2B"], float)
        sig_r_cond = np.hypot(np.asarray(rho_table["dchi4B"], float) / 6.0,
                              0.10 * np.abs(yn))
    else:
        y_r_chi2 = np.interp(Tn, Tc, yc)
        sig_r_cond = sn
    out = dict(
        T_s=torch.tensor(Ts, dtype=torch.float32, device=device),
        y_s=torch.tensor(ys, dtype=torch.float32, device=device),
        sig_s=torch.tensor(sig_s, dtype=torch.float32, device=device),
        T_c=torch.tensor(Tc, dtype=torch.float32, device=device),
        y_c=torch.tensor(yc, dtype=torch.float32, device=device),
        sig_c=torch.tensor(sig_c, dtype=torch.float32, device=device),
        T_r=torch.tensor(Tn, dtype=torch.float32, device=device),
        y_r=torch.tensor(yn, dtype=torch.float32, device=device),
        sig_r=torch.tensor(sn, dtype=torch.float32, device=device),
        y_r_chi2=torch.tensor(y_r_chi2, dtype=torch.float32, device=device),
        sig_r_cond=torch.tensor(sig_r_cond, dtype=torch.float32, device=device),
        T_i=torch.tensor(dig["T_GeV"][mI], dtype=torch.float32, device=device),
        y_i=torch.tensor(dig["I_over_T4"][mI], dtype=torch.float32,
                         device=device),
        sig_i=torch.tensor(np.maximum(dig["dI"][mI], 1e-3),
                           dtype=torch.float32, device=device),
        y_p=torch.tensor(dig["p_over_T4"][mI] + 0.302,
                         dtype=torch.float32, device=device),
        sig_p=torch.tensor(np.hypot(dig["dp"][mI], 0.2 * 0.302),
                           dtype=torch.float32, device=device),
        y_e=torch.tensor(dig["e_over_T4"][mI] + 3 * 0.302,
                         dtype=torch.float32, device=device),
        sig_e=torch.tensor(np.hypot(dig["de"][mI], 3 * 0.2 * 0.302),
                           dtype=torch.float32, device=device),
        n_hrg_s=int(is_h_s.sum()),
        n_bridge_s=int(np.sum(np.char.startswith(ks, "bridge"))),
        n_lat_s=int(np.sum(np.char.startswith(ks, "lattice"))),
        n_hrg_c=int(is_h_c.sum()),
        n_bridge_c=int(np.sum(np.char.startswith(kc, "bridge"))),
        n_lat_c=int(np.sum(np.char.startswith(kc, "lattice"))),
        n_lat_i=int(mI.sum()),
        p_anch=(float(p_anch[0]), float(p_anch[1])),
        eos_fit=bool(eos_fit),
        datta_t_scale=float(datta_t_scale),
        hrg_end=float(hrg_end),
    )
    if eos_fit:
        low = dense_low_temperature_eos(Ts, ys, ks, p_anch,
                                        hrg_end=hrg_end)
        for key, value in low.items():
            out["T_bridge_eos" if key == "T" else f"y_bridge_{key}"] = \
                torch.tensor(value, dtype=torch.float32, device=device)
    if chi4_fit:
        T4, y4, s4, _ = load_csv(os.path.join(DATA,
                                              "Nf2_train_chi4_verified.csv"))
        out.update(T_4=torch.tensor(T4 * datta_t_scale,
                                    dtype=torch.float32, device=device),
                   y_4=torch.tensor(y4, dtype=torch.float32, device=device),
                   sig_4=torch.tensor(s4, dtype=torch.float32,
                                      device=device))
    return out


def _interp(Tg, yg, Tq):
    Tq = Tq.clamp(Tg[0], Tg[-1])
    idx = torch.searchsorted(Tg.detach(), Tq.detach()).clamp(1, Tg.numel() - 1)
    x0, x1 = Tg[idx - 1], Tg[idx]
    y0, y1 = yg[idx - 1], yg[idx]
    w = ((Tq - x0) / (x1 - x0).clamp_min(1e-12)).clamp(0.0, 1.0)
    return y0 + w * (y1 - y0)


# ---------------------------------------------------------------------- training
def train(phase1=6000, phase1b=0, phase2=3000, lr=1e-3, lr2=3e-4, lr_min=1e-6,
          device="cpu", seed=0, n_zh=400, zh_max=20.0, n_int=200,
          G_init=0.885, G_range=(0.05, 2.0), w_reg=1e-6, w_phi=1e-3,
          w_I=1.0, hrg_frac=0.05, rho_scale=1.0, rho_warmup=0.35,
          ema_decay=0.999, eval_every=25, pretrain_steps=1500, verbose=True,
          hidden=32, depth=3, no_hrg=False, s_boost=1.0,
          bridge_s_frac=None, eos_fit=False, chi4_fit=False,
          datta_t_scale=1.0,
          s_boost_win=(0.19, 0.24), s_file="Nf2_train_s_verified.csv",
          chi_file="Nf2_train_chi_verified.csv",
          rho_file="Nf2_nB_muhat1_verified.csv",
          i_file="newSEXP_eos.csv",
          p_anch=(0.174, 0.302), hrg_end=HRG_END, data_seed=None, chi4_scale=0.0,
          closure_f=False, f0=0.5, monotonic_f=False, smooth_monotonic_f=False,
          f_knots=56, initial_state=None):
    torch.manual_seed(seed)
    np.random.seed(seed)
    t0 = time.time()
    if sum((closure_f, monotonic_f, smooth_monotonic_f)) > 1:
        raise ValueError("closure_f, monotonic_f and smooth_monotonic_f are mutually exclusive")

    a_net = A_net(hidden=hidden, depth=depth, act="tanh", form="constrained").to(device)
    if monotonic_f or smooth_monotonic_f:
        z_knots = np.geomspace(1e-4, 20.0, f_knots)
        A_ch = CH_NF2["d"] * (np.log1p(CH_NF2["a"] * z_knots**2)
                              + np.log1p(CH_NF2["b"] * z_knots**4))
        log_f_ch = CH_NF2["c"] * z_knots**2 - A_ch + CH_NF2["k"]
        f_class = SmoothMonotonicF if smooth_monotonic_f else MonotonicF
        f_net = f_class(np.log(z_knots), pava_decreasing(log_f_ch)).to(device)
    else:
        f_net = ClosureF(a_net, f0=f0).to(device) if closure_f else F_net(
            hidden=hidden, depth=depth, act="tanh").to(device)
    model = EMD(a_net, f_net, G=G_init, G_range=G_range, n_int=n_int).to(device)

    pt = 0.0 if closure_f and initial_state is not None else pretrain_background(
        a_net, f_net, device, steps=pretrain_steps)
    if initial_state is not None:
        model.load_state_dict(initial_state, strict=not closure_f)
    D = load_targets(device, hrg_frac=hrg_frac, no_hrg=no_hrg,
                     s_boost=s_boost, s_boost_win=s_boost_win,
                     bridge_s_frac=bridge_s_frac, eos_fit=eos_fit,
                     chi4_fit=chi4_fit or chi4_scale > 0, datta_t_scale=datta_t_scale,
                     s_file=s_file, chi_file=chi_file, rho_file=rho_file,
                     i_file=i_file,
                     p_anch=p_anch, hrg_end=hrg_end)
    if data_seed is not None:
        rng = np.random.default_rng(data_seed)

        def noise(key):
            return torch.as_tensor(rng.standard_normal(len(D[key])),
                                   dtype=D[key].dtype, device=D[key].device)

        D["y_s"] = D["y_s"] + D["sig_s"] * noise("y_s")
        chi_noise = D["sig_c"] * noise("y_c")
        D["y_c"] = D["y_c"] + chi_noise
        D["y_r"] = D["y_r"] + chi_noise + D["sig_r_cond"] * noise("y_r")
        D["y_r_chi2"] = D["y_r_chi2"] + chi_noise
    if verbose:
        print("warm start pretrain loss %.3e | data: s %dHRG+%dbridge+%dLat, "
              "chi %dHRG+%dbridge+%dLat, I %dLat, nB %d"
              % (pt, D["n_hrg_s"], D["n_bridge_s"], D["n_lat_s"],
                 D["n_hrg_c"], D["n_bridge_c"], D["n_lat_c"],
                 D["n_lat_i"], len(D["T_r"])), flush=True)

    zh_grid = torch.exp(torch.linspace(np.log(0.02), np.log(zh_max), n_zh,
                                       device=device))
    zz_smooth = torch.linspace(0.02, zh_max, 200, device=device)

    def branch(T, y):
        m = torch.isfinite(T) & torch.isfinite(y) & (T > 0)
        Tg, yg = T[m], y[m]
        if Tg.numel() < 2:
            return None, None
        order = torch.argsort(Tg)
        Tg, yg = Tg[order], yg[order]
        dup = torch.cat([torch.tensor([True], device=device),
                         torch.diff(Tg) > 1e-9])
        Tg, yg = Tg[dup], yg[dup]
        if Tg.numel() < 2:
            return None, None
        return Tg, yg

    chi4_multiplier = 0.0

    def grouped_pull_loss(residual, n_hrg, n_bridge, n_lattice):
        """Balance provenance groups instead of weighting by row count.

        HRG and bridge rows are dense model constraints; allowing their row
        counts to dominate diluted the genuinely measured lattice targets.
        """
        pieces = []
        if n_hrg:
            pieces.append(.25 * residual[:n_hrg].square().mean())
        if n_bridge:
            lo, hi = n_hrg, n_hrg + n_bridge
            pieces.append(.35 * residual[lo:hi].square().mean())
        if n_lattice:
            pieces.append(1.40 * residual[n_hrg + n_bridge:].square().mean())
        return sum(pieces)

    L4_0 = None

    def losses(use_r):
        nonlocal L4_0
        nan = torch.full((), float("nan"), device=device)
        o = model.observables_mu0(zh_grid)
        Tg, sg = branch(o["T"], o["s_over_T3"])
        _, cg = branch(o["T"], o["chi2B"])
        if Tg is None or cg is None:
            return nan, nan, nan, nan, nan, nan
        r_s = (_interp(Tg, sg, D["T_s"]) - D["y_s"]) / D["sig_s"]
        r_c = (_interp(Tg, cg, D["T_c"]) - D["y_c"]) / D["sig_c"]
        if eos_fit:
            L_s = grouped_pull_loss(r_s, D["n_hrg_s"], D["n_bridge_s"],
                                    D["n_lat_s"])
        else:
            L_s = r_s.square().mean()
        if chi4_fit:
            L_c = grouped_pull_loss(r_c, D["n_hrg_c"], D["n_bridge_c"],
                                    D["n_lat_c"])
        else:
            L_c = r_c.square().mean()
        if chi4_scale > 0:
            t4, _, c4 = model.susceptibilities_mu0(zh_grid)
            t4, c4 = branch(t4, c4)
            L4 = (((_interp(t4, c4, D["T_4"]) - D["y_4"]) / D["sig_4"]) ** 2).mean()
            if L4_0 is None:
                L4_0 = max(float(L4.detach()), 1e-12)
            L_c = L_c + chi4_scale * L4 / L4_0
        # Thermodynamically integrate p from s.  Legacy mode uses the paper's
        # 174 MeV pressure; EOS-fit mode is launched with the 80 MeV HRG anchor.
        sint = torch.cat([torch.zeros(1, device=device), torch.cumsum(
            0.5 * (sg[1:] * Tg[1:] ** 3 + sg[:-1] * Tg[:-1] ** 3)
            * torch.diff(Tg), 0)])
        T_ANCH, P_ANCH = D["p_anch"]
        C = P_ANCH * T_ANCH ** 4 - _interp(
            Tg, sint, torch.tensor([T_ANCH], device=device))[0]
        Ig = sg - 4.0 * (sint + C) / Tg ** 4
        L_trace = (((_interp(Tg, Ig, D["T_i"]) - D["y_i"]) /
                    D["sig_i"]) ** 2).mean()
        if eos_fit:
            pg = (sint + C) / Tg ** 4
            eg = sg - pg
            L_p = (((_interp(Tg, pg, D["T_i"]) - D["y_p"]) /
                    D["sig_p"]) ** 2).mean()
            L_e = (((_interp(Tg, eg, D["T_i"]) - D["y_e"]) /
                    D["sig_e"]) ** 2).mean()
            # Dense, thermodynamically consistent splice constraint.  The old
            # sparse 5 MeV entropy rows with a 10% tolerance allowed visible
            # dips and a large slope overshoot between HRG and the first LQCD
            # point.  This is explicitly a model-shape constraint, not LQCD.
            Tb = D["T_bridge_eos"]
            sb = _interp(Tg, sg, Tb)
            pb = _interp(Tg, pg, Tb)
            eb = _interp(Tg, eg, Tb)
            Ib = _interp(Tg, Ig, Tb)
            L_bridge_value = sum(
                (((pred - D[f"y_bridge_{key}"]) /
                  (0.02 * D[f"y_bridge_{key}"].abs().clamp_min(0.02))) ** 2).mean()
                for key, pred in (("s", sb), ("p", pb),
                                  ("e", eb), ("I", Ib))) / 4.0
            ds_model = torch.diff(sb) / torch.diff(Tb)
            ds_target = torch.diff(D["y_bridge_s"]) / torch.diff(Tb)
            slope_scale = 0.15 * ds_target.abs().clamp_min(10.0)
            L_bridge_slope = (((ds_model - ds_target) /
                               slope_scale) ** 2).mean()
            # These EOS observables share lattice configurations and algebraic
            # identities.  This is a weighted fit objective, not a chi-square
            # of statistically independent measurements.
            L_I = (0.28 * L_p + 0.20 * L_e + 0.20 * L_trace +
                   0.24 * L_bridge_value + 0.08 * L_bridge_slope)
        else:
            L_I = L_trace
        if chi4_fit and chi4_multiplier > 0:
            t4, _, chi4g = model.susceptibilities_mu0(zh_grid)
            t4, chi4g = branch(t4, chi4g)
            L_4 = (((_interp(t4, chi4g, D["T_4"]) - D["y_4"]) /
                    D["sig_4"]) ** 2).mean()
            L_I = L_I + chi4_multiplier * L_4
        L_r = torch.zeros((), device=device)
        if use_r:
            nB, Tr, _ = model.nB_over_T3(zh_grid, muhat=1.0)
            Tn, rn = branch(Tr, nB)
            if Tn is None:
                return nan, nan, nan, nan, nan, nan
            delta_model = _interp(Tn, rn, D["T_r"]) - _interp(Tg, cg, D["T_r"])
            delta_data = D["y_r"] - D["y_r_chi2"]
            L_r = (((delta_model - delta_data) / D["sig_r_cond"]) ** 2).mean()
        L_phi = torch.relu(-model.phi_prime_sq(zz_smooth)).mean()
        Ag = a_net(zh_grid.unsqueeze(-1)).squeeze(-1)
        Fg = torch.log(f_net(zh_grid.unsqueeze(-1)).squeeze(-1))
        L_reg = ((Ag[2:] - 2 * Ag[1:-1] + Ag[:-2]) ** 2).mean() \
              + ((Fg[2:] - 2 * Fg[1:-1] + Fg[:-2]) ** 2).mean()
        return L_s, L_c, L_I, L_r, L_reg, L_phi

    params = list({id(p): p for p in list(a_net.parameters()) + list(f_net.parameters())}.values()) + [model.G]
    ema = {k: v.detach().clone() for k, v in model.state_dict().items()}

    def ema_eval(use_r):
        raw = {k: v.detach().clone() for k, v in model.state_dict().items()}
        model.load_state_dict(ema)
        L_s, L_c, L_I, L_r, L_reg, L_phi = losses(use_r)
        tot = L_s + L_c + w_reg * L_reg + w_phi * L_phi
        model.load_state_dict(raw)
        return [float(v.detach()) for v in (tot, L_s, L_c, L_I, L_r)]

    hist = []

    def run(n_epochs, lr0, phase, use_I):
        nonlocal chi4_multiplier
        opt = torch.optim.Adam(params, lr=lr0)
        # normalisers for the ramped-in terms, fixed at phase start
        LI0 = Lr0 = None
        if use_I and not eos_fit:
            LI0 = max(float(losses(False)[2].detach()), 1e-12)
        if phase == 2:
            Lr0 = max(float(losses(True)[3].detach()), 1e-12)

        def total(parts, ep):
            L_s, L_c, L_I, L_r, L_reg, L_phi = parts
            tot = L_s + L_c + w_reg * L_reg + w_phi * L_phi
            w_full = min(1.0, (ep + 1) / max(1.0, rho_warmup * n_epochs))
            if use_I:
                tot = tot + w_I * w_full * (L_I if eos_fit else L_I / LI0)
            if phase == 2:
                tot = tot + rho_scale * w_full * L_r / Lr0
            return tot

        best, best_state = float("inf"), None
        last_good = {k: v.detach().clone() for k, v in model.state_dict().items()}
        last_good_ema = {k: v.detach().clone() for k, v in ema.items()}
        lr_scale = 1.0
        for ep in range(n_epochs):
            # Reach the full direct-chi4 objective early enough for both the
            # optimiser and the EMA checkpoint to converge under that same
            # objective.  The old full-phase ramp reached weight one only on
            # the final step and selected a lagging compromise checkpoint.
            chi4_multiplier = min(
                1.0, (ep + 1) / max(1.0, rho_warmup * n_epochs)) ** 2 if (
                    use_I and chi4_fit) else 0.0
            model.train()
            opt.zero_grad(set_to_none=True)
            use_r = (phase == 2)
            L_s, L_c, L_I, L_r, L_reg, L_phi = losses(use_r)
            tot = total((L_s, L_c, L_I, L_r, L_reg, L_phi), ep)
            cur = float(tot.detach())
            gnorm = float("nan")
            if math.isfinite(cur):
                tot.backward()
                gnorm = float(torch.nn.utils.clip_grad_norm_(params, 1.0))
            if not (math.isfinite(cur) and math.isfinite(gnorm)):
                # diverged step: roll back to the last finite state, slow down
                opt.zero_grad(set_to_none=True)
                model.load_state_dict(last_good)
                for k, v in last_good_ema.items():
                    ema[k].copy_(v)
                lr_scale *= 0.5
                continue
            opt.step()
            model.clamp_G()
            frac = ep / max(n_epochs - 1, 1)
            for g in opt.param_groups:
                g["lr"] = lr_scale * (lr_min + 0.5 * (lr0 - lr_min)
                                      * (1.0 + math.cos(math.pi * frac)))
            with torch.no_grad():
                msd = model.state_dict()
                for k, v in ema.items():
                    v.mul_(ema_decay).add_(msd[k], alpha=1.0 - ema_decay)
            last_good = {k: v.detach().clone()
                         for k, v in model.state_dict().items()}
            last_good_ema = {k: v.detach().clone() for k, v in ema.items()}
            if ep % eval_every == 0 or ep == n_epochs - 1:
                train_multiplier = chi4_multiplier
                if use_I and chi4_fit:
                    # Compare checkpoints with the same full chi4 objective
                    # while its training weight is being ramped in.
                    chi4_multiplier = 1.0
                e = ema_eval(use_r)
                chi4_multiplier = train_multiplier
                if use_I:
                    e[0] += w_I * (e[3] if eos_fit else e[3] / LI0)
                if use_r:
                    e[0] += rho_scale * e[4] / Lr0
                if e[0] < best:
                    best, best_state = e[0], {k: v.clone() for k, v in ema.items()}
                hist.append(dict(phase=phase, epoch=ep, total_ema=e[0],
                                 L_s_ema=e[1], L_c_ema=e[2], L_I_ema=e[3],
                                 L_r_ema=e[4],
                                 total_raw=cur, L_s_raw=float(L_s.detach()),
                                 L_c_raw=float(L_c.detach()),
                                 L_I_raw=float(L_I.detach()),
                                 L_r_raw=float(L_r.detach()),
                                 lr=opt.param_groups[0]["lr"],
                                 G=float(model.G.detach())))
                if verbose and (ep % (eval_every * 40) == 0 or ep == n_epochs - 1):
                    print("  [ph%d] ep %5d ema=%.4e (s=%.3e c=%.3e I=%.3e r=%.3e) "
                          "lr=%.2e G=%.4f"
                          % (phase, ep, e[0], e[1], e[2], e[3], e[4],
                             opt.param_groups[0]["lr"], float(model.G.detach())),
                          flush=True)
        if best_state is not None:
            model.load_state_dict(best_state)
        return best

    if verbose:
        print("=== phase 1: mu=0 (s/T^3 + chi_2^B) ===", flush=True)
    b1 = run(phase1, lr, 1, use_I=False)
    b1b = float("nan")
    if phase1b:
        if verbose:
            print("=== phase 1b: + I/T^4 (digitised tmfT band) ===", flush=True)
        b1b = run(phase1b, lr2, 1, use_I=True)
    state_mu0 = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
    b2 = float("nan")
    if phase2:
        if verbose:
            print("=== phase 2: + n_B/T^3 at mu_B/T = 1 ===", flush=True)
        b2 = run(phase2, lr2, 2, use_I=bool(phase1b))

    res = dict(model=model, history=hist, state_mu0=state_mu0,
               meta=dict(method="mu=0 (s + chi) + conditional n_B/T^3(mu_B/T=1)"
                                + (" + p,e,I/T^4+chi4B" if phase1b and
                                   eos_fit and chi4_fit
                                   else " + p,e,I/T^4" if phase1b and eos_fit
                                   else " + I/T^4" if phase1b else ""),
                         device=str(device),
                         warm_start="CH Table1 Nf=2 analytic",
                         pretrain_loss=pt, best_phase1=b1, best_phase1b=b1b,
                         best_phase2=b2,
                         w_I=w_I, no_hrg=no_hrg, s_boost=s_boost,
                         bridge_s_frac=bridge_s_frac, eos_fit=eos_fit,
                         chi4_fit=chi4_fit, chi4_scale=chi4_scale,
                         closure_f=closure_f, f0=f0,
                         monotonic_f=monotonic_f, smooth_monotonic_f=smooth_monotonic_f,
                         f_knots=f_knots,
                         f_parameterization=("smooth monotonic cubic B-spline log f(log z)"
                                             if smooth_monotonic_f else
                                             "monotonic log f(log z)" if monotonic_f
                                             else "closure" if closure_f else "free network"),
                         datta_t_scale=datta_t_scale,
                         hrg_end=hrg_end,
                         s_file=s_file, chi_file=chi_file, rho_file=rho_file,
                         i_file=i_file,
                         p_anch=str(tuple(p_anch)),
                         rho_scale=rho_scale, rho_warmup=rho_warmup,
                         hrg_frac=hrg_frac, w_reg=w_reg, w_phi=w_phi,
                         n_zh=n_zh, n_int=n_int, hidden=hidden, depth=depth,
                         data_seed=data_seed,
                         A_parameterization="-z sigmoid(n_A(z))",
                         wall=time.time() - t0))
    if verbose:
        print("best: phase1 %.4e  phase1b %.4e  phase2 %.4e (%.0fs)"
              % (b1, b1b, b2, time.time() - t0), flush=True)
    return res


def save(res, tag=""):
    import copy
    os.makedirs(RESULTS, exist_ok=True)
    z = torch.linspace(1e-4, 20.0, 4000)
    meta = {k: v for k, v in res["meta"].items()
            if isinstance(v, (int, float, str, type(None)))}
    A, f, G = res["model"].export_functions(z)
    np.savez(os.path.join(RESULTS, "Nf2_A_f%s.npz" % tag), z=z.numpy(), A=A,
             f=f, G=G, **meta)
    m0 = copy.deepcopy(res["model"])
    m0.load_state_dict(res["state_mu0"])
    A, f, G = m0.export_functions(z)
    np.savez(os.path.join(RESULTS, "Nf2_A_f_mu0only%s.npz" % tag), z=z.numpy(),
             A=A, f=f, G=G, **meta)
    json.dump(dict(meta=res["meta"], history=res["history"]),
              open(os.path.join(RESULTS, "Nf2_history%s.json" % tag), "w"),
              indent=1)
    return os.path.join(RESULTS, "Nf2_A_f%s.npz" % tag)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--phase1", type=int, default=6000)
    ap.add_argument("--phase1b", type=int, default=0)
    ap.add_argument("--phase2", type=int, default=3000)
    ap.add_argument("--seeds", type=int, default=3)
    ap.add_argument("--seed_start", type=int, default=0,
                    help="first random seed (for running seeds in separate processes)")
    ap.add_argument("--wI", type=float, default=1.0)
    ap.add_argument("--w_reg", type=float, default=1e-6)
    ap.add_argument("--hidden", type=int, default=32)
    ap.add_argument("--depth", type=int, default=3)
    ap.add_argument("--n_zh", type=int, default=400)
    ap.add_argument("--n_int", type=int, default=200)
    ap.add_argument("--device", default=None)
    ap.add_argument("--tag", default="_verified")
    ap.add_argument("--no_hrg", action="store_true")
    ap.add_argument("--s_boost", type=float, default=1.0)
    ap.add_argument("--bridge_s_frac", type=float, default=None)
    ap.add_argument("--eos_fit", action="store_true")
    ap.add_argument("--chi4_fit", action="store_true")
    ap.add_argument("--chi4_scale", type=float, default=0.0)
    ap.add_argument("--closure_f", action="store_true")
    ap.add_argument("--f0", type=float, default=0.5)
    ap.add_argument("--monotonic_f", action="store_true")
    ap.add_argument("--smooth_monotonic_f", action="store_true")
    ap.add_argument("--f_knots", type=int, default=56)
    ap.add_argument("--datta_t_scale", type=float, default=1.0)
    ap.add_argument("--rho_scale", type=float, default=1.0)
    ap.add_argument("--s_boost_win", type=float, nargs=2,
                    default=(0.19, 0.24))
    ap.add_argument("--s_file", default="Nf2_train_s_verified.csv")
    ap.add_argument("--chi_file", default="Nf2_train_chi_verified.csv")
    ap.add_argument("--rho_file", default="Nf2_nB_muhat1_verified.csv")
    ap.add_argument("--i_file", default="newSEXP_eos.csv")
    ap.add_argument("--p_anch", type=float, nargs=2, default=(0.174, 0.302))
    ap.add_argument("--hrg_end", type=float, default=HRG_END)
    a = ap.parse_args()
    if a.eos_fit and a.phase1b <= 0:
        ap.error("--eos_fit requires --phase1b > 0 so EOS loss is optimized")
    if a.chi4_fit and a.phase1b <= 0:
        ap.error("--chi4_fit requires --phase1b > 0")
    if sum((a.closure_f, a.monotonic_f, a.smooth_monotonic_f)) > 1:
        ap.error("f parameterization flags are mutually exclusive")
    if a.f_knots < 4:
        ap.error("--f_knots must be at least 4")
    if a.w_reg < 0:
        ap.error("--w_reg must be nonnegative")
    if not .95 <= a.datta_t_scale <= 1.05:
        ap.error("--datta_t_scale must be within 0.95..1.05")
    if not .12 <= a.hrg_end <= .18:
        ap.error("--hrg_end must be within 0.12..0.18 GeV")
    dev = a.device or ("cuda" if torch.cuda.is_available() else "cpu")
    print("device:", dev, flush=True)

    winner, winner_seed, wscore = None, None, float("inf")
    for seed in range(a.seed_start, a.seed_start + a.seeds):
        print("=== run seed %d ===" % seed, flush=True)
        res = train(phase1=a.phase1, phase1b=a.phase1b, phase2=a.phase2,
                    device=dev, seed=seed,
                    hidden=a.hidden, depth=a.depth, w_I=a.wI, w_reg=a.w_reg,
                    n_zh=a.n_zh, n_int=a.n_int,
                    no_hrg=a.no_hrg, s_boost=a.s_boost,
                    bridge_s_frac=a.bridge_s_frac, eos_fit=a.eos_fit,
                    chi4_fit=a.chi4_fit, datta_t_scale=a.datta_t_scale,
                    rho_scale=a.rho_scale, chi4_scale=a.chi4_scale,
                    closure_f=a.closure_f, f0=a.f0,
                    monotonic_f=a.monotonic_f,
                    smooth_monotonic_f=a.smooth_monotonic_f, f_knots=a.f_knots,
                    s_boost_win=tuple(a.s_boost_win),
                    s_file=a.s_file, chi_file=a.chi_file, rho_file=a.rho_file,
                    i_file=a.i_file,
                    p_anch=tuple(a.p_anch), hrg_end=a.hrg_end)
        score = (res["meta"]["best_phase2"] if a.phase2 else
                 res["meta"]["best_phase1b"] if a.phase1b else
                 res["meta"]["best_phase1"])
        print("seed %d: best %s %.4e" %
              (seed, "phase2" if a.phase2 else "phase1b/phase1", score),
              flush=True)
        if score < wscore:
            winner, winner_seed, wscore = res, seed, score
    print("winner: seed %d (%.4e)" % (winner_seed, wscore))
    winner["meta"]["seed"] = winner_seed
    winner["meta"]["n_seeds"] = a.seeds
    print("saved:", save(winner, tag=a.tag), flush=True)
    print("now run: python3 code/plot_verified_nf2.py", flush=True)


if __name__ == "__main__":
    main()
