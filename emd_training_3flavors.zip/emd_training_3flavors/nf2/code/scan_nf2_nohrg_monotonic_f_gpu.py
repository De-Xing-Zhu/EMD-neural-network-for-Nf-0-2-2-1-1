#!/usr/bin/env python3
"""GPU scan of independent hard-monotonic Nf=2 f(z) refits.

All variants and the selected model are written below
results/monotonic_f_scan/.  Existing training code and results are read-only.
"""

from pathlib import Path
import json
import math
import time

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch

from emd_free import EMD, InterpNet, find_cep, load_trained
from train_nf2 import _interp, load_targets
from refine_nf2_nohrg_monotonic_f_gpu import (
    MonotonicF, branch, pava_decreasing, stats,
)


BASE = Path(__file__).resolve().parents[1]
SOURCE = BASE / "results/Nf2_A_f_nohrg_smooth.npz"
OUTDIR = BASE / "results/monotonic_f_scan"
FINAL = OUTDIR / "Nf2_A_f_nohrg_monotonic_balanced.npz"


def train_variant(name, chi_weight, density_weight, z_saved, A_saved,
                  f_saved, G_saved, targets, device):
    torch.manual_seed(20261027)
    n_knots = 56
    z_knots = np.geomspace(max(float(z_saved[0]), 1.0e-4),
                           float(z_saved[-1]), n_knots)
    source = np.interp(np.log(z_knots), np.log(z_saved),
                       np.log(np.clip(f_saved, 1.0e-14, None)))
    initial = pava_decreasing(source)
    f_net = MonotonicF(np.log(z_knots), initial).to(device)
    model = EMD(InterpNet(z_saved, A_saved).to(device), f_net,
                G=G_saved, n_int=320).to(device)
    model.G.requires_grad_(False)
    zh = torch.exp(torch.linspace(math.log(.02), math.log(20.0), 760,
                                  device=device))
    initial_t = torch.as_tensor(initial, dtype=torch.float32, device=device)
    optimizer = torch.optim.Adam(f_net.parameters(), lr=8.0e-3)
    epochs = 2800
    best_key, best_state, history = None, None, []
    started = time.time()

    for epoch in range(epochs + 1):
        optimizer.zero_grad(set_to_none=True)
        obs = model.observables_mu0(zh)
        tc, chi = branch(obs["T"], obs["chi2B"])
        rc = (_interp(tc, chi, targets["T_c"]) - targets["y_c"]) / \
             targets["sig_c"]
        nb, tnb, _ = model.nB_over_T3(zh, muhat=1.0)
        tn, nb = branch(tnb, nb)
        delta = (_interp(tn, nb, targets["T_r"]) -
                 _interp(tc, chi, targets["T_r"]))
        target_delta = targets["y_r"] - targets["y_r_chi2"]
        rn = (delta - target_delta) / targets["sig_r_cond"]

        knots = f_net.knot_values()
        slopes = -(knots[1:] - knots[:-1]) / f_net.dx
        roughness = (slopes[1:] - slopes[:-1]).square().mean()
        prior = (knots - initial_t).square().mean()
        loss = (chi_weight * rc.square().mean() +
                density_weight * rn.square().mean() +
                2.0e-3 * roughness + 2.0e-4 * prior)

        metrics = dict(
            chi_rms=float(torch.sqrt(rc.square().mean()).detach()),
            chi_max=float(rc.abs().max().detach()),
            nB_cond_rms=float(torch.sqrt(rn.square().mean()).detach()),
            nB_cond_max=float(rn.abs().max().detach()),
        )
        gate = (metrics["chi_rms"] <= 1.20 and metrics["chi_max"] <= 2.4 and
                metrics["nB_cond_rms"] <= 1.20 and
                metrics["nB_cond_max"] <= 2.5)
        score = (metrics["chi_rms"]**2 + metrics["nB_cond_rms"]**2 +
                 .08 * (metrics["chi_max"]**2 + metrics["nB_cond_max"]**2))
        key = (not gate, score)
        if best_key is None or key < best_key:
            best_key = key
            best_state = {k: v.detach().clone()
                          for k, v in f_net.state_dict().items()}
        if epoch % 400 == 0 or epoch == epochs:
            row = dict(epoch=epoch, loss=float(loss.detach()), gate=gate,
                       elapsed_s=round(time.time() - started, 2), **metrics)
            history.append(row)
            print(name, json.dumps(row), flush=True)
        if epoch == epochs:
            break
        loss.backward()
        torch.nn.utils.clip_grad_norm_(f_net.parameters(), 5.0)
        optimizer.step()
        fraction = epoch / max(epochs - 1, 1)
        optimizer.param_groups[0]["lr"] = 1.0e-4 + \
            0.5 * (8.0e-3 - 1.0e-4) * (1.0 + math.cos(math.pi * fraction))

    f_net.load_state_dict(best_state)
    with torch.no_grad():
        f_new = f_net(torch.as_tensor(z_saved, dtype=torch.float32,
                                      device=device)).cpu().numpy()
    path = OUTDIR / f"Nf2_A_f_{name}.npz"
    np.savez(path, z=z_saved, A=A_saved, f=f_new, G=G_saved, no_hrg=True,
             hard_monotonic_f=True, source=SOURCE.name,
             chi_weight=chi_weight, density_weight=density_weight,
             method="hard-monotonic weight scan; A and G frozen")
    report = dict(name=name, output=path.name, chi_weight=chi_weight,
                  density_weight=density_weight, selection_key=list(best_key),
                  quality_gate_passed=not best_key[0], history=history)
    (OUTDIR / f"{name}_training.json").write_text(
        json.dumps(report, indent=2) + "\n")
    return path, best_key


def validate(path, z_saved, targets, device):
    model = load_trained(path, n_int=900).to(device)
    z_check = np.geomspace(max(float(z_saved[0]), 1.0e-4),
                           float(z_saved[-1]), 12000)
    zh = torch.exp(torch.linspace(math.log(.02), math.log(20.0), 3000,
                                  device=device))
    with torch.no_grad():
        f = model.f_net(torch.as_tensor(z_check, dtype=torch.float32,
                                       device=device)).cpu().numpy()
        obs = model.observables_mu0(zh)
        tc, chi = branch(obs["T"], obs["chi2B"])
        nb, tnb, _ = model.nB_over_T3(zh, muhat=1.0)
        tn, nb = branch(tnb, nb)
        rc = ((_interp(tc, chi, targets["T_c"]) - targets["y_c"]) /
              targets["sig_c"]).cpu().numpy()
        delta = (_interp(tn, nb, targets["T_r"]) -
                 _interp(tc, chi, targets["T_r"]))
        target_delta = targets["y_r"] - targets["y_r_chi2"]
        rn = ((delta - target_delta) / targets["sig_r_cond"]).cpu().numpy()
    df = np.diff(f)
    result = dict(
        model=path.name,
        f_positive=bool(np.all(f > 0.0)),
        f_nonincreasing=bool(np.all(df <= 1.0e-10)),
        positive_steps_over_12000=int(np.count_nonzero(df > 1.0e-10)),
        f_uv=float(f[0]), f_at_z4=float(np.interp(4.0, z_check, f)),
        chi2B=stats(rc), nB_minus_chi2=stats(rn),
    )
    gate = (result["chi2B"]["rms_pull"] <= 1.20 and
            result["chi2B"]["max_abs_pull"] <= 2.4 and
            result["nB_minus_chi2"]["rms_pull"] <= 1.20 and
            result["nB_minus_chi2"]["max_abs_pull"] <= 2.5 and
            result["f_nonincreasing"] and result["f_positive"])
    score = (result["chi2B"]["rms_pull"]**2 +
             result["nB_minus_chi2"]["rms_pull"]**2 +
             .08 * (result["chi2B"]["max_abs_pull"]**2 +
                    result["nB_minus_chi2"]["max_abs_pull"]**2))
    result["quality_gate_passed"] = gate
    result["score"] = score
    return result


def main():
    if not torch.cuda.is_available():
        raise SystemExit("CUDA is required; no CPU fallback was started")
    device = torch.device("cuda")
    OUTDIR.mkdir(parents=True, exist_ok=True)
    with np.load(SOURCE, allow_pickle=False) as data:
        z_saved = data["z"].copy(); A_saved = data["A"].copy()
        f_saved = data["f"].copy(); G_saved = float(data["G"])
    targets = load_targets("cuda", no_hrg=True, s_boost=4.0,
                           s_boost_win=(.19, .24), p_anch=(.174, .302))

    variants = [("monotonic_equal", 1.0, 1.0),
                ("monotonic_chi2", 2.0, 1.0),
                ("monotonic_chi4", 4.0, 1.0)]
    rows = []
    for name, wc, wn in variants:
        path, _ = train_variant(name, wc, wn, z_saved, A_saved, f_saved,
                                G_saved, targets, device)
        row = validate(path, z_saved, targets, device)
        row.update(name=name, chi_weight=wc, density_weight=wn)
        rows.append(row)
        print("validated", json.dumps(row), flush=True)

    selected = min(rows, key=lambda row: (not row["quality_gate_passed"],
                                          row["score"]))
    selected_path = OUTDIR / selected["model"]
    with np.load(selected_path, allow_pickle=False) as data:
        payload = {key: data[key].copy() for key in data.files}
    payload["selected_from"] = selected_path.name
    np.savez(FINAL, **payload)
    final_validation = dict(source=SOURCE.name, selected=selected,
                            all_variants=rows, A_and_G_frozen=True,
                            original_results_overwritten=False)
    (OUTDIR / "validation.json").write_text(
        json.dumps(final_validation, indent=2) + "\n")

    final_model = load_trained(FINAL, n_int=900).to(device)
    cep = find_cep(final_model, mu_lo=0.0, mu_hi=1.6, n_scan=45,
                   tol=2.0e-5, z0=.05, z1=40.0, n=6000)
    (OUTDIR / "cep.json").write_text(json.dumps(cep, indent=2) + "\n")

    old = load_trained(SOURCE, n_int=900).to(device)
    z = np.linspace(.0001, 4.0, 1200)
    with torch.no_grad():
        zt = torch.as_tensor(z, dtype=torch.float32, device=device)
        old_f = old.f_net(zt).cpu().numpy()
        new_f = final_model.f_net(zt).cpu().numpy()
    fig, ax = plt.subplots(figsize=(4.2, 3.0), constrained_layout=True)
    ax.plot(z, old_f, color="0.55", ls="--", lw=1.4,
            label="selected unconstrained")
    ax.plot(z, new_f, color="green", lw=1.7,
            label="selected hard-monotonic")
    ax.set(xlabel=r"$z$ [GeV$^{-1}$]", ylabel=r"$f(z)$", xlim=(0, 4))
    ax.tick_params(which="both", direction="in", top=True, right=True)
    ax.legend(frameon=False, fontsize=8)
    fig.savefig(OUTDIR / "comparison.png", dpi=240, bbox_inches="tight")
    plt.close(fig)
    print("selected", json.dumps(selected), flush=True)
    print("cep", json.dumps(cep), flush=True)
    print("saved", FINAL, flush=True)


if __name__ == "__main__":
    main()
