#!/usr/bin/env python3
"""Run an isolated GPU retraining with HRG retained only through 140 MeV."""

from pathlib import Path
import argparse
import json
import os
import subprocess
import sys

import numpy as np
import torch

BASE = Path(__file__).resolve().parents[1]
CODE = BASE / "code"
DATA = BASE / "data"
RESULTS = BASE / "results"
HRG_END = .140


def preflight():
    if not torch.cuda.is_available():
        raise SystemExit("CUDA is unavailable; no CPU training started.")
    free, total = torch.cuda.mem_get_info(0)
    print(f"GPU: {torch.cuda.get_device_name(0)}; "
          f"free {free / 2**30:.2f}/{total / 2**30:.2f} GiB", flush=True)
    if free < 3 * 2**30:
        raise SystemExit("At least 3 GiB GPU memory must be free.")


def run_logged(command, logfile):
    env = os.environ.copy()
    env.setdefault("OMP_NUM_THREADS", "4")
    env.setdefault("MKL_NUM_THREADS", "4")
    env.setdefault("MPLCONFIGDIR", "/tmp/mpl_nf2_hrg140_gpu")
    with logfile.open("w") as output:
        proc = subprocess.Popen(command, cwd=BASE, env=env,
                                stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, text=True, bufsize=1)
        for line in proc.stdout:
            print(line, end="", flush=True)
            output.write(line)
            output.flush()
        if proc.wait():
            raise RuntimeError(f"Training failed. See {logfile}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--check-only", action="store_true")
    ap.add_argument("--seed-start", type=int, default=40)
    ap.add_argument("--seeds", type=int, default=2)
    ap.add_argument("--phase1", type=int, default=8000)
    ap.add_argument("--phase1b", type=int, default=4000)
    ap.add_argument("--phase2", type=int, default=4000)
    ap.add_argument("--n-zh", type=int, default=600)
    ap.add_argument("--n-int", type=int, default=300)
    args = ap.parse_args()
    if args.seeds < 1 or min(args.phase1, args.phase1b, args.phase2) < 1:
        ap.error("seeds and all phases must be positive")
    preflight()
    if args.check_only:
        return

    RESULTS.mkdir(exist_ok=True)
    hrg = np.genfromtxt(DATA / "hrg_adapted_Burger2015.csv", delimiter=",",
                        names=True)
    p80 = float(hrg["PT4"][np.argmin(abs(hrg["TGeV"] - .080))])
    seeds = list(range(args.seed_start, args.seed_start + args.seeds))
    config = {"device": "cuda", "experiment": "isolated_hrg140",
              "does_not_replace": "Nf2_A_f_eosfit.npz",
              "seeds": seeds, "phase1": args.phase1,
              "phase1b": args.phase1b, "phase2": args.phase2,
              "n_zh": args.n_zh, "n_int": args.n_int,
              "hrg_end_GeV": HRG_END, "bridge_s_frac": .02,
              "dense_bridge_eos": True, "p_anchor": [.08, p80]}
    (RESULTS / "hrg140_gpu_run_config.json").write_text(
        json.dumps(config, indent=2) + "\n")

    for seed in seeds:
        tag = f"_hrg140_seed{seed}"
        logfile = RESULTS / f"train_hrg140_seed{seed}_gpu.log"
        command = [sys.executable, "-u", str(CODE / "train_nf2.py"),
                   "--device", "cuda", "--seeds", "1",
                   "--seed_start", str(seed), "--tag", tag,
                   "--hidden", "64", "--depth", "4",
                   "--phase1", str(args.phase1),
                   "--phase1b", str(args.phase1b),
                   "--phase2", str(args.phase2),
                   "--n_zh", str(args.n_zh), "--n_int", str(args.n_int),
                   "--eos_fit", "--wI", "1.0", "--hrg_end", str(HRG_END),
                   "--bridge_s_frac", ".02", "--s_boost", "4.0",
                   "--s_boost_win", ".19", ".24", "--rho_scale", ".5",
                   "--p_anch", ".08", repr(p80)]
        print(f"Starting isolated HRG140 seed {seed}; log: {logfile}",
              flush=True)
        run_logged(command, logfile)

    subprocess.run([sys.executable, str(CODE / "evaluate_nf2_hrg140.py"),
                    "--seeds", *map(str, seeds)], cwd=BASE, check=True)


if __name__ == "__main__":
    main()
