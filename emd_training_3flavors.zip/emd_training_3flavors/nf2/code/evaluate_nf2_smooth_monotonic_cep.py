#!/usr/bin/env python3
"""Solve and convergence-check the geometric cusp of the selected Nf=2 model."""

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.integrate import cumulative_trapezoid
from scipy.interpolate import CubicSpline
from scipy.optimize import root

BASE = Path(__file__).resolve().parents[1]
MODEL = BASE / "results/Nf2_A_f_smooth_monotonic_warm20k_phi10_seed50.npz"
OUTPUT = BASE / "results/Nf2_cep_smooth_monotonic_warm20k_phi10_seed50.json"


def solve_cusp(path, n, initial):
    with np.load(path, allow_pickle=False) as data:
        acs = CubicSpline(data["z"], data["A"])
        fcs = CubicSpline(data["z"], np.log(data["f"]))

    def temperature(zh, mu):
        z = np.linspace(1e-4, zh, n)
        A = acs(z)
        f = np.exp(fcs(z))
        q1 = z**3 * np.exp(-3*A)
        q2 = z * np.exp(-A) / f
        i1 = cumulative_trapezoid(q1, z, initial=0.0)[-1]
        i2 = cumulative_trapezoid(q2, z, initial=0.0)[-1]
        i4 = cumulative_trapezoid(
            q1*cumulative_trapezoid(q2, z, initial=0.0), z, initial=0.0)[-1]
        t0 = zh**3 * np.exp(-3*A[-1]) / (4*np.pi*i1)
        return t0 * (1 - (mu/i2)**2 * (i1*i2-i4))

    def conditions(x):
        zh, mu = x
        hz = 2e-4
        tz = (temperature(zh+hz, mu)-temperature(zh-hz, mu))/(2*hz)
        tzz = (temperature(zh+hz, mu)-2*temperature(zh, mu)
               + temperature(zh-hz, mu))/hz**2
        return [tz, tzz]

    fit = root(conditions, initial, method="hybr", options={"xtol": 1e-10})
    zh, mu = fit.x
    residual = conditions(fit.x)
    if max(abs(residual[0]), abs(residual[1])) > 2e-3:
        raise RuntimeError(f"Cusp solve failed at n={n}: {fit.message}, {fit.x}, {residual}")
    return {"radial_integral_points": n, "zh": float(zh), "mu_CEP": float(mu),
            "T_CEP": float(temperature(zh, mu)), "solver_success": bool(fit.success),
            "residual_passed": True, "T_z_residual": float(residual[0]),
            "T_zz_residual": float(residual[1])}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", type=Path, default=MODEL)
    parser.add_argument("--output", type=Path, default=OUTPUT)
    parser.add_argument("--initial", type=float, nargs=2,
                        default=(2.17254608, 0.53843573), metavar=("ZH", "MU_B"))
    args = parser.parse_args()
    rows = []
    for n in (6000, 12000, 24000, 48000):
        rows.append(solve_cusp(args.model, n, args.initial))
        print(rows[-1], flush=True)
    final = rows[-1]
    report = {
        "model": args.model.name,
        "T_CEP_GeV": final["T_CEP"], "muB_CEP_GeV": final["mu_CEP"],
        "z_h_CEP": final["zh"], "T_CEP_MeV": 1000*final["T_CEP"],
        "muB_CEP_MeV": 1000*final["mu_CEP"],
        "muB_over_T_CEP": final["mu_CEP"]/final["T_CEP"],
        "method": "fixed-mu cusp: dT/dz_h = d2T/dz_h2 = 0",
        "precision_check": {
            "integration_points": [r["radial_integral_points"] for r in rows],
            "muB_CEP_GeV": [r["mu_CEP"] for r in rows],
            "T_CEP_GeV": [r["T_CEP"] for r in rows],
            "residual_passed": [r["residual_passed"] for r in rows],
        },
        "caveat": "Geometric EMD cusp of a single LQCD-only fit; not a direct QCD CEP determination. No HRG constraints or multi-seed stability assessment.",
    }
    args.output.write_text(json.dumps(report, indent=2) + "\n")
    print("saved:", args.output)


if __name__ == "__main__":
    main()
