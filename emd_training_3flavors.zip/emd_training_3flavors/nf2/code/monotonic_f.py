"""Positive, monotonically non-increasing gauge kinetic function."""

import math

import numpy as np
import torch
from torch import nn


def pava_decreasing(values):
    """Least-squares projection onto a non-increasing sequence."""
    levels, weights, starts, ends = [], [], [], []
    for i, value in enumerate(np.asarray(values, dtype=float)):
        levels.append(float(value))
        weights.append(1.0)
        starts.append(i)
        ends.append(i)
        while len(levels) >= 2 and levels[-2] < levels[-1]:
            weight = weights[-2] + weights[-1]
            level = (weights[-2] * levels[-2] + weights[-1] * levels[-1]) / weight
            levels[-2:] = [level]
            weights[-2:] = [weight]
            ends[-2:] = [ends[-1]]
            starts.pop()
    out = np.empty(len(values), dtype=float)
    for level, start, end in zip(levels, starts, ends):
        out[start:end + 1] = level
    return out


def inverse_softplus(x):
    x = np.asarray(x, dtype=np.float64)
    return np.where(x > 20.0, x, np.log(np.expm1(x)))


class MonotonicF(nn.Module):
    """Piecewise-linear log f(log z) with a hard non-positive derivative."""

    def __init__(self, log_z_knots, log_f_knots, min_slope=1.0e-5):
        super().__init__()
        lz = torch.as_tensor(log_z_knots, dtype=torch.float32)
        lf = torch.as_tensor(log_f_knots, dtype=torch.float32)
        self.register_buffer("log_z", lz)
        self.register_buffer("dx", lz[1:] - lz[:-1])
        self.min_slope = float(min_slope)
        slopes = ((lf[:-1] - lf[1:]) / self.dx).clamp_min(
            self.min_slope + 1.0e-6)
        raw = inverse_softplus((slopes - self.min_slope).cpu().numpy())
        self.log_f0 = nn.Parameter(lf[:1].clone())
        self.raw_slopes = nn.Parameter(torch.as_tensor(raw, dtype=torch.float32))

    def knot_values(self):
        slopes = torch.nn.functional.softplus(self.raw_slopes) + self.min_slope
        drops = slopes * self.dx
        return self.log_f0 - torch.cat((torch.zeros_like(self.log_f0),
                                       torch.cumsum(drops, dim=0)))

    def forward(self, z):
        x = z.reshape(-1).clamp_min(math.exp(float(self.log_z[0])))
        lx = torch.log(x).clamp(self.log_z[0], self.log_z[-1])
        idx = torch.searchsorted(self.log_z.detach(), lx.detach()).clamp(
            1, self.log_z.numel() - 1)
        y = self.knot_values()
        w = ((lx - self.log_z[idx - 1]) /
             (self.log_z[idx] - self.log_z[idx - 1]).clamp_min(1.0e-12))
        log_f = y[idx - 1] + w * (y[idx] - y[idx - 1])
        return torch.exp(log_f.clamp_min(-80.0))


class SmoothMonotonicF(nn.Module):
    """Cubic B-spline log f(log z) with non-increasing coefficients."""

    def __init__(self, log_z_knots, log_f_knots, min_drop=1.0e-6):
        super().__init__()
        lz = torch.as_tensor(log_z_knots, dtype=torch.float32)
        lf = torch.as_tensor(log_f_knots, dtype=torch.float32)
        if lz.numel() != lf.numel() or lz.numel() < 4:
            raise ValueError("at least four matching spline knots are required")
        if not torch.all(lz[1:] > lz[:-1]):
            raise ValueError("spline knots must be strictly increasing")
        if not torch.allclose((lz[1:] - lz[:-1]),
                              (lz[1] - lz[0]).expand_as(lz[1:])):
            raise ValueError("cubic B-spline knots must be uniform in log z")
        self.register_buffer("log_z", lz)
        self.register_buffer("dx", lz[1] - lz[0])
        self.min_drop = float(min_drop)
        drops = (lf[:-1] - lf[1:]).clamp_min(self.min_drop + 1.0e-7)
        raw = inverse_softplus((drops - self.min_drop).cpu().numpy())
        self.log_f0 = nn.Parameter(lf[:1].clone())
        self.raw_drops = nn.Parameter(torch.as_tensor(raw, dtype=torch.float32))

    def coefficients(self):
        drops = torch.nn.functional.softplus(self.raw_drops) + self.min_drop
        return self.log_f0 - torch.cat((torch.zeros_like(self.log_f0),
                                       torch.cumsum(drops, dim=0)))

    def forward(self, z):
        x = z.reshape(-1).clamp_min(math.exp(float(self.log_z[0])))
        lx = torch.log(x).clamp(self.log_z[0], self.log_z[-1])
        u = (lx - self.log_z[0]) / self.dx
        idx = torch.floor(u).to(torch.long).clamp(0, self.log_z.numel() - 2)
        t = (u - idx.to(u.dtype)).clamp(0.0, 1.0)
        c = self.coefficients()
        padded = torch.cat((c[:1], c, c[-1:]))
        c0, c1, c2, c3 = (padded[idx + offset] for offset in range(4))
        log_f = ((1.0 - t)**3 * c0
                 + (3.0*t**3 - 6.0*t**2 + 4.0) * c1
                 + (-3.0*t**3 + 3.0*t**2 + 3.0*t + 1.0) * c2
                 + t**3 * c3) / 6.0
        return torch.exp(log_f.clamp_min(-80.0))
