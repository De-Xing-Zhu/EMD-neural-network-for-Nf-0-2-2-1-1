#!/usr/bin/env python3
"""GPU-only Nf=2+1+1 fit; published lattice inputs, no HRG targets/anchor."""
import argparse
import gc
import json
import shutil
from pathlib import Path

import torch

from evaluate_nf211_nohrg import evaluate
from train_nf211 import BASE, save, train, load_targets


def score(metrics):
    return (metrics["s_over_T3"]["chi2_per_point"] +
            metrics["p_over_T4"]["chi2_per_point"] +
            metrics["e_over_T4"]["chi2_per_point"] +
            metrics["I_over_T4"]["chi2_per_point"] +
            metrics["chi2B"]["chi2_per_point"] +
            0.2 * metrics["nB_Taylor_muhat1"]["chi2_per_point"] +
            metrics["nB_minus_chi2"]["chi2_per_point"])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--phase1", type=int, default=12000)
    ap.add_argument("--phase2", type=int, default=5000)
    ap.add_argument("--seeds", type=int, default=3)
    ap.add_argument("--hidden", type=int, default=64)
    ap.add_argument("--depth", type=int, default=4)
    ap.add_argument("--n-zh", type=int, default=320)
    ap.add_argument("--n-int", type=int, default=160)
    a = ap.parse_args()
    if not torch.cuda.is_available():
        raise SystemExit("CUDA unavailable in this process; no CPU training started. "
                         "Run from the host terminal with CUDA PyTorch.")
    free, total = torch.cuda.mem_get_info(0)
    print(f"GPU: {torch.cuda.get_device_name(0)}; free {free/2**30:.2f}/"
          f"{total/2**30:.2f} GiB", flush=True)
    if free < 3 * 2**30:
        raise SystemExit("Less than 3 GiB GPU memory free; training not started.")
    if a.seeds < 1 or a.phase1 < 1 or a.phase2 < 0:
        raise SystemExit("Invalid run lengths")
    D = load_targets("cuda", no_hrg=True)
    assert D["n_hrg_s"] == D["n_hrg_c"] == 0
    print(f"Published LQCD points: EOS={D['n_lat_s']}, chi2={D['n_lat_c']}; "
          f"Taylor nB={len(D['T_r'])}. HRG=0.", flush=True)
    del D
    root = Path(BASE) / "results/nohrg"
    root.mkdir(parents=True, exist_ok=True)
    summary = []
    for seed in range(a.seeds):
        dest = root / f"seed{seed}"
        final = dest / "Nf211_A_f.npz"
        report = dest / "evaluation.json"
        if final.exists() and report.exists():
            print(f"seed {seed}: existing result; reusing", flush=True)
            r = json.loads(report.read_text())
        else:
            print(f"=== seed {seed} ===", flush=True)
            fit = train(phase1=a.phase1, phase2=a.phase2, device="cuda",
                        seed=seed, hidden=a.hidden, depth=a.depth,
                        n_zh=a.n_zh, n_int=a.n_int, no_hrg=True)
            fit["meta"].update(seed=seed, source="published lattice only",
                               pressure_anchor="Borsanyi2025 p/T4 at 120 MeV")
            save(fit, dest)
            del fit
            gc.collect()
            torch.cuda.empty_cache()
            r = evaluate(final, figure_dir=None, do_cep=False, device="cuda")
            report.write_text(json.dumps(r, indent=2))
        r["seed"] = seed
        r["score"] = score(r["metrics"])
        summary.append(r)
        print(f"seed {seed}: EOS/chi score={r['score']:.3f}", flush=True)
    winner = min(summary, key=lambda x: x["score"])
    sd = root / f"seed{winner['seed']}"
    for name in ("Nf211_A_f.npz", "Nf211_A_f_mu0only.npz", "Nf211_history.json"):
        shutil.copy2(sd / name, root / name)
    print(f"Selected seed {winner['seed']}; evaluating EOS and CEP", flush=True)
    result = evaluate(root / "Nf211_A_f.npz", Path(BASE)/"figures/nohrg",
                      do_cep=True, device="cuda")
    result["winner_seed"] = winner["seed"]
    result["all_seed_scores"] = [{"seed": x["seed"], "score": x["score"]}
                                 for x in summary]
    result["quality_gate"] = bool(
        all(result["metrics"][k]["chi2_per_point"] < 1.5
            for k in ("s_over_T3", "p_over_T4", "e_over_T4", "I_over_T4")) and
        result["metrics"]["chi2B"]["chi2_per_point"] < 2.0 and
        result["metrics"]["nB_Taylor_muhat1"]["chi2_per_point"] < 2.0 and
        result["metrics"]["nB_minus_chi2"]["chi2_per_point"] < 2.0 and
        result.get("cep_stable", False))
    (root / "evaluation.json").write_text(json.dumps(result, indent=2, default=float))
    print(json.dumps({"winner_seed": winner["seed"],
                      "quality_gate": result["quality_gate"],
                      "metrics": result["metrics"],
                      "cep": result.get("cep_resolution_4800")},
                     indent=2, default=float), flush=True)
    print(f"Result: {root/'evaluation.json'}", flush=True)


if __name__ == "__main__":
    main()
