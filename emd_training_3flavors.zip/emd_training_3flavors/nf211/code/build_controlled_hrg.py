#!/usr/bin/env python3
"""Build the HRG extension without replacing any high-temperature LQCD input."""
import argparse
import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
HRG_FRAC = 0.05
TAG = "controlled_hrg"


def smoothstep(x):
    x = np.clip(x, 0.0, 1.0)
    return x * x * (3.0 - 2.0 * x)


def blend(grid, low, high, start, end):
    weight = smoothstep((grid - start) / (end - start))
    return (1.0 - weight) * low + weight * high


def main():
    global HRG_FRAC, TAG
    ap = argparse.ArgumentParser()
    ap.add_argument("--tolerance", type=float, default=HRG_FRAC)
    ap.add_argument("--match-shift", type=float, default=0.0,
                    help="Common matching-temperature shift in MeV")
    ap.add_argument("--taylor-order", type=int, choices=(4, 6), default=4)
    ap.add_argument("--tag", default=TAG)
    args = ap.parse_args()
    if not 0 < args.tolerance < 1:
        raise ValueError("HRG tolerance must lie between zero and one")
    HRG_FRAC, TAG = args.tolerance, args.tag
    shift = args.match_shift / 1000.0
    h0 = np.genfromtxt(DATA / "hrg_Nf211_thermo_susc.csv", delimiter=",", names=True)
    h1 = np.genfromtxt(DATA / "hrg_Nf211_muhat1.csv", delimiter=",", names=True)
    eos = np.genfromtxt(DATA / "Nf211_lattice_s.csv", delimiter=",", names=True)
    wb = np.loadtxt(DATA / "WB-chiB-1805.04445.dat")
    tw = wb[:, 0] / 1000.0
    chi2, dchi2 = wb[:, 1], wb[:, 2]
    delta = wb[:, 3] / 6.0
    ddelta = wb[:, 4] / 6.0
    if args.taylor_order == 6:
        delta = delta + wb[:, 5] / 120.0
        ddelta = np.hypot(ddelta, wb[:, 6] / 120.0)
    nref = chi2 + delta

    ts0, ts1 = 0.120 + shift, 0.135 + shift
    fs = float(np.interp(ts0, eos["T"], eos["s_over_T3"]) /
               np.interp(ts0, h0["TGeV"], h0["sT3"]))
    ts = np.arange(0.080, ts1 + 0.0001, 0.001)
    hs = fs * np.interp(ts, h0["TGeV"], h0["sT3"])
    ys = blend(ts, hs, np.interp(ts, eos["T"], eos["s_over_T3"]), ts0, ts1)
    keep = eos["T"] > ts1
    Ts = np.concatenate([ts, eos["T"][keep]])
    Ys = np.concatenate([ys, eos["s_over_T3"][keep]])
    Ss = np.concatenate([HRG_FRAC * np.abs(ys), eos["ds_over_T3"][keep]])
    Ks = np.concatenate([
        np.where(ts < ts0, "hrg", "hrg-lattice blend"),
        np.full(keep.sum(), "lattice:Borsanyi2025")])

    tc0, tc1 = 0.135 + shift, 0.150 + shift
    fc = float(np.interp(tc0, tw, chi2) / np.interp(tc0, h0["TGeV"], h0["chi2B"]))
    tc = np.arange(0.080, tc1 + 0.0001, 0.001)
    hc = fc * np.interp(tc, h0["TGeV"], h0["chi2B"])
    yc = blend(tc, hc, np.interp(tc, tw, chi2), tc0, tc1)
    keep = tw > tc1
    Tc = np.concatenate([tc, tw[keep]])
    Yc = np.concatenate([yc, chi2[keep]])
    Sc = np.concatenate([HRG_FRAC * np.abs(yc), dchi2[keep]])
    Kc = np.concatenate([
        np.where(tc < tc0, "hrg", "hrg-lattice blend"),
        np.full(keep.sum(), "lattice:WB2018 Nt12")])

    tn0, tn1 = float(tw[1]) + shift, float(tw[4]) + shift
    fn = float(np.interp(tn0, tw, nref) / np.interp(tn0, h1["TGeV"], h1["nBT3"]))
    tn = np.arange(0.080, tn1 + 0.0001, 0.001)
    hn = fn * np.interp(tn, h1["TGeV"], h1["nBT3"])
    hc_at_n = fc * np.interp(tn, h0["TGeV"], h0["chi2B"])
    hd = hn - hc_at_n
    yd = blend(tn, hd, np.interp(tn, tw, delta), tn0, tn1)
    keep = tw > tn1
    Td = np.concatenate([tn, tw[keep]])
    Yd = np.concatenate([yd, delta[keep]])
    Sd = np.concatenate([
        HRG_FRAC * np.maximum(np.abs(yd), 1e-4),
        np.hypot(ddelta[keep], 0.10 * np.abs(nref[keep]))])
    density_label = ("lattice-Taylor:WB2018 chi4/6" if args.taylor_order == 4
                     else "lattice-Taylor:WB2018 through chi6")
    Kd = np.concatenate([
        np.where(tn < tn0, "hrg", "hrg-lattice blend"),
        np.full(keep.sum(), density_label)])

    outputs = [
        ("s", Ts, Ys, Ss, Ks, "s_over_T3"),
        ("chi", Tc, Yc, Sc, Kc, "chi2B"),
        ("delta", Td, Yd, Sd, Kd, "nB_minus_chi2"),
    ]
    paths = {}
    prefix = "Nf211_controlled" if TAG == "controlled_hrg" else f"Nf211_{TAG}"
    for stem, t, y, sig, kind, yname in outputs:
        path = DATA / f"{prefix}_{stem}.csv"
        with path.open("w") as f:
            f.write(f"T,{yname},sigma,kind\n")
            for row in zip(t, y, sig, kind):
                f.write("%.9f,%.12e,%.12e,%s\n" % row)
        paths[stem] = str(path)

    meta = {
        "variant": TAG,
        "rule": "low-temperature HRG extension only; all high-temperature arrays equal the lattice-only arrays",
        "hrg_model_tolerance": HRG_FRAC,
        "taylor_order": args.taylor_order,
        "pressure_anchor": "Borsanyi2025 p/T4 at 120 MeV for both fits",
        "entropy": {"match_GeV": ts0, "blend_end_GeV": ts1, "factor": fs},
        "chi2B": {"match_GeV": tc0, "blend_end_GeV": tc1, "factor": fc},
        "density_increment": {"match_GeV": tn0, "blend_end_GeV": tn1,
                              "nB_factor": fn, "chi2_factor": fc},
        "targets": paths,
    }
    meta_path = DATA / ("Nf211_controlled_hrg_meta.json" if TAG == "controlled_hrg"
                        else f"Nf211_{TAG}_meta.json")
    meta_path.write_text(json.dumps(meta, indent=2) + "\n")
    print(json.dumps(meta, indent=2))


if __name__ == "__main__":
    main()
