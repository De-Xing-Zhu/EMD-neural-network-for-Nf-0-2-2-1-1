#!/usr/bin/env python3
"""Run the central-fit lattice-only/HRG comparison from one shared checkpoint."""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import torch

from emd_free import A_net, EMD, F_net
from evaluate_nf211_nohrg import evaluate
from train_nf211 import pretrain_background, save, train

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results/controlled_pair"
PROTOCOL = dict(seed=0, phase1=12000, phase2=5000, hidden=64, depth=4,
                n_zh=320, n_int=160, pretrain_steps=1500, lr=1e-3,
                lr2=3e-4, lr_min=1e-6, ema_decay=0.999, eval_every=25,
                w_reg=1e-6, w_phi=1000.0, hrg_frac=0.05, rho_scale=1.0,
                rho_warmup=0.35, G_init=0.391, G_range=(0.05, 2.0),
                zh_max=20.0, pressure_anchor="LQCD p/T4 at 120 MeV")


def make_checkpoint(path):
    torch.manual_seed(PROTOCOL["seed"])
    np.random.seed(PROTOCOL["seed"])
    a = A_net(hidden=PROTOCOL["hidden"], depth=PROTOCOL["depth"],
              act="tanh", form="constrained").cuda()
    f = F_net(hidden=PROTOCOL["hidden"], depth=PROTOCOL["depth"], act="tanh").cuda()
    model = EMD(a, f, G=PROTOCOL["G_init"], G_range=PROTOCOL["G_range"],
                n_int=PROTOCOL["n_int"]).cuda()
    loss = pretrain_background(a, f, "cuda", steps=PROTOCOL["pretrain_steps"])
    torch.save(model.state_dict(), path)
    return model.state_dict(), loss


def check_inputs():
    import train_nf211
    pure = train_nf211.load_targets("cpu", no_hrg=True,
                                    taylor_order=PROTOCOL.get("taylor_order", 4))
    hrg = train_nf211.load_targets("cpu", controlled_hrg=True,
                                   target_tag=PROTOCOL.get("target_tag"))
    common = {}
    blocks = (("entropy", "T_s", "y_s", "sig_s"),
              ("chi2B", "T_c", "y_c", "sig_c"),
              ("density_increment", "T_r", "y_r", "sig_r_cond"))
    for label, tkey, ykey, skey in blocks:
        pt, ht = pure[tkey].numpy(), hrg[tkey].numpy()
        py = pure[ykey].numpy()
        if ykey == "y_r":
            py = py - pure["y_r_chi2"].numpy()
        n_common = 0
        for n in range(pt.size, 0, -1):
            same = (np.allclose(pt[-n:], ht[-n:], rtol=0, atol=1e-7) and
                    np.allclose(py[-n:], hrg[ykey].numpy()[-n:], rtol=1e-6, atol=1e-7) and
                    np.allclose(pure[skey].numpy()[-n:], hrg[skey].numpy()[-n:],
                                rtol=1e-6, atol=1e-8))
            if same:
                n_common = n
                break
        assert n_common >= 1
        for i in range(pt.size-n_common, pt.size):
            j = ht.size-(pt.size-i)
            assert np.allclose(py[i], hrg[ykey].numpy()[j], rtol=1e-6, atol=1e-7), ykey
            assert np.allclose(pure[skey].numpy()[i], hrg[skey].numpy()[j],
                               rtol=1e-6, atol=1e-8), skey
        common[label] = n_common
    prefix = "Nf211_controlled" if PROTOCOL.get("target_tag") is None else f"Nf211_{PROTOCOL['target_tag']}"
    filenames = ("Nf211_lattice_s.csv", "WB-chiB-1805.04445.dat",
                 prefix + "_s.csv", prefix + "_chi.csv", prefix + "_delta.csv",
                 "hrg_Nf211_thermo_susc.csv", "hrg_Nf211_muhat1.csv")
    for filename in filenames:
        digest = hashlib.sha256((ROOT / "data" / filename).read_bytes()).hexdigest()
        PROTOCOL.setdefault("input_sha256", {})[filename] = digest
    total = {"entropy": len(pure["T_s"]), "chi2B": len(pure["T_c"]),
             "density_increment": len(pure["T_r"])}
    hrg_total = {"entropy": len(hrg["T_s"]), "chi2B": len(hrg["T_c"]),
                 "density_increment": len(hrg["T_r"])}
    return {"lattice_only_total_points": total,
            "shared_high_temperature_points": common,
            "replaced_low_temperature_points": {k: total[k]-common[k] for k in total},
            "hrg_and_blend_target_points": {k: hrg_total[k]-common[k] for k in total}}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--phase1", type=int, default=PROTOCOL["phase1"])
    ap.add_argument("--phase2", type=int, default=PROTOCOL["phase2"])
    ap.add_argument("--seed", type=int, default=PROTOCOL["seed"])
    ap.add_argument("--rho-scale", type=float, default=PROTOCOL["rho_scale"])
    ap.add_argument("--hrg-frac", type=float, default=PROTOCOL["hrg_frac"])
    ap.add_argument("--taylor-order", type=int, choices=(4, 6), default=4)
    ap.add_argument("--chi4-scale", type=float, default=0.0)
    ap.add_argument("--closure-f", action="store_true")
    ap.add_argument("--f0", type=float, default=0.4)
    ap.add_argument("--w-reg", type=float, default=PROTOCOL["w_reg"])
    ap.add_argument("--w-phi", type=float, default=PROTOCOL["w_phi"])
    ap.add_argument("--controlled-tag")
    ap.add_argument("--output", default=str(OUT))
    ap.add_argument("--skip-cep", action="store_true")
    args = ap.parse_args()
    if not torch.cuda.is_available():
        raise SystemExit("CUDA is required")
    if args.chi4_scale and args.taylor_order != 4:
        raise SystemExit("Direct chi4 training currently requires --taylor-order 4")
    PROTOCOL.update(phase1=args.phase1, phase2=args.phase2, seed=args.seed,
                    rho_scale=args.rho_scale, hrg_frac=args.hrg_frac,
                    w_reg=args.w_reg, w_phi=args.w_phi,
                    target_tag=args.controlled_tag, taylor_order=args.taylor_order,
                    chi4_scale=args.chi4_scale, closure_f=args.closure_f, f0=args.f0)
    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    audit = check_inputs()
    checkpoint = out / "shared_analytic_warm_start.pt"
    if checkpoint.exists():
        state = torch.load(checkpoint, map_location="cuda", weights_only=True)
        pretrain_loss = None
    else:
        state, pretrain_loss = make_checkpoint(checkpoint)
    protocol = dict(protocol=PROTOCOL, input_audit=audit,
                    pretrain_loss=pretrain_loss,
                    checkpoint_sha256=hashlib.sha256(checkpoint.read_bytes()).hexdigest())
    (out / "protocol.json").write_text(json.dumps(protocol, indent=2) + "\n")
    train_protocol = {k: v for k, v in PROTOCOL.items()
                      if k not in ("pressure_anchor", "input_sha256")}
    for label, hrg in (("lattice_only", False), ("hrg_lqcd", True)):
        dest = out / label
        print(f"=== {label}: controlled_hrg={hrg} ===", flush=True)
        fit = train(device="cuda", no_hrg=not hrg, controlled_hrg=hrg,
                    initial_state=state, verbose=True, **train_protocol)
        fit["meta"].update(fit=label,
                           central_fit=args.seed == 0 and out.resolve() == OUT.resolve(),
                           pressure_anchor=PROTOCOL["pressure_anchor"])
        save(fit, dest)
        result = evaluate(dest / "Nf211_A_f.npz", do_cep=not args.skip_cep,
                          device="cuda")
        result["fit"] = label
        result["controlled_protocol"] = str(out / "protocol.json")
        (dest / "evaluation.json").write_text(json.dumps(result, indent=2, default=float) + "\n")
        print(json.dumps({"fit": label, "metrics": result["metrics"],
                          "cusp": result.get("cep_resolution_4800")}, indent=2), flush=True)


if __name__ == "__main__":
    main()
