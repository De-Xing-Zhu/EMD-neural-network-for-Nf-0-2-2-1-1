#!/usr/bin/env python3
"""Audit the HRG-free Nf=2+1+1 EMD result against published tables."""
import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch

from emd_free import emd_mu0_curve, find_cep, load_trained

BASE = Path(__file__).resolve().parents[1]
LAT = BASE / "data/Nf211_lattice_s.csv"
WB = BASE / "data/WB-chiB-1805.04445.dat"


def branch(x, *ys):
    x = np.asarray(x)
    keep = np.isfinite(x) & (x > 0)
    for y in ys:
        keep &= np.isfinite(y)
    order = np.argsort(x[keep])
    xx = x[keep][order]
    yy = [np.asarray(y)[keep][order] for y in ys]
    unique, index = np.unique(xx, return_index=True)
    return (unique, *[y[index] for y in yy])


def evaluate(path, figure_dir=None, do_cep=True, device="cpu"):
    model = load_trained(str(path), n_int=700).to(device)
    model.eval()
    lat = np.genfromtxt(LAT, delimiter=",", names=True)
    wb = np.loadtxt(WB)
    tl = lat["T"]
    tc = wb[:, 0] / 1000.0
    tm, sm, _ = emd_mu0_curve(model, zmax=20, n=2200)
    if tm[0] > tl[0] or tm[-1] < tl[-1]:
        raise ValueError(f"mu=0 branch does not cover lattice EOS: {tm[0]:.4f}..{tm[-1]:.4f}")
    sg = np.interp(tl, tm, sm)
    # LQCD's independently determined pressure at 120 MeV fixes the constant.
    p = np.empty_like(tl)
    p[0] = lat["p_over_T4"][0] * tl[0] ** 4
    for i in range(1, len(tl)):
        # Dense EMD s(T) integration prevents a coarse 5 MeV quadrature bias.
        grid = np.linspace(tl[i-1], tl[i], 21)
        p[i] = p[i-1] + np.trapz(np.interp(grid, tm, sm) * grid**3, grid)
    pg = p / tl**4
    eg, ig = sg - pg, sg - 4 * pg
    eos = {"s_over_T3": sg, "p_over_T4": pg,
           "e_over_T4": eg, "I_over_T4": ig}
    metrics = {}
    for name, pred, sigma in [
        ("s_over_T3", sg, lat["ds_over_T3"]),
        ("p_over_T4", pg, lat["dp_over_T4"]),
        ("e_over_T4", eg, lat["de_over_T4"]),
        ("I_over_T4", ig, lat["dI_over_T4"])]:
        obs = lat[name]
        resid = pred - obs
        metrics[name] = {"rms_percent": float(np.sqrt(np.mean((100*resid/obs)**2))),
                         "max_percent": float(np.max(np.abs(100*resid/obs))),
                         "chi2_per_point": float(np.mean((resid/sigma)**2)),
                         "within_2sigma": int(np.sum(np.abs(resid) <= 2*sigma)),
                         "n": len(obs)}
    with torch.no_grad():
        zh = torch.exp(torch.linspace(np.log(0.02), np.log(20.), 2200,
                                      device=device))
        obs = model.observables_mu0(zh)
        tchi, chi = branch(obs["T"].cpu().numpy(), obs["chi2B"].cpu().numpy())
        nbt, nt, _ = model.nB_over_T3(zh, muhat=1.0)
        tn, nb = branch(nt.cpu().numpy(), nbt.cpu().numpy())
    if tchi[0] > tc[0] or tchi[-1] < tc[-1] or tn[0] > tc[0] or tn[-1] < tc[-1]:
        raise ValueError("model branch does not cover WB susceptibility/Taylor data")
    cg = np.interp(tc, tchi, chi)
    ng = np.interp(tc, tn, nb)
    nref = wb[:, 1] + wb[:, 3]/6.0
    nsig = np.hypot(np.hypot(wb[:, 2], wb[:, 4]/6.0), 0.1*np.abs(nref))
    for name, pred, ref, sig in [("chi2B", cg, wb[:, 1], wb[:, 2]),
                                  ("nB_Taylor_muhat1", ng, nref, nsig)]:
        metrics[name] = {"rms_percent": float(np.sqrt(np.mean((100*(pred-ref)/ref)**2))),
                         "chi2_per_point": float(np.mean(((pred-ref)/sig)**2)),
                         "within_2sigma": int(np.sum(np.abs(pred-ref) <= 2*sig)),
                         "n": len(ref)}
    dmodel = ng - cg
    dref = wb[:, 3] / 6.0
    dsig = np.hypot(wb[:, 4] / 6.0, 0.1*np.abs(nref))
    metrics["nB_minus_chi2"] = {
        "chi2_per_point": float(np.mean(((dmodel-dref)/dsig)**2)),
        "within_2sigma": int(np.sum(np.abs(dmodel-dref) <= 2*dsig)),
        "n": len(dref)}
    result = {"model": str(path), "source_eos": "arXiv:2502.10267 Table 1, Nf=2+1+1",
              "source_chi": "arXiv:1805.04445, Nf=2+1+1, Nt=12",
              "pressure_anchor": {"T_GeV": float(tl[0]),
                                  "p_over_T4": float(lat["p_over_T4"][0])},
              "metrics": metrics}
    if do_cep:
        cep_a = find_cep(model, n=2400, n_scan=45)
        cep_b = find_cep(model, n=4800, n_scan=45)
        result["cep_resolution_2400"] = cep_a
        result["cep_resolution_4800"] = cep_b
        result["cep_stable"] = bool(
            cep_a["cep_found"] and cep_b["cep_found"] and
            abs(cep_a["mu_CEP"]-cep_b["mu_CEP"]) < 0.05 and
            abs(cep_a["T_CEP"]-cep_b["T_CEP"]) < 0.01)
    if figure_dir:
        figure_dir = Path(figure_dir)
        figure_dir.mkdir(parents=True, exist_ok=True)
        fig, axs = plt.subplots(2, 3, figsize=(14, 8))
        for ax, name, ylabel in zip(axs.flat[:4], eos,
                                   [r"$s/T^3$", r"$p/T^4$", r"$\epsilon/T^4$", r"$I/T^4$"]):
            err = {"s_over_T3":"ds_over_T3", "p_over_T4":"dp_over_T4",
                   "e_over_T4":"de_over_T4", "I_over_T4":"dI_over_T4"}[name]
            ax.errorbar(tl, lat[name], yerr=lat[err], fmt="o", ms=3,
                        label="Nf=2+1+1 LQCD")
            ax.plot(tl, eos[name], "-", lw=2, label="EMD")
            ax.set(xlabel="T [GeV]", ylabel=ylabel)
            ax.grid(alpha=.25)
        for ax, tx, ref, sig, pred, ylabel in [
            (axs.flat[4], tc, wb[:,1], wb[:,2], cg, r"$\chi_2^B$"),
            (axs.flat[5], tc, nref, nsig, ng, r"$n_B/T^3$, $\mu_B/T=1$ Taylor")]:
            ax.errorbar(tx, ref, yerr=sig, fmt="o", ms=3, label="Nf=2+1+1 LQCD")
            ax.plot(tx, pred, "-", lw=2, label="EMD")
            ax.set(xlabel="T [GeV]", ylabel=ylabel)
            ax.grid(alpha=.25)
        axs.flat[0].legend()
        fig.tight_layout()
        fig.savefig(figure_dir / "eos_nohrg.png", dpi=160)
        plt.close(fig)
    return result


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default=str(BASE / "results/nohrg/Nf211_A_f.npz"))
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    ap.add_argument("--skip-cep", action="store_true")
    ap.add_argument("--figures", default=str(BASE / "figures/nohrg"))
    ap.add_argument("--output", default=None)
    a = ap.parse_args()
    result = evaluate(a.model, a.figures, not a.skip_cep, a.device)
    out = (Path(a.output) if a.output else
           Path(a.model).parent / "evaluation.json")
    out.write_text(json.dumps(result, indent=2, default=float))
    print(json.dumps(result, indent=2, default=float))
