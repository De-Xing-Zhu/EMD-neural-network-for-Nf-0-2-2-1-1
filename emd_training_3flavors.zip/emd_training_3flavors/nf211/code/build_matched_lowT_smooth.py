#!/usr/bin/env python3
"""Build exact-lowest-point matched HRG + LQCD targets for Nf=2+1+1.

The raw HRG normalization is fixed independently for each observable at the
lowest available lattice/Taylor temperature.  A 15 MeV smoothstep window then
changes from the matched HRG curve to the published high-temperature target.
"""

from pathlib import Path
import json

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
TAG = "matched_lowT_smooth"
HRG_FRAC = 0.05


def smoothstep(x):
    x = np.clip(x, 0.0, 1.0)
    return x * x * (3.0 - 2.0 * x)


def main():
    h0 = np.genfromtxt(DATA / "hrg_Nf211_thermo_susc.csv",
                       delimiter=",", names=True)
    h1 = np.genfromtxt(DATA / "hrg_Nf211_muhat1.csv",
                       delimiter=",", names=True)
    eos = np.genfromtxt(DATA / "Nf211_lattice_s.csv",
                        delimiter=",", names=True)
    chi = np.loadtxt(DATA / "Chi2B_30-800-dT1.dat")
    nb = np.genfromtxt(DATA / "Nf211_nB_muhat1.csv",
                       delimiter=",", names=True)

    # ---------------------------------------------------------- s/T^3
    ts0, ts1 = float(eos["T"][0]), 0.135
    fs = float(eos["s_over_T3"][0] /
               np.interp(ts0, h0["TGeV"], h0["sT3"]))
    gs = np.arange(0.080, ts1 + 0.0001, 0.001)
    sh = fs * np.interp(gs, h0["TGeV"], h0["sT3"])
    sl = np.interp(gs, eos["T"], eos["s_over_T3"])
    ws = smoothstep((gs - ts0) / (ts1 - ts0))
    sy = (1.0 - ws) * sh + ws * sl
    sreg = np.where(gs < ts0, "hrg", "blend")
    ml = eos["T"] > ts1
    Ts = np.concatenate([gs, eos["T"][ml]])
    Ys = np.concatenate([sy, eos["s_over_T3"][ml]])
    Ss = np.concatenate([HRG_FRAC * sy, eos["ds_over_T3"][ml]])
    Ks = np.concatenate([
        np.where(sreg == "hrg", "hrg:Thermal-FIST(Nf211,exact-match@120)",
                 "hrg-latt blend(0.120-0.135)"),
        np.full(ml.sum(), "lattice:Borsanyi2025(2502.10267,2+1+1)"),
    ])

    s_path = DATA / f"Nf211_train_s_{TAG}.csv"
    with s_path.open("w") as f:
        f.write("T,s_over_T3,sigma,kind\n")
        f.write("# raw HRG multiplied at the same T=0.120 GeV so its center "
                "equals the lowest LQCD center; smoothstep to pure LQCD by "
                "0.135 GeV\n")
        for row in zip(Ts, Ys, Ss, Ks):
            f.write("%.6f,%.10e,%.10e,%s\n" % row)

    # Thermodynamically consistent completion of the new entropy target.
    p0 = fs * float(np.interp(Ts[0], h0["TGeV"], h0["PT4"])) * Ts[0] ** 4
    integ = np.concatenate([[0.0], np.cumsum(
        0.5 * (Ys[1:] * Ts[1:] ** 3 + Ys[:-1] * Ts[:-1] ** 3) * np.diff(Ts))])
    pT4 = (p0 + integ) / Ts ** 4
    hybrid_path = DATA / f"Nf211_hybrid_eos_{TAG}.csv"
    with hybrid_path.open("w") as f:
        f.write("T,s_over_T3,I_over_T4,e_over_T4,p_over_T4,region\n")
        f.write("# exact match at 0.120 GeV; smoothstep 0.120-0.135 GeV\n")
        for t, s, p, k in zip(Ts, Ys, pT4, Ks):
            region = "hrg" if k.startswith("hrg:Thermal") else (
                "blend" if k.startswith("hrg-latt") else "latt")
            f.write("%.6f,%.10e,%.10e,%.10e,%.10e,%s\n" %
                    (t, s, s - 4.0 * p, s - p, p, region))

    # ---------------------------------------------------------- chi_2^B
    tc0, tc1 = 0.135, 0.150
    cm = (chi[:, 0] / 1000.0 >= tc0) & (chi[:, 0] / 1000.0 <= 0.250)
    Tc_l, Yc_l, Sc_l = chi[cm, 0] / 1000.0, chi[cm, 1], chi[cm, 2]
    fc = float(Yc_l[0] / np.interp(tc0, h0["TGeV"], h0["chi2B"]))
    gc = np.arange(0.080, tc1 + 0.0001, 0.001)
    ch = fc * np.interp(gc, h0["TGeV"], h0["chi2B"])
    cl = np.interp(gc, Tc_l, Yc_l)
    wc = smoothstep((gc - tc0) / (tc1 - tc0))
    cy = (1.0 - wc) * ch + wc * cl
    mc = Tc_l > tc1
    Tc = np.concatenate([gc, Tc_l[mc]])
    Yc = np.concatenate([cy, Yc_l[mc]])
    Sc = np.concatenate([HRG_FRAC * np.maximum(cy, 1e-12), Sc_l[mc]])
    Kc = np.concatenate([
        np.where(gc < tc0, "hrg:Thermal-FIST(Nf211,exact-match@135)",
                 "hrg-latt blend(0.135-0.150)"),
        np.full(mc.sum(), "lattice:JahanParotto2025(Zenodo15123623,2+1continuum)"),
    ])
    c_path = DATA / f"Nf211_train_chi_{TAG}.csv"
    with c_path.open("w") as f:
        f.write("T,chi2B,sigma,kind\n")
        f.write("# raw HRG multiplied at the same T=0.135 GeV so its center "
                "equals the lowest LQCD center; smoothstep to pure LQCD by "
                "0.150 GeV\n")
        for row in zip(Tc, Yc, Sc, Kc):
            f.write("%.6f,%.10e,%.10e,%s\n" % row)

    # ------------------------------------------------ n_B/T^3 at mu_B/T=1
    tn0, tn1 = float(nb["T"][0]), float(nb["T"][3])  # ~140 to 155 MeV
    fn = float(nb["nB_over_T3"][0] /
               np.interp(tn0, h1["TGeV"], h1["nBT3"]))
    gn_lo = h1["TGeV"][(h1["TGeV"] >= 0.080) & (h1["TGeV"] < tn0)]
    gn_blend = np.linspace(tn0, tn1, 16)
    gn = np.concatenate([gn_lo, gn_blend])
    nh = fn * np.interp(gn, h1["TGeV"], h1["nBT3"])
    nl = np.interp(gn, nb["T"], nb["nB_over_T3"])
    wn = smoothstep((gn - tn0) / (tn1 - tn0))
    ny = (1.0 - wn) * nh + wn * nl
    mn = nb["T"] > tn1
    Tn = np.concatenate([gn, nb["T"][mn]])
    Yn = np.concatenate([ny, nb["nB_over_T3"][mn]])
    Sn = np.concatenate([HRG_FRAC * np.maximum(ny, 1e-12), nb["dnB_tot"][mn]])
    Kn = np.concatenate([
        np.where(gn < tn0, "hrg:Thermal-FIST(Nf211,muhat1,exact-match@140)",
                 "hrg-latt blend(0.140-0.155)"),
        np.full(mn.sum(), "lattice-Taylor:chi2+chi4/6(muhat1)"),
    ])
    n_path = DATA / f"Nf211_nB_muhat1_{TAG}.csv"
    with n_path.open("w") as f:
        f.write("T,nB_over_T3,dnB_tot,kind\n")
        f.write("# finite-density Nf211 HRG multiplied at the same lowest "
                "Taylor temperature; smoothstep to pure Taylor target by "
                "T=%.6f GeV\n" % tn1)
        for row in zip(Tn, Yn, Sn, Kn):
            f.write("%.6f,%.10e,%.10e,%s\n" % row)

    meta = {
        "variant": TAG,
        "rule": "same-temperature HRG center equals lowest LQCD/Taylor center",
        "s_over_T3": {"T_match_GeV": ts0, "T_blend_end_GeV": ts1,
                       "factor": fs},
        "chi2B": {"T_match_GeV": tc0, "T_blend_end_GeV": tc1,
                  "factor": fc},
        "nB_over_T3_muhat1": {"T_match_GeV": tn0,
                               "T_blend_end_GeV": tn1, "factor": fn},
        "hrg_model_tolerance": HRG_FRAC,
        "targets": [str(s_path), str(c_path), str(n_path)],
    }
    meta_path = DATA / f"Nf211_{TAG}_meta.json"
    meta_path.write_text(json.dumps(meta, indent=2) + "\n")

    print("match factors: s %.8f  chi %.8f  nB %.8f" % (fs, fc, fn))
    print("blend windows [MeV]: s %.0f-%.0f  chi %.0f-%.0f  nB %.3f-%.3f" %
          (ts0 * 1000, ts1 * 1000, tc0 * 1000, tc1 * 1000,
           tn0 * 1000, tn1 * 1000))
    for path in (s_path, c_path, n_path, hybrid_path, meta_path):
        print("wrote", path)


if __name__ == "__main__":
    main()
