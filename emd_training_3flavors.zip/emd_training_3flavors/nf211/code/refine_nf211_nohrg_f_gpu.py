#!/usr/bin/env python3
"""Smooth f-only refinement of the HRG-free Nf=2+1+1 fit."""

from pathlib import Path
import json
import math

import numpy as np
import torch
from torch import nn

from emd_free import EMD, InterpNet
from train_nf211 import _interp, load_targets

BASE = Path(__file__).resolve().parents[1]
SOURCE = BASE / "results/nohrg/Nf211_A_f.npz"
OUTPUT = BASE / "results/nohrg/Nf211_A_f_nohrg_best.npz"


class CorrectedF(nn.Module):
    def __init__(self, z, f, n_centers=40):
        super().__init__()
        self.base = InterpNet(z, f)
        c = torch.linspace(math.log(.45), math.log(8.), n_centers)
        self.register_buffer("centers", c)
        self.width = 1.8 * float(c[1] - c[0])
        self.coeff = nn.Parameter(torch.zeros(n_centers))

    def forward(self, z):
        x = z.reshape(-1).clamp_min(1e-8)
        basis = torch.exp(-.5 * ((torch.log(x)[:, None] -
                                  self.centers[None, :]) / self.width) ** 2)
        return self.base(x) * torch.exp(.35 * torch.tanh(basis @ self.coeff))


def branch(t, y):
    order = torch.argsort(t.detach())
    return t[order], y[order]


def main():
    if not torch.cuda.is_available():
        raise SystemExit("CUDA unavailable; no CPU refinement started")
    with np.load(SOURCE, allow_pickle=False) as d:
        z, A, f, G = (d[k].copy() for k in ("z", "A", "f", "G"))
    model = EMD(InterpNet(z, A), CorrectedF(z, f), G=float(G),
                n_int=250).cuda()
    model.G.requires_grad_(False)
    D = load_targets("cuda", no_hrg=True)
    zh = torch.exp(torch.linspace(math.log(.02), math.log(20.), 600,
                                  device="cuda"))
    opt = torch.optim.Adam([model.f_net.coeff], lr=.008)
    best = (True, float("inf"))
    best_coeff = None
    history = []
    for ep in range(1801):
        opt.zero_grad(set_to_none=True)
        o = model.observables_mu0(zh)
        tc, chi = branch(o["T"], o["chi2B"])
        rc = (_interp(tc, chi, D["T_c"]) - D["y_c"]) / D["sig_c"]
        nb, tnb, _ = model.nB_over_T3(zh, muhat=1.)
        tn, nb = branch(tnb, nb)
        dm = _interp(tn, nb, D["T_r"]) - _interp(tc, chi, D["T_r"])
        rd = (dm - (D["y_r"] - D["y_r_chi2"])) / D["sig_r_cond"]
        c = model.f_net.coeff
        reg = .005 * c.square().mean() + .02 * (
            c[2:] - 2*c[1:-1] + c[:-2]).square().mean()
        tail = .35 * torch.relu(rc.abs()-1.8).square().mean() + \
            .15 * torch.relu(rd.abs()-1.8).square().mean()
        loss = rc.square().mean() + rd.square().mean() + tail + reg
        vals = (float(torch.sqrt(rc.square().mean()).detach()),
                float(rc.abs().max().detach()),
                float(torch.sqrt(rd.square().mean()).detach()),
                float(rd.abs().max().detach()))
        gate = vals[0] <= 1 and vals[1] <= 2 and vals[2] <= 1 and vals[3] <= 2
        score = vals[0]**2 + vals[2]**2 + .1*(vals[1]**2 + vals[3]**2)
        key = (not gate, score)
        if key < best:
            best, best_coeff = key, c.detach().clone()
        if ep % 200 == 0 or ep == 1800:
            row = dict(epoch=ep, chi_rms=vals[0], chi_max=vals[1],
                       nB_cond_rms=vals[2], nB_cond_max=vals[3], gate=gate)
            history.append(row)
            print(row, flush=True)
        if ep == 1800:
            break
        loss.backward()
        torch.nn.utils.clip_grad_norm_([c], 2.)
        opt.step()
        frac = ep / 1799
        opt.param_groups[0]["lr"] = 1e-4 + .5*(.008-1e-4)*(
            1+math.cos(math.pi*frac))
    with torch.no_grad():
        model.f_net.coeff.copy_(best_coeff)
        fnew = model.f_net(torch.tensor(z, device="cuda")).cpu().numpy()
    np.savez(OUTPUT, z=z, A=A, f=fnew, G=G, no_hrg=True,
             method="lattice-only s+chi2+(nB-chi2); smooth f refinement",
             source=SOURCE.name)
    report = {"source": SOURCE.name, "model": OUTPUT.name,
              "quality_gate_passed": not best[0], "selected_key": best,
              "history": history}
    (OUTPUT.parent / "f_refinement.json").write_text(
        json.dumps(report, indent=2) + "\n")
    print("saved", OUTPUT, "gate", not best[0], flush=True)


if __name__ == "__main__":
    main()
