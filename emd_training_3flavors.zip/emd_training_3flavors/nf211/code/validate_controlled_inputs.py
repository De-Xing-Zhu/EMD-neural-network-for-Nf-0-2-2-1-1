#!/usr/bin/env python3
"""Validate controlled-input continuity and the common pressure normalization."""
import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
PAIR = ROOT / "results/controlled_pair"
DATA = ROOT / "data"


def main():
    report = {"blend_checks": {}, "pressure": {}}
    for name, windows in {
        "s": [(0.120, 0.135)],
        "chi": [(0.135, 0.150)],
        "delta": [(0.14000899959946722, 0.1550059998494656)],
    }.items():
        d = np.genfromtxt(DATA/f"Nf211_controlled_{name}.csv", delimiter=",", names=True,
                          usecols=(0, 1, 2))
        t, y = d["T"], d[d.dtype.names[1]]
        dy = np.gradient(y, t)
        checks = []
        for point in windows[0]:
            checks.append({"T_GeV": point,
                           "value_jump": float(abs(np.interp(point-1e-7, t, y)-np.interp(point+1e-7, t, y))),
                           "derivative_jump": float(abs(np.interp(point-1e-7, t, dy)-np.interp(point+1e-7, t, dy)))})
        report["blend_checks"][name] = checks
        assert all(c["value_jump"] < 2e-5 and c["derivative_jump"] < 1e-3 for c in checks)
    lat = np.genfromtxt(DATA/"Nf211_lattice_s.csv", delimiter=",", names=True)
    for label in ("lattice_only", "hrg_lqcd"):
        d = np.genfromtxt(PAIR/label/"eos_common_anchor.csv", delimiter=",", names=True)
        value = float(np.interp(.120, d["T"], d["p_over_T4"]))
        report["pressure"][label] = {"p_over_T4_at_120MeV": value}
        assert abs(value-lat["p_over_T4"][0]) < 5e-6
    report["status"] = "passed"
    (PAIR/"input_and_pressure_validation.json").write_text(json.dumps(report, indent=2)+"\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
