#!/usr/bin/env python3
"""Evaluate EOS, cusp convergence, and physical checks for the controlled pair."""
import argparse
import json
from pathlib import Path

import numpy as np
import torch
from scipy.integrate import cumulative_trapezoid
from scipy.interpolate import CubicSpline
from scipy.optimize import root

from emd_free import curve_mu, emd_mu0_curve, load_trained, turning_points

ROOT = Path(__file__).resolve().parents[1]
PAIR = ROOT / "results/controlled_pair"
OUT = ROOT.parent / "paper_3flavors/results_revision"
LAT = np.genfromtxt(ROOT / "data/Nf211_lattice_s.csv", delimiter=",", names=True)


def sorted_curve(model, zmax=20.0, n=6000):
    t, s, zh = emd_mu0_curve(model, zmax=zmax, n=n)
    return np.asarray(t), np.asarray(s), np.asarray(zh)


def eos_curve(model):
    t, s, zh = sorted_curve(model)
    grid = np.linspace(max(0.080, t[0]), min(0.295, t[-1]), 1600)
    sg = np.interp(grid, t, s)
    integral = cumulative_trapezoid(sg * grid**3, grid, initial=0.0)
    t0 = float(LAT["T"][0])
    p0 = float(LAT["p_over_T4"][0])
    const = p0 * t0**4 - np.interp(t0, grid, integral)
    p = (integral + const) / grid**4
    ds = CubicSpline(grid, sg)(grid, 1)
    cs2 = sg / (3 * sg + grid * ds)
    return dict(T=grid, s_over_T3=sg, p_over_T4=p,
                e_over_T4=sg-p, I_over_T4=sg-4*p, cs2=cs2)


def maxwell_ratio(path, zh, n=12000):
    d = np.load(path)
    z = np.linspace(1e-4, zh, n)
    A = CubicSpline(d["z"], d["A"])(z)
    cs = CubicSpline(z, A)
    f = np.exp(CubicSpline(d["z"], np.log(d["f"]))(z))
    q1 = z**3 * np.exp(-3*A)
    q2 = z * np.exp(-A) / f
    i1 = cumulative_trapezoid(q1, z, initial=0.0)
    i2 = cumulative_trapezoid(q2, z, initial=0.0)
    i4 = cumulative_trapezoid(q1*i2, z, initial=0.0)
    r = i2 - i4/i1
    m = q2 - 6*(1/z-cs(z, 1))*r
    return float(m[-1]/q2[-1])


def solve_cusp(path, n, initial):
    d = np.load(path)
    acs = CubicSpline(d["z"], d["A"])
    fcs = CubicSpline(d["z"], np.log(d["f"]))

    def temperature(zh, mu):
        z = np.linspace(1e-4, zh, n)
        A = acs(z)
        f = np.exp(fcs(z))
        q1 = z**3*np.exp(-3*A)
        q2 = z*np.exp(-A)/f
        i1 = cumulative_trapezoid(q1, z, initial=0.0)[-1]
        i2 = cumulative_trapezoid(q2, z, initial=0.0)[-1]
        i4 = cumulative_trapezoid(q1*cumulative_trapezoid(q2, z, initial=0.0), z, initial=0.0)[-1]
        t0 = zh**3*np.exp(-3*A[-1])/(4*np.pi*i1)
        return t0*(1-(mu/i2)**2*(i1*i2-i4))

    def conditions(x):
        zh, mu = x
        hz, hm = 2e-4, 2e-5
        tz = (temperature(zh+hz, mu)-temperature(zh-hz, mu))/(2*hz)
        tzz = (temperature(zh+hz, mu)-2*temperature(zh, mu)+temperature(zh-hz, mu))/hz**2
        return [tz, tzz]

    fit = root(conditions, initial, method="hybr", options={"xtol": 1e-10})
    zh, mu = fit.x
    residual = conditions(fit.x)
    residual_passed = max(abs(residual[0]), abs(residual[1])) <= 2e-3
    if not residual_passed:
        raise RuntimeError(f"cusp solve failed for {path}, n={n}: {fit.message}, {fit.x}, {residual}")
    return {"radial_integral_points": n, "zh": float(zh), "mu_CEP": float(mu),
            "T_CEP": float(temperature(zh, mu)), "solver_success": bool(fit.success),
            "residual_passed": bool(residual_passed),
            "T_z_residual": float(residual[0]), "T_zz_residual": float(residual[1])}


def physical_checks(path, zstar):
    d = np.load(path)
    z = np.linspace(0.02, max(8.0, zstar), 12000)
    cs = CubicSpline(d["z"], d["A"])
    A, A1, A2 = cs(z), cs(z, 1), cs(z, 2)
    phi2 = 6*(A1**2-A2-2*A1/z)
    f = np.exp(CubicSpline(d["z"], np.log(d["f"]))(z))
    zt = d["z"]
    At = d["A"]
    A1t = np.gradient(At, zt)
    A2t = np.gradient(A1t, zt)
    phi2_table = 6*(A1t**2-A2t-2*A1t/zt)
    table_mask = (zt >= .02) & (zt <= zstar)
    model = load_trained(str(path), n_int=900)
    t, s, zh = sorted_curve(model, zmax=max(8.0, zstar))
    return {
        "A_at_z0_by_parameterization": 0.0,
        "A_at_saved_zmin": float(d["A"][0]),
        "f_positive": bool(np.all(f > 0)),
        "f_min": float(np.min(f)),
        "phi_prime_sq_min_z002_to_zmax": float(np.min(phi2)),
        "phi_prime_sq_min_z002_to_cusp": float(np.min(phi2[z <= zstar])),
        "phi_prime_sq_finite_difference_min_to_cusp": float(np.min(phi2_table[table_mask])),
        "phi_prime_sq_nonnegative_to_cusp": bool(np.all(phi2[z <= zstar] >= 0)),
        "zero_density_T_monotonic_on_used_branch": bool(np.all(np.diff(t) > 0)),
        "finite_entropy_and_temperature": bool(np.all(np.isfinite(t)) and np.all(np.isfinite(s))),
        "checked_zmax": float(z.max()),
        "cusp_horizon": float(zstar),
        "blackening_boundaries": "g(0)=1 and g(zh)=0 by construction",
        "pressure_relation": "dp=s dT by numerical integration with common 120 MeV anchor",
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pair", type=Path, default=PAIR)
    ap.add_argument("--analysis-output", type=Path)
    ap.add_argument("--revision-output", type=Path)
    args = ap.parse_args()
    pair = args.pair.resolve()
    analysis_output = args.analysis_output or pair / "analysis.json"
    analysis_output.parent.mkdir(parents=True, exist_ok=True)
    report = {"pressure_anchor": {"T_GeV": 0.120, "p_over_T4": float(LAT["p_over_T4"][0])},
              "fits": {}}
    for label in ("lattice_only", "hrg_lqcd"):
        path = pair / label / "Nf211_A_f.npz"
        model = load_trained(str(path), n_int=700)
        cusp_model = load_trained(str(path), n_int=4800)
        old = json.loads((pair / label / "evaluation.json").read_text())
        cep = old["cep_resolution_4800"]
        if not cep.get("cep_found", False):
            report["fits"][label] = {
                "G": float(np.load(path)["G"]),
                "metrics_high_temperature_LQCD": old["metrics"],
                "cusp": None, "cusp_status": "not_found_in_coarse_scan",
                "Maxwell_M_over_I2prime_at_cusp": None,
                "physical_checks": physical_checks(path, 8.0),
            }
            continue
        zh_curve, t_curve, _, _ = curve_mu(cusp_model, cep["mu_CEP"], z0=0.05, z1=40.0, n=4000)
        turns = turning_points(t_curve)
        guesses = [float(np.mean(zh_curve[turns[:2]]))] if len(turns) >= 2 else []
        reference = PAIR / label / "Nf211_A_f.npz"
        with np.load(path) as current, np.load(reference) as central:
            same_reference = all(np.array_equal(current[key], central[key])
                                 for key in ("z", "A", "f", "G"))
        if same_reference:
            guesses.insert(0, 3.37 if label == "lattice_only" else 3.20)
        guesses.extend(z for z in np.linspace(1.0, 6.0, 21) if all(abs(z-g) > 0.1 for g in guesses))
        candidates = []
        for z_guess in guesses:
            try:
                r = solve_cusp(path, 4000, [z_guess, cep["mu_CEP"]])
                if r["T_CEP"] > 0 and r["mu_CEP"] > 0:
                    score = abs(r["mu_CEP"]-cep["mu_CEP"]) + abs(r["T_CEP"]-cep["T_CEP"])
                    candidates.append((score, r))
            except RuntimeError:
                continue
        if not candidates:
            raise RuntimeError(f"No direct cusp solution converged for {path}")
        if same_reference:
            first = solve_cusp(path, 4000, [3.37 if label == "lattice_only" else 3.20,
                                           cep["mu_CEP"]])
        else:
            first = min(candidates, key=lambda item: item[0])[1]
        if abs(first["mu_CEP"]-cep["mu_CEP"]) > 0.05 or abs(first["T_CEP"]-cep["T_CEP"]) > 0.02:
            raise RuntimeError(f"Direct cusp is inconsistent with the coarse bracket for {path}")
        initial = [first["zh"], first["mu_CEP"]]
        resolutions = [first]
        for n in (8000, 16000):
            r = solve_cusp(path, n, initial)
            initial = [r["zh"], r["mu_CEP"]]
            resolutions.append(r)
        best = resolutions[-1]
        zstar = best["zh"]
        eos = eos_curve(model)
        columns = np.column_stack([eos[k] for k in ("T", "s_over_T3", "p_over_T4", "e_over_T4", "I_over_T4", "cs2")])
        np.savetxt(pair / label / "eos_common_anchor.csv", columns, delimiter=",",
                   header="T,s_over_T3,p_over_T4,e_over_T4,I_over_T4,cs2", comments="")
        report["fits"][label] = {
            "G": float(np.load(path)["G"]),
            "metrics_high_temperature_LQCD": old["metrics"],
            "cusp": {"T_GeV": best["T_CEP"], "muB_GeV": best["mu_CEP"],
                     "zh": zstar, "resolutions": resolutions},
            "Maxwell_M_over_I2prime_at_cusp": maxwell_ratio(path, zstar),
            "physical_checks": physical_checks(path, zstar),
        }
    a = report["fits"]["lattice_only"]["cusp"]
    b = report["fits"]["hrg_lqcd"]["cusp"]
    report["HRG_induced_shift"] = None if a is None or b is None else {
        "Delta_T_MeV": 1000*(b["T_GeV"]-a["T_GeV"]),
        "Delta_muB_MeV": 1000*(b["muB_GeV"]-a["muB_GeV"])}
    report["protocol"] = json.loads((pair / "protocol.json").read_text())
    analysis_output.write_text(json.dumps(report, indent=2) + "\n")
    if args.revision_output:
        args.revision_output.parent.mkdir(parents=True, exist_ok=True)
        args.revision_output.write_text(json.dumps(report, indent=2) + "\n")
    if not all(v["physical_checks"]["phi_prime_sq_nonnegative_to_cusp"]
               for v in report["fits"].values()):
        raise RuntimeError("A fit failed the radial reality gate; do not use this pair in the paper")
    print(json.dumps({k: {"G": v["G"],
                          "T_MeV": None if v["cusp"] is None else 1000*v["cusp"]["T_GeV"],
                          "muB_MeV": None if v["cusp"] is None else 1000*v["cusp"]["muB_GeV"],
                          "Maxwell": v["Maxwell_M_over_I2prime_at_cusp"],
                          "checks": v["physical_checks"]}
                      for k, v in report["fits"].items()}, indent=2))
    print("shift", report["HRG_induced_shift"])


if __name__ == "__main__":
    main()
