#!/usr/bin/env python3
"""Paper figures for the controlled lattice-only/HRG comparison."""
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np
import torch

from emd_free import emd_mu0_curve, load_trained

ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT.parent
PAIR = ROOT / "results/controlled_pair"
IMG = PROJECT / "paper_3flavors/img"
OUT = PROJECT / "paper_3flavors/results_revision"
ANALYSIS = json.loads((PAIR / "analysis.json").read_text())
LAT = np.genfromtxt(ROOT / "data/Nf211_lattice_s.csv", delimiter=",", names=True)
WB = np.loadtxt(ROOT / "data/WB-chiB-1805.04445.dat")
COLORS = {"lattice_only": "#2468a2", "hrg_lqcd": "black"}
LABELS = {"lattice_only": "LQCD only", "hrg_lqcd": "controlled HRG+LQCD"}


def style(ax, ylabel):
    ax.set_xlabel(r"$T$ [GeV]")
    ax.set_ylabel(ylabel)
    ax.grid(alpha=.2)


def regional(ax, t, y, label, breaks):
    color = COLORS[label]
    regions = [(t[0], t[-1], "-")]
    for lo, hi, ls in regions:
        mask = (t >= lo) & (t <= hi)
        if np.sum(mask) > 1:
            ax.plot(t[mask], y[mask], ls=ls, color=color, lw=1.65,
                    zorder=1 if label == "hrg_lqcd" else 3)


def hrg_input_eos():
    d = np.genfromtxt(ROOT/"data/Nf211_controlled_s.csv", delimiter=",",
                      names=True, usecols=(0, 1, 2))
    t, s = d["T"], d["s_over_T3"]
    integ = np.r_[0., np.cumsum(.5*(s[1:]*t[1:]**3+s[:-1]*t[:-1]**3)*np.diff(t))]
    const = LAT["p_over_T4"][0]*LAT["T"][0]**4-np.interp(LAT["T"][0], t, integ)
    p = (integ+const)/t**4
    x = s
    cs2 = x/(3*x+t*np.gradient(x, t))
    return dict(T=t, s_over_T3=s, p_over_T4=p, e_over_T4=s-p,
                I_over_T4=s-4*p, cs2=cs2)


def plot_eos():
    curves = {k: np.genfromtxt(PAIR/k/"eos_common_anchor.csv", delimiter=",", names=True)
              for k in COLORS}
    inputs = hrg_input_eos()
    panels = [("s_over_T3", r"$s/T^3$"), ("p_over_T4", r"$p/T^4$"),
              ("e_over_T4", r"$\epsilon/T^4$"), ("I_over_T4", r"$I/T^4$"),
              ("cs2", r"$c_s^2$")]
    fig, axes = plt.subplots(2, 3, figsize=(10.2, 5.8), constrained_layout=True)
    for ax, (key, ylab) in zip(axes.flat, panels):
        for label, curve in curves.items():
            regional(ax, curve["T"], curve[key], label, (0.120, 0.135))
        ax.plot(inputs["T"], inputs[key], color="gray", ls=":", lw=1.2, zorder=0)
        if key != "cs2":
            err = "d"+key
            ax.errorbar(LAT["T"], LAT[key], yerr=LAT[err], fmt="o", ms=2.5,
                        color=".25", lw=.7, capsize=1, zorder=1)
        ax.set_xlim(.08, .30)
        style(ax, ylab)
    ax = axes.flat[-1]
    points = [(535, 174, "#c33c54", "o", r"$N_f=2$ LQCD"),
              (1000*ANALYSIS["fits"]["lattice_only"]["cusp"]["muB_GeV"],
               1000*ANALYSIS["fits"]["lattice_only"]["cusp"]["T_GeV"],
               COLORS["lattice_only"], "s", r"$N_f=2+1+1$ LQCD"),
              (1000*ANALYSIS["fits"]["hrg_lqcd"]["cusp"]["muB_GeV"],
               1000*ANALYSIS["fits"]["hrg_lqcd"]["cusp"]["T_GeV"],
               COLORS["hrg_lqcd"], "*", r"$N_f=2+1+1$ HRG")]
    for mu, temp, color, marker, label in points:
        ax.scatter(mu, temp, s=55 if marker == "*" else 30, color=color,
                   marker=marker, label=label, zorder=3)
    ax.annotate("", xy=points[2][:2], xytext=points[1][:2],
                arrowprops=dict(arrowstyle="->", color=".4", lw=.9))
    ax.set(xlabel=r"$\mu_{B,\mathrm{cusp}}$ [MeV]", ylabel=r"$T_{\mathrm{cusp}}$ [MeV]")
    ax.grid(alpha=.2)
    ax.legend(frameon=False, fontsize=6, loc="upper right")
    ax.tick_params(labelsize=7)
    fig.savefig(IMG/"controlled_hrg_eos.pdf")
    fig.savefig(IMG/"controlled_hrg_eos.png", dpi=180)
    plt.close(fig)


def plot_eos_single():
    """HRG+LQCD result in the same compact format as the lattice-only EoS."""
    curve = np.genfromtxt(PAIR/"hrg_lqcd"/"eos_common_anchor.csv",
                          delimiter=",", names=True)
    fig, ax = plt.subplots(figsize=(3.55, 3.15))
    panels = [
        ("s_over_T3", "ds_over_T3", .2, r"$s/5T^3$", "#d62728", "o"),
        ("e_over_T4", "de_over_T4", .2, r"$\epsilon/5T^4$", "#2ca02c", "s"),
        ("I_over_T4", "dI_over_T4", .5,
         r"$(\epsilon-3p)/2T^4$", "#1f4aff", "^"),
        ("p_over_T4", "dp_over_T4", 1., r"$p/T^4$", "#8b169b", "D"),
    ]
    for key, err, scale, label, color, marker in panels:
        y = scale * curve[key]
        for lo, hi, ls in ((curve["T"].min(), .120, "--"),
                           (.120, .135, ":"), (.135, curve["T"].max(), "-")):
            mask = (curve["T"] >= lo) & (curve["T"] <= hi)
            ax.plot(curve["T"][mask], y[mask], color=color, ls=ls,
                    lw=2.3, zorder=3)
        ax.errorbar(LAT["T"], scale * LAT[key], yerr=scale * LAT[err],
                    fmt=marker, color=color, ms=3.2, mfc="none",
                    markeredgewidth=1.0, capsize=1.3, capthick=.7,
                    elinewidth=.7, zorder=4)
    handles = [Line2D([], [], marker=marker, ls="", color=color,
                      markersize=3.4, mfc="none", markeredgewidth=1.0,
                      label=label)
               for _, _, _, label, color, marker in panels]
    handles += [Line2D([], [], color=".25", lw=1.6, label="HRG+LQCD"),
                Line2D([], [], color=".35", ls="--", label="HRG segment"),
                Line2D([], [], color=".35", ls=":", label="HRG--LQCD blend")]
    ax.legend(handles=handles, frameon=False, loc="upper left", ncol=3,
              fontsize=5.7, columnspacing=.7, handletextpad=.3,
              labelspacing=.28)
    ax.set(xlabel=r"$T\;[\mathrm{GeV}]$", xlim=(.08, .30), ylim=(0, 3.40))
    ax.tick_params(which="both", direction="in", top=True, right=True)
    fig.text(.5, -.01,
             r"$N_f=2+1+1$: $p/T^4(120\,\mathrm{MeV})=0.433$; controlled HRG",
             ha="center", fontsize=6.0, color=".35")
    fig.tight_layout()
    fig.savefig(IMG/"controlled_hrg_eos_single.pdf", bbox_inches="tight")
    fig.savefig(IMG/"controlled_hrg_eos_single.png", dpi=500,
                bbox_inches="tight")
    plt.close(fig)


def baryon_curves():
    result = {}
    for label in COLORS:
        model = load_trained(str(PAIR/label/"Nf211_A_f.npz"), n_int=700)
        with torch.no_grad():
            zh = torch.exp(torch.linspace(np.log(.02), np.log(12.), 4000))
            obs = model.observables_mu0(zh)
            nb, tn, _ = model.nB_over_T3(zh, muhat=1.0)
        tc, cc = obs["T"].numpy(), obs["chi2B"].numpy()
        order = np.argsort(tc)
        tn, nn = tn.numpy(), nb.numpy()
        order_n = np.argsort(tn)
        result[label] = (tc[order], cc[order], tn[order_n], nn[order_n])
    return result


def plot_baryon():
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.8), constrained_layout=True)
    curves = baryon_curves()
    tw = WB[:, 0]/1000
    nref = WB[:, 1]+WB[:, 3]/6
    nsig = np.hypot(np.hypot(WB[:, 2], WB[:, 4]/6), .1*np.abs(nref))
    hc = np.genfromtxt(ROOT/"data/Nf211_controlled_chi.csv", delimiter=",",
                       names=True, usecols=(0, 1, 2))
    hd = np.genfromtxt(ROOT/"data/Nf211_controlled_delta.csv", delimiter=",",
                       names=True, usecols=(0, 1, 2))
    hn = np.interp(hd["T"], hc["T"], hc["chi2B"])+hd["nB_minus_chi2"]
    axes[0].plot(hc["T"], hc["chi2B"], color="gray", ls=":", lw=1.2, zorder=0)
    axes[1].plot(hd["T"], hn, color="gray", ls=":", lw=1.2, zorder=0)
    for label, (tc, cc, tn, nn) in curves.items():
        regional(axes[0], tc, cc, label, (.135, .150))
        regional(axes[1], tn, nn, label, (WB[1, 0]/1000, WB[4, 0]/1000))
        axes[1].plot(tn, np.interp(tn, tc, cc), color=COLORS[label], lw=.7, alpha=.3)
    axes[0].errorbar(tw, WB[:, 1], yerr=WB[:, 2], fmt="o", ms=3, color=".25", lw=.7)
    axes[1].errorbar(tw, nref, yerr=nsig, fmt="o", ms=3, color=".25", lw=.7)
    for ax, ylab in zip(axes, (r"$\chi_2^B$", r"$n_B/T^3$ at $\mu_B/T=1$")):
        ax.set_xlim(.08, .23)
        style(ax, ylab)
    handles = [Line2D([], [], color=COLORS[k], label=LABELS[k]) for k in COLORS]
    handles.append(Line2D([], [], color="gray", ls=":", label="HRG target"))
    axes[0].legend(handles=handles, frameon=False, fontsize=8, loc="upper left")
    fig.savefig(IMG/"controlled_hrg_baryon.pdf")
    fig.savefig(IMG/"controlled_hrg_baryon.png", dpi=180)
    plt.close(fig)


def plot_cusps():
    fig, ax = plt.subplots(figsize=(4.8, 3.5), constrained_layout=True)
    points = {r"$N_f=2$ LQCD only": (535, 174),
              r"$N_f=2+1+1$ LQCD only": (1000*ANALYSIS["fits"]["lattice_only"]["cusp"]["muB_GeV"],
                                      1000*ANALYSIS["fits"]["lattice_only"]["cusp"]["T_GeV"]),
              r"$N_f=2+1+1$ HRG+LQCD": (1000*ANALYSIS["fits"]["hrg_lqcd"]["cusp"]["muB_GeV"],
                                     1000*ANALYSIS["fits"]["hrg_lqcd"]["cusp"]["T_GeV"])}
    styles = [("#c33c54", "o"), ("#2468a2", "s"), ("black", "*")]
    for (label, (mu, t)), (color, marker) in zip(points.items(), styles):
        ax.scatter(mu, t, s=85 if marker == "*" else 45,
                   color=color, marker=marker, label=label, zorder=3)
    a = points[r"$N_f=2+1+1$ LQCD only"]
    b = points[r"$N_f=2+1+1$ HRG+LQCD"]
    ax.annotate("", xy=b, xytext=a,
                arrowprops=dict(arrowstyle="->", color=".4", lw=1))
    ax.set(xlabel=r"$\mu_{B,\mathrm{cusp}}$ [MeV]", ylabel=r"$T_{\mathrm{cusp}}$ [MeV]")
    ax.grid(alpha=.25)
    ax.legend(frameon=False, fontsize=8)
    fig.savefig(IMG/"controlled_cusp_candidates.pdf")
    fig.savefig(IMG/"controlled_cusp_candidates.png", dpi=180)
    plt.close(fig)


def main():
    IMG.mkdir(exist_ok=True)
    plot_eos()
    plot_eos_single()
    plot_baryon()
    plot_cusps()
    for name in ("controlled_hrg_eos", "controlled_hrg_eos_single",
                 "controlled_hrg_baryon", "controlled_cusp_candidates"):
        print("saved", IMG/(name+".pdf"))


if __name__ == "__main__":
    main()
