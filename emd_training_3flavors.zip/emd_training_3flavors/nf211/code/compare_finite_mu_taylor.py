#!/usr/bin/env python3
"""Compare the controlled HRG+LQCD EMD background with the WB Taylor EOS."""
import hashlib
import json
import math
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np
from scipy.integrate import cumulative_simpson
from scipy.interpolate import CubicSpline
import torch

from emd_free import load_trained

ROOT = Path(__file__).resolve().parents[1]
MODEL_PATH = ROOT / "results/controlled_pair/hrg_lqcd/Nf211_A_f.npz"
WB_PATH = ROOT / "data/WB-chiB-1805.04445.dat"
OUT = ROOT / "results/finite_mu_taylor_hrg"
FIG = ROOT / "figures/finite_mu_taylor_hrg"
MU_GRID = np.linspace(0.0, 3.5, 71)
MU_PANELS = (1.0, 2.0, 3.0)
T_PANELS = (0.150, 0.170, 0.200)
ORDERS = (2, 4, 6, 8)
STYLE = {
    2: ("#777777", ":", r"$\mathcal{O}(\hat\mu_B^2)$"),
    4: ("#2468a2", "--", r"$\mathcal{O}(\hat\mu_B^4)$"),
    6: ("#2ca02c", "-.", r"$\mathcal{O}(\hat\mu_B^6)$"),
    8: ("#c33c54", (0, (4, 2, 1, 2)), r"$\mathcal{O}(\hat\mu_B^8)$"),
}


def stable_branch(x, *ys):
    good = np.isfinite(x) & (x > 0)
    for y in ys:
        good &= np.isfinite(y)
    x = np.asarray(x)[good]
    ys = [np.asarray(y)[good] for y in ys]
    turns = np.where(np.diff(x) > 0)[0]
    if len(turns):
        keep = turns[0] + 1
        x = x[:keep]
        ys = [y[:keep] for y in ys]
    order = np.argsort(x)
    x = x[order]
    unique, keep = np.unique(x, return_index=True)
    return unique, *[y[order][keep] for y in ys]


def emd_on_mu_grid(t_grid):
    model = load_trained(str(MODEL_PATH), n_int=1200).double()
    zh = torch.exp(torch.linspace(np.log(0.02), np.log(12.0), 3000,
                                  dtype=torch.float64))
    n_interp = []
    convergence = []
    with torch.no_grad():
        obs = model.observables_mu0(zh)
        t0 = obs["T"].numpy()
        chi2 = obs["chi2B"].numpy()
        for muhat in MU_GRID:
            if muhat == 0:
                t = t0
                n = np.zeros_like(t)
                residual = 0.0
            else:
                mu, t_tensor, i2 = model.solve_mu_eq_T(
                    zh, muhat=float(muhat), n_iter=180, tol=1e-13)
                t = t_tensor.numpy()
                n = (mu / (16 * np.pi * model.G * i2) / t_tensor**3).numpy()
                residual = float(np.max(np.abs(mu.numpy() - muhat * t)))
            t, n = stable_branch(t, n)
            n_interp.append(np.interp(t_grid, t, n, left=np.nan, right=np.nan))
            convergence.append(residual)
    n_curve = np.asarray(n_interp)
    if not np.all(np.isfinite(n_curve)):
        raise RuntimeError("EMD branch does not cover the complete comparison window")
    dp_curve = cumulative_simpson(n_curve, x=MU_GRID, axis=0, initial=0.0)
    t_chi, chi_curve = stable_branch(t0, chi2)
    chi_dense = np.interp(t_grid, t_chi, chi_curve)
    small = 1
    leading = n_curve[small] / MU_GRID[small]
    leading_error = np.abs(leading / chi_dense - 1)
    checks = {
        "max_mu_fixed_point_residual_GeV": max(convergence),
        "small_mu_nB_over_muhat_vs_chi2_median_relative_error": float(np.median(leading_error)),
        "small_mu_nB_over_muhat_vs_chi2_max_relative_error": float(np.max(leading_error)),
        "muhat_used_for_small_mu_check": float(MU_GRID[small]),
    }
    return n_curve, dp_curve, checks


def taylor_curves(t_grid):
    wb = np.loadtxt(WB_PATH)
    t = wb[:, 0] / 1000.0
    splines = [CubicSpline(t, wb[:, i]) for i in (1, 3, 5, 7)]
    error_splines = [CubicSpline(t, wb[:, i]) for i in (2, 4, 6, 8)]
    chi = [s(t_grid) for s in splines]
    chi_error = [s(t_grid) for s in error_splines]
    n, dp, n_error, dp_error = {}, {}, {}, {}
    for order in ORDERS:
        n[order] = sum(chi[k] * MU_GRID[:, None]**(2*k+1) /
                       math.factorial(2*k+1) for k in range(order//2))
        dp[order] = sum(chi[k] * MU_GRID[:, None]**(2*k+2) /
                        math.factorial(2*k+2) for k in range(order//2))
        n_error[order] = np.sqrt(sum(
            (chi_error[k] * MU_GRID[:, None]**(2*k+1) /
             math.factorial(2*k+1))**2 for k in range(order//2)))
        dp_error[order] = np.sqrt(sum(
            (chi_error[k] * MU_GRID[:, None]**(2*k+2) /
             math.factorial(2*k+2))**2 for k in range(order//2)))
    return wb, n, dp, n_error, dp_error


def panel_style(ax, tag=None):
    ax.grid(alpha=0.2)
    ax.tick_params(which="both", direction="in", top=True, right=True)
    if tag:
        ax.text(0.96, 0.95, tag, transform=ax.transAxes, ha="right",
                va="top", fontsize=8)


def legend_handles():
    handles = [Line2D([], [], color="black", lw=1.8, label="EMD, HRG+LQCD $A,f$")]
    handles += [Line2D([], [], color=STYLE[o][0], ls=STYLE[o][1], lw=1.35,
                       label=STYLE[o][2]) for o in ORDERS]
    return handles


def plot_temperature(t_grid, mu_indices, n_emd, dp_emd, n_taylor, dp_taylor,
                     n_error, dp_error):
    fig, axes = plt.subplots(2, 3, figsize=(10.2, 5.8), constrained_layout=True)
    for col, muhat in enumerate(MU_PANELS):
        i = mu_indices[muhat]
        for row, (emd, taylor, error, ylabel) in enumerate((
                (n_emd, n_taylor, n_error, r"$n_B/T^3$"),
                (dp_emd, dp_taylor, dp_error, r"$\Delta p/T^4$"))):
            ax = axes[row, col]
            ax.plot(t_grid, emd[i], color="black", lw=1.8, zorder=4)
            for order in ORDERS:
                color, ls, _ = STYLE[order]
                central = taylor[order][i]
                sigma = error[order][i]
                ax.fill_between(t_grid, central-sigma, central+sigma,
                                color=color, alpha=0.10, lw=0, zorder=0)
                ax.plot(t_grid, central, color=color, ls=ls, lw=1.35)
            ax.set(xlabel=r"$T$ [GeV]", ylabel=ylabel, xlim=(0.135, 0.220))
            ax.set_title(rf"$\mu_B/T={muhat:g}$", fontsize=9)
            panel_style(ax, f"({chr(97+row*3+col)})")
    axes[0, 0].legend(handles=legend_handles(), frameon=False, fontsize=6.5,
                      loc="upper left", labelspacing=0.35)
    for ext in ("pdf", "png"):
        fig.savefig(FIG / f"finite_mu_vs_T.{ext}", dpi=400, bbox_inches="tight")
    plt.close(fig)


def plot_mu(t_grid, mu_indices, n_emd, dp_emd, n_taylor, dp_taylor,
            n_error, dp_error):
    fig, axes = plt.subplots(2, 3, figsize=(10.2, 5.8), constrained_layout=True)
    for col, temp in enumerate(T_PANELS):
        j = int(np.argmin(np.abs(t_grid - temp)))
        for row, (emd, taylor, error, ylabel) in enumerate((
                (n_emd, n_taylor, n_error, r"$n_B/T^3$"),
                (dp_emd, dp_taylor, dp_error, r"$\Delta p/T^4$"))):
            ax = axes[row, col]
            ax.plot(MU_GRID, emd[:, j], color="black", lw=1.8, zorder=4)
            for order in ORDERS:
                color, ls, _ = STYLE[order]
                central = taylor[order][:, j]
                sigma = error[order][:, j]
                ax.fill_between(MU_GRID, central-sigma, central+sigma,
                                color=color, alpha=0.10, lw=0, zorder=0)
                ax.plot(MU_GRID, central, color=color, ls=ls, lw=1.35)
            ax.set(xlabel=r"$\mu_B/T$", ylabel=ylabel, xlim=(0, 3.5))
            ax.set_title(rf"$T={1000*t_grid[j]:.0f}\,\mathrm{{MeV}}$", fontsize=9)
            panel_style(ax, f"({chr(97+row*3+col)})")
    axes[0, 0].legend(handles=legend_handles(), frameon=False, fontsize=6.5,
                      loc="upper left", labelspacing=0.35)
    for ext in ("pdf", "png"):
        fig.savefig(FIG / f"finite_mu_vs_muhat.{ext}", dpi=400, bbox_inches="tight")
    plt.close(fig)


def save_tables(t_grid, mu_indices, n_emd, dp_emd, n_taylor, dp_taylor,
                n_error, dp_error):
    header = ["T_GeV", "muB_over_T", "EMD_nB_over_T3", "EMD_delta_p_over_T4"]
    for order in ORDERS:
        header += [f"TaylorO{order}_nB_over_T3", f"TaylorO{order}_nB_sigma",
                   f"TaylorO{order}_delta_p_over_T4", f"TaylorO{order}_delta_p_sigma"]
    rows = []
    for muhat in MU_PANELS:
        i = mu_indices[muhat]
        columns = [t_grid, np.full_like(t_grid, muhat), n_emd[i], dp_emd[i]]
        columns += [v for order in ORDERS for v in (
            n_taylor[order][i], n_error[order][i],
            dp_taylor[order][i], dp_error[order][i])]
        rows.append(np.column_stack(columns))
    np.savetxt(OUT / "comparison_vs_T.csv", np.vstack(rows), delimiter=",",
               header=",".join(header), comments="")
    rows = []
    for temp in T_PANELS:
        j = int(np.argmin(np.abs(t_grid - temp)))
        columns = [np.full_like(MU_GRID, t_grid[j]), MU_GRID,
                   n_emd[:, j], dp_emd[:, j]]
        columns += [v for order in ORDERS for v in (
            n_taylor[order][:, j], n_error[order][:, j],
            dp_taylor[order][:, j], dp_error[order][:, j])]
        rows.append(np.column_stack(columns))
    np.savetxt(OUT / "comparison_vs_muhat.csv", np.vstack(rows), delimiter=",",
               header=",".join(header), comments="")


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    FIG.mkdir(parents=True, exist_ok=True)
    wb = np.loadtxt(WB_PATH)
    t_grid = np.linspace(wb[0, 0]/1000, wb[-1, 0]/1000, 400)
    n_emd, dp_emd, checks = emd_on_mu_grid(t_grid)
    wb, n_taylor, dp_taylor, n_error, dp_error = taylor_curves(t_grid)
    mu_indices = {mu: int(np.argmin(np.abs(MU_GRID-mu))) for mu in MU_PANELS}
    save_tables(t_grid, mu_indices, n_emd, dp_emd, n_taylor, dp_taylor,
                n_error, dp_error)
    plot_temperature(t_grid, mu_indices, n_emd, dp_emd, n_taylor, dp_taylor,
                     n_error, dp_error)
    plot_mu(t_grid, mu_indices, n_emd, dp_emd, n_taylor, dp_taylor,
            n_error, dp_error)
    summary = {}
    for muhat, i in mu_indices.items():
        item = {}
        for name, emd, taylor in (("nB_over_T3", n_emd, n_taylor),
                                  ("delta_p_over_T4", dp_emd, dp_taylor)):
            item[name] = {}
            for order in ORDERS:
                scale = np.sqrt(np.mean(taylor[order][i]**2))
                item[name][f"EMD_vs_O{order}_rms_relative_difference"] = float(
                    np.sqrt(np.mean((emd[i]-taylor[order][i])**2))/scale)
        summary[str(muhat)] = item
    report = {
        "model": str(MODEL_PATH),
        "model_sha256": hashlib.sha256(MODEL_PATH.read_bytes()).hexdigest(),
        "coefficients": str(WB_PATH),
        "coefficient_source": "arXiv:1805.04445, Nf=2+1+1, physical masses, Nt=12",
        "temperature_GeV": [float(t_grid[0]), float(t_grid[-1])],
        "muB_over_T_grid": [0.0, 3.5, 0.05],
        "EMD_radial_integral_points": 1200,
        "EMD_horizon_points": 3000,
        "pressure_definition": "Delta p/T4 = integral_0^muhat (nB/T3) dmuhat at fixed T",
        "Taylor_definition": "nB/T3=sum chi_(2k+2) muhat^(2k+1)/(2k+1)!; Delta p/T4=sum chi_(2k+2) muhat^(2k+2)/(2k+2)!",
        "uncertainty_note": "Shaded bands are diagonal 1-sigma propagation of published marginal coefficient errors; cross-order covariances are unavailable and set to zero.",
        "training_note": "chi2B and the O(muhat^4) density at muhat=1 were training targets; higher muhat and O6/O8 are extrapolations.",
        "numerical_checks": checks,
        "comparison": summary,
    }
    (OUT / "summary.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"numerical_checks": checks, "comparison": summary}, indent=2))
    print("saved", FIG / "finite_mu_vs_T.png")
    print("saved", FIG / "finite_mu_vs_muhat.png")


if __name__ == "__main__":
    main()
