#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
train_nf211.py -- train A(z), f(z), G of the EMD model on Nf=2+1+1 lattice data
(s/T^3 + chi_B^2 at mu=0, then n_B/T^3 at mu_B/T = 1), for the standalone
Nf=2 package.  See plot_nf211.py for the EOS comparison and the CEP.

INPUT   data/Nf211_train_s.csv      T, s_over_T3, sigma, kind
                                  kind 'adapted-HRG...' = low-T model anchor
                                  (treated with a 5 % model tolerance, not as
                                  exact data); kind 'lattice:tmfT...' = data
        data/Nf211_train_chi.csv    T, chi2B, sigma, kind   (Zenodo 15123623 2+1 continuum
                                  + matched physical HRG anchors)
        data/Nf211_nB_muhat1.csv    T, n_B/T^3, dnB_tot at mu_B/T = 1
                                  (Taylor extrapolation: chi_2 Zenodo 15123623,
                                  chi_4 1805.04445 -- NOT a finite-mu simulation)

MODEL   A(z) = A_net(z), f(z) = F_net(z), scalar G (8 pi G_5), clamp [0.05, 2]

LOSS    phase 1 (mu = 0):  L = L_s + L_c + 1e-6 L_reg + 1e-3 L_phi
        phase 2 (+ n_B):   L += w(ep) * L_r / L_r(0)   (normalised self-ramp,
                           w ramps 0 -> 1 over rho_warmup of the phase)
        L_s, L_c : inverse-variance chi^2 of s/T^3 and chi_B^2
                   (EMD forward on a fixed z_h grid, differentiable interp)
        L_r      : chi^2 of n_B/T^3 on the mu_B = T line
        L_reg    : second-difference smoothness of A and log f
        L_phi    : mean relu(-phi'^2), phi'^2 = 6(A'^2 - A'' - 2A'/z) >= 0

OPTIMISATION  warm start to the CH Table-1 Nf=2+1+1 analytic background
              (a,b,c,d,k = 0.067, 0.023, -0.377, -0.382, 0), Adam, cosine LR,
              EMA best-state selection, --seeds independent runs (best kept).

OUTPUT  results/Nf211_A_f.npz          final model (mu0 + n_B constraint)
        results/Nf211_A_f_mu0only.npz  phase-1 model (mu = 0 only)
        results/Nf211_history.json     loss history

Usage:  python3 code/train_nf211.py                 # 3 seeds, 6000 + 3000 epochs
        python3 code/train_nf211.py --phase1 4000 --phase2 1500 --seeds 1
"""

import os
import sys
import json
import time
import math
import argparse

import numpy as np
import torch

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from emd_free import EMD, A_net, F_net, ClosureF           # noqa: E402

DATA = os.path.join(BASE, "data")
RESULTS = os.path.join(BASE, "results")

# Chen & Huang Table 1, Nf=2 (arXiv:2405.06179)
CH_NF211 = dict(a=0.196, b=0.014, c=-0.362, d=-0.171, k=-0.735)

HRG_PREFIXES = ("hrg", "adapted", "glueball")


def _is_hrg(kind):
    return str(kind).lower().startswith(HRG_PREFIXES)


# ------------------------------------------------------------------- warm start
def pretrain_background(a_net, f_net, device, steps=1500, lr=1e-3, n=512):
    """Fit A_net, F_net to the analytic CH Nf=2 background."""
    z = torch.exp(torch.linspace(np.log(1e-3), np.log(20.0), n, device=device))
    A_tgt = CH_NF211["d"] * (torch.log1p(CH_NF211["a"] * z ** 2)
                           + torch.log1p(CH_NF211["b"] * z ** 4))
    logf_tgt = CH_NF211["c"] * z ** 2 - A_tgt + CH_NF211["k"]
    params = list({id(p): p for p in list(a_net.parameters()) + list(f_net.parameters())}.values())
    opt = torch.optim.Adam(params, lr=lr)
    for _ in range(steps):
        opt.zero_grad(set_to_none=True)
        loss = ((a_net(z) - A_tgt) ** 2).mean() \
             + ((torch.log(f_net(z).clamp_min(1e-12)) - logf_tgt) ** 2).mean()
        loss.backward()
        opt.step()
    return float(loss.detach())


# ---------------------------------------------------------------------- targets
def load_csv(path):
    T, y, sig, kind = [], [], [], []
    with open(path) as f:
        for line in f:
            if line.startswith("#") or not line.strip() or line.startswith("T,"):
                continue
            p = line.strip().split(",")
            T.append(float(p[0])); y.append(float(p[1])); sig.append(float(p[2]))
            kind.append(p[3] if len(p) > 3 else "")
    return (np.array(T), np.array(y), np.abs(np.array(sig)),
            np.array(kind, dtype=str))


def load_targets(device, hrg_frac=0.05, no_hrg=False, target_tag=None,
                 controlled_hrg=False, taylor_order=4):
    if controlled_hrg:
        prefix = "Nf211_controlled" if target_tag is None else f"Nf211_{target_tag}"
        Ts, ys, ss, ks = load_csv(os.path.join(DATA, prefix + "_s.csv"))
        Tc, yc, sc, kc = load_csv(os.path.join(DATA, prefix + "_chi.csv"))
        Td, yd, sd, kd = load_csv(os.path.join(DATA, prefix + "_delta.csv"))
        wb = np.loadtxt(os.path.join(DATA, "WB-chiB-1805.04445.dat"))
        raw_chi4_sigma = np.interp(Td, wb[:, 0] / 1000.0, wb[:, 4])
        lattice_rows = np.array([str(k).startswith("lattice") for k in kd])
        sig4 = np.where(lattice_rows, raw_chi4_sigma, 6.0 * sd)
        def tensor(a):
            return torch.as_tensor(a, dtype=torch.float32, device=device)
        return dict(T_s=tensor(Ts), y_s=tensor(ys), sig_s=tensor(ss),
                    T_c=tensor(Tc), y_c=tensor(yc), sig_c=tensor(sc),
                    T_r=tensor(Td), y_r=tensor(yd), sig_r=tensor(sd),
                    T_4=tensor(Td), y_4=tensor(6.0 * yd), sig_4=tensor(sig4),
                    y_r_chi2=tensor(np.zeros_like(yd)),
                    sig_r_cond=tensor(sd),
                    n_hrg_s=int(sum(_is_hrg(k) for k in ks)),
                    n_lat_s=int(sum(not _is_hrg(k) for k in ks)),
                    n_hrg_c=int(sum(_is_hrg(k) for k in kc)),
                    n_lat_c=int(sum(not _is_hrg(k) for k in kc)))
    if no_hrg:
        # Published Nf=2+1+1 zero-density EOS and baryon susceptibilities.
        # The n_B target is a truncated Taylor estimate, not a finite-mu run.
        lat = np.genfromtxt(os.path.join(DATA, "Nf211_lattice_s.csv"),
                            delimiter=",", names=True)
        wb = np.loadtxt(os.path.join(DATA, "WB-chiB-1805.04445.dat"))
        Ts, ys, ss = lat["T"], lat["s_over_T3"], lat["ds_over_T3"]
        Tc, yc, sc = wb[:, 0] / 1000.0, wb[:, 1], wb[:, 2]
        Tn = Tc.copy()
        delta = wb[:, 3] / 6.0
        dsigma = wb[:, 4] / 6.0
        if taylor_order == 6:
            delta = delta + wb[:, 5] / 120.0
            dsigma = np.hypot(dsigma, wb[:, 6] / 120.0)
        yn = yc + delta
        sn = np.hypot(np.hypot(sc, dsigma), 0.10 * np.abs(yn))
        # Train the density minus chi2 to avoid counting chi2 twice.
        sr_cond = np.hypot(dsigma, 0.10 * np.abs(yn))
        def tensor(a):
            return torch.as_tensor(a, dtype=torch.float32, device=device)
        return dict(T_s=tensor(Ts), y_s=tensor(ys), sig_s=tensor(ss),
                    T_c=tensor(Tc), y_c=tensor(yc), sig_c=tensor(sc),
                    T_r=tensor(Tn), y_r=tensor(yn), sig_r=tensor(sn),
                    T_4=tensor(Tn), y_4=tensor(wb[:, 3]), sig_4=tensor(wb[:, 4]),
                    y_r_chi2=tensor(yc), sig_r_cond=tensor(sr_cond),
                    n_hrg_s=0, n_lat_s=len(Ts), n_hrg_c=0, n_lat_c=len(Tc))
    suffix = f"_{target_tag}" if target_tag else ""
    Ts, ys, ss, ks = load_csv(os.path.join(DATA, f"Nf211_train_s{suffix}.csv"))
    Tc, yc, sc, kc = load_csv(os.path.join(DATA, f"Nf211_train_chi{suffix}.csv"))
    Tn, yn, sn, _ = load_csv(os.path.join(DATA, f"Nf211_nB_muhat1{suffix}.csv"))

    is_h_s = np.array([_is_hrg(k) for k in ks])
    is_h_c = np.array([_is_hrg(k) for k in kc])
    # lattice -> published sigma; HRG anchor -> explicit model tolerance
    sig_s = np.where(is_h_s, hrg_frac * np.abs(ys), np.maximum(ss, 1e-4))
    floor = max(1e-3, 0.02 * float(np.abs(yc).max()))
    sig_c = np.where(is_h_c, np.maximum(hrg_frac * np.abs(yc), floor),
                     np.maximum(np.where(sc > 0, sc, hrg_frac * np.abs(yc)),
                                floor))
    out = dict(
        T_s=torch.tensor(Ts, dtype=torch.float32, device=device),
        y_s=torch.tensor(ys, dtype=torch.float32, device=device),
        sig_s=torch.tensor(sig_s, dtype=torch.float32, device=device),
        T_c=torch.tensor(Tc, dtype=torch.float32, device=device),
        y_c=torch.tensor(yc, dtype=torch.float32, device=device),
        sig_c=torch.tensor(sig_c, dtype=torch.float32, device=device),
        T_r=torch.tensor(Tn, dtype=torch.float32, device=device),
        y_r=torch.tensor(yn, dtype=torch.float32, device=device),
        sig_r=torch.tensor(sn, dtype=torch.float32, device=device),
        n_hrg_s=int(is_h_s.sum()), n_lat_s=int((~is_h_s).sum()),
        n_hrg_c=int(is_h_c.sum()), n_lat_c=int((~is_h_c).sum()),
    )
    return out


def _interp(Tg, yg, Tq):
    Tq = Tq.clamp(Tg[0], Tg[-1])
    idx = torch.searchsorted(Tg.detach(), Tq.detach()).clamp(1, Tg.numel() - 1)
    x0, x1 = Tg[idx - 1], Tg[idx]
    y0, y1 = yg[idx - 1], yg[idx]
    w = ((Tq - x0) / (x1 - x0).clamp_min(1e-12)).clamp(0.0, 1.0)
    return y0 + w * (y1 - y0)


# ---------------------------------------------------------------------- training
def train(phase1=6000, phase2=3000, lr=1e-3, lr2=3e-4, lr_min=1e-6,
          device="cpu", seed=0, n_zh=400, zh_max=20.0, n_int=200,
          G_init=0.391, G_range=(0.05, 2.0), w_reg=1e-6, w_phi=1e-3,
          hrg_frac=0.05, rho_scale=1.0, rho_warmup=0.35,
          ema_decay=0.999, eval_every=25, pretrain_steps=1500, verbose=True,
          hidden=32, depth=3, no_hrg=False, data_seed=None, target_tag=None,
          controlled_hrg=False, initial_state=None, taylor_order=4, chi4_scale=0.0,
          closure_f=False, f0=0.4):
    torch.manual_seed(seed)
    np.random.seed(seed)
    t0 = time.time()

    a_net = A_net(hidden=hidden, depth=depth, act="tanh", form="constrained").to(device)
    f_net = ClosureF(a_net, f0=f0).to(device) if closure_f else F_net(
        hidden=hidden, depth=depth, act="tanh").to(device)
    model = EMD(a_net, f_net, G=G_init, G_range=G_range, n_int=n_int).to(device)

    pt = 0.0 if closure_f and initial_state is not None else pretrain_background(
        a_net, f_net, device, steps=pretrain_steps)
    if initial_state is not None:
        model.load_state_dict(initial_state, strict=not closure_f)
    D = load_targets(device, hrg_frac=hrg_frac, no_hrg=no_hrg,
                     target_tag=target_tag, controlled_hrg=controlled_hrg,
                     taylor_order=taylor_order)
    if data_seed is not None:
        rng = np.random.default_rng(data_seed)

        def noise(key):
            return torch.as_tensor(rng.standard_normal(len(D[key])),
                                   dtype=D[key].dtype, device=D[key].device)

        D["y_s"] = D["y_s"] + D["sig_s"] * noise("y_s")
        chi_noise = D["sig_c"] * noise("y_c")
        D["y_c"] = D["y_c"] + chi_noise
        if "sig_r_cond" in D:
            D["y_r"] = D["y_r"] + chi_noise + D["sig_r_cond"] * noise("y_r")
            D["y_r_chi2"] = D["y_r_chi2"] + chi_noise
        else:
            D["y_r"] = D["y_r"] + D["sig_r"] * noise("y_r")
    if verbose:
        print("warm start pretrain loss %.3e | data: s %dHRG+%dLat, chi %dHRG+%dLat, nB %d"
              % (pt, D["n_hrg_s"], D["n_lat_s"], D["n_hrg_c"], D["n_lat_c"],
                 len(D["T_r"])), flush=True)

    zh_grid = torch.exp(torch.linspace(np.log(0.02), np.log(zh_max), n_zh,
                                       device=device))
    zz_smooth = torch.linspace(0.02, zh_max, 200, device=device)

    def branch(T, y):
        m = torch.isfinite(T) & torch.isfinite(y) & (T > 0)
        Tg, yg = T[m], y[m]
        order = torch.argsort(Tg)
        Tg, yg = Tg[order], yg[order]
        dup = torch.cat([torch.tensor([True], device=device),
                         torch.diff(Tg) > 1e-9])
        return Tg[dup], yg[dup]

    L4_0 = None

    def losses(use_r):
        nonlocal L4_0
        o = model.observables_mu0(zh_grid)
        Tg, sg = branch(o["T"], o["s_over_T3"])
        _, cg = branch(o["T"], o["chi2B"])
        L_s = (((_interp(Tg, sg, D["T_s"]) - D["y_s"]) / D["sig_s"]) ** 2).mean()
        L_c = (((_interp(Tg, cg, D["T_c"]) - D["y_c"]) / D["sig_c"]) ** 2).mean()
        if chi4_scale:
            t4, _, c4 = model.susceptibilities_mu0(zh_grid)
            t4, c4 = branch(t4, c4)
            L4 = (((_interp(t4, c4, D["T_4"]) - D["y_4"]) / D["sig_4"]) ** 2).mean()
            if L4_0 is None:
                L4_0 = max(float(L4.detach()), 1e-12)
            L_c = L_c + chi4_scale * L4 / L4_0
        L_r = torch.zeros((), device=device)
        if use_r:
            nB, Tr, _ = model.nB_over_T3(zh_grid, muhat=1.0)
            Tn, rn = branch(Tr, nB)
            if "sig_r_cond" in D:
                delta_model = _interp(Tn, rn, D["T_r"]) - \
                    _interp(Tg, cg, D["T_r"])
                delta_data = D["y_r"] - D["y_r_chi2"]
                L_r = (((delta_model - delta_data) /
                        D["sig_r_cond"]) ** 2).mean()
            else:
                L_r = (((_interp(Tn, rn, D["T_r"]) - D["y_r"]) /
                        D["sig_r"]) ** 2).mean()
        L_phi = torch.relu(-model.phi_prime_sq(zz_smooth)).mean()
        Ag = a_net(zh_grid.unsqueeze(-1)).squeeze(-1)
        Fg = torch.log(f_net(zh_grid.unsqueeze(-1)).squeeze(-1))
        L_reg = ((Ag[2:] - 2 * Ag[1:-1] + Ag[:-2]) ** 2).mean() \
              + ((Fg[2:] - 2 * Fg[1:-1] + Fg[:-2]) ** 2).mean()
        return L_s, L_c, L_r, L_reg, L_phi

    params = list({id(p): p for p in list(a_net.parameters()) + list(f_net.parameters())}.values()) + [model.G]
    ema = {k: v.detach().clone() for k, v in model.state_dict().items()}

    def ema_eval(use_r, w_r=0.0, Lr0=1.0):
        raw = {k: v.detach().clone() for k, v in model.state_dict().items()}
        model.load_state_dict(ema)
        L_s, L_c, L_r, L_reg, L_phi = losses(use_r)
        tot = L_s + L_c + w_reg * L_reg + w_phi * L_phi
        if use_r:
            tot = tot + w_r * L_r / Lr0
        model.load_state_dict(raw)
        return [float(v.detach()) for v in (tot, L_s, L_c, L_r)]

    hist = []

    def run(n_epochs, lr0, phase):
        opt = torch.optim.Adam(params, lr=lr0)
        best, best_state, Lr0 = float("inf"), None, None
        for ep in range(n_epochs):
            model.train()
            opt.zero_grad(set_to_none=True)
            use_r = (phase == 2)
            L_s, L_c, L_r, L_reg, L_phi = losses(use_r)
            tot = L_s + L_c + w_reg * L_reg + w_phi * L_phi
            w_r = 0.0
            if phase == 2:
                if Lr0 is None:
                    Lr0 = max(float(L_r.detach()), 1e-12)
                w_r = rho_scale * min(1.0, (ep + 1) / max(1.0, rho_warmup * n_epochs))
                tot = tot + w_r * L_r / Lr0
            cur = float(tot.detach())
            if not math.isfinite(cur):
                opt.zero_grad(set_to_none=True)
                continue
            tot.backward()
            torch.nn.utils.clip_grad_norm_(params, 1.0)
            opt.step()
            model.clamp_G()
            frac = ep / max(n_epochs - 1, 1)
            for g in opt.param_groups:
                g["lr"] = lr_min + 0.5 * (lr0 - lr_min) * (1.0 + math.cos(math.pi * frac))
            with torch.no_grad():
                msd = model.state_dict()
                for k, v in ema.items():
                    v.mul_(ema_decay).add_(msd[k], alpha=1.0 - ema_decay)
            if ep % eval_every == 0 or ep == n_epochs - 1:
                # Compare checkpoints with the same fully ramped objective.
                e = ema_eval(use_r, rho_scale if use_r else 0.0, Lr0 or 1.0)
                if e[0] < best:
                    best, best_state = e[0], {k: v.clone() for k, v in ema.items()}
                hist.append(dict(phase=phase, epoch=ep, total_ema=e[0],
                                 L_s_ema=e[1], L_c_ema=e[2], L_r_ema=e[3],
                                 total_raw=cur, L_s_raw=float(L_s.detach()),
                                 L_c_raw=float(L_c.detach()),
                                 L_r_raw=float(L_r.detach()), w_r=w_r,
                                 lr=opt.param_groups[0]["lr"],
                                 G=float(model.G.detach())))
                if verbose and (ep % (eval_every * 40) == 0 or ep == n_epochs - 1):
                    print("  [ph%d] ep %5d ema=%.4e (s=%.3e c=%.3e r=%.3e) "
                          "lr=%.2e G=%.4f"
                          % (phase, ep, e[0], e[1], e[2], e[3],
                             opt.param_groups[0]["lr"], float(model.G.detach())),
                          flush=True)
        if best_state is not None:
            model.load_state_dict(best_state)
            for k, v in model.state_dict().items():
                ema[k] = v.detach().clone()
        return best

    if verbose:
        print("=== phase 1: mu=0 (s/T^3 + chi_2^B) ===", flush=True)
    b1 = run(phase1, lr, 1)
    state_mu0 = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
    b2 = float("nan")
    if phase2:
        if verbose:
            print("=== phase 2: + n_B/T^3 at mu_B/T = 1 ===", flush=True)
        b2 = run(phase2, lr2, 2)

    res = dict(model=model, history=hist, state_mu0=state_mu0,
               meta=dict(method="mu=0 + n_B/T^3(mu_B/T=1)",
                         warm_start="CH Table1 Nf=2 analytic",
                         pretrain_loss=pt, best_phase1=b1, best_phase2=b2,
                         rho_scale=rho_scale, rho_warmup=rho_warmup,
                         hrg_frac=hrg_frac, no_hrg=no_hrg,
                         controlled_hrg=controlled_hrg, taylor_order=taylor_order,
                         chi4_scale=chi4_scale, closure_f=closure_f, f0=f0,
                         shared_initial_checkpoint=initial_state is not None,
                         w_reg=w_reg, w_phi=w_phi, n_zh=n_zh, n_int=n_int,
                         hidden=hidden, depth=depth, data_seed=data_seed,
                         target_tag=target_tag,
                         A_parameterization="-z sigmoid(n_A(z))",
                         wall=time.time() - t0))
    if verbose:
        print("best: phase1 %.4e  phase2 %.4e (%.0fs)" % (b1, b2, time.time() - t0),
              flush=True)
    return res


def save(res, out_dir=RESULTS):
    import copy
    os.makedirs(out_dir, exist_ok=True)
    z = torch.linspace(1e-4, 20.0, 4000)
    meta = {k: v for k, v in res["meta"].items()
            if isinstance(v, (int, float, str, type(None)))}
    A, f, G = res["model"].export_functions(z)
    np.savez(os.path.join(out_dir, "Nf211_A_f.npz"), z=z.numpy(), A=A, f=f, G=G,
             **meta)
    m0 = copy.deepcopy(res["model"])
    m0.load_state_dict(res["state_mu0"])
    A, f, G = m0.export_functions(z)
    np.savez(os.path.join(out_dir, "Nf211_A_f_mu0only.npz"), z=z.numpy(), A=A,
             f=f, G=G, **meta)
    json.dump(dict(meta=res["meta"], history=res["history"]),
              open(os.path.join(out_dir, "Nf211_history.json"), "w"), indent=1)
    return os.path.join(out_dir, "Nf211_A_f.npz")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--phase1", type=int, default=6000)
    ap.add_argument("--phase2", type=int, default=3000)
    ap.add_argument("--seeds", type=int, default=3)
    ap.add_argument("--hidden", type=int, default=32)
    ap.add_argument("--depth", type=int, default=3)
    ap.add_argument("--device", default=None)
    a = ap.parse_args()
    dev = a.device or ("cuda" if torch.cuda.is_available() else "cpu")
    print("device:", dev, flush=True)

    winner, winner_seed, wscore = None, None, float("inf")
    for seed in range(a.seeds):
        print("=== run seed %d ===" % seed, flush=True)
        res = train(phase1=a.phase1, phase2=a.phase2, device=dev, seed=seed,
                    hidden=a.hidden, depth=a.depth)
        score = res["meta"]["best_phase2"] if a.phase2 else res["meta"]["best_phase1"]
        print("seed %d: best phase2 %.4e" % (seed, score), flush=True)
        if score < wscore:
            winner, winner_seed, wscore = res, seed, score
    print("winner: seed %d (%.4e)" % (winner_seed, wscore))
    winner["meta"]["seed"] = winner_seed
    winner["meta"]["n_seeds"] = a.seeds
    print("saved:", save(winner), flush=True)
    print("now run: python3 code/plot_nf211.py", flush=True)


if __name__ == "__main__":
    main()
