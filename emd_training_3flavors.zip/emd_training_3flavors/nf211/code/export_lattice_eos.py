#!/usr/bin/env python3
"""Regenerate the Nf=2+1+1 LQCD EOS CSV from the saved publication table."""
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent
source = HERE / "data/borsanyi2025_tab.tex"
target = HERE / "data/Nf211_lattice_s.csv"


def main():
    rows = []
    for line in source.read_text().splitlines():
        match = re.match(r"\s*(\d+)\s*&", line)
        if not match:
            continue
        cells = line.split("&")
        if len(cells) < 5:
            continue
        values = []
        for cell in cells[1:5]:
            value = re.match(r"(-?\d+\.\d+)\((\d+)\)",
                             cell.replace("\\quad", "").replace("\\", "").strip())
            if value is None:
                break
            # Parenthesized uncertainties refer to the final quoted digits:
            # 0.433(53) means 0.433 +/- 0.053, while 2.41(25) means
            # 2.41 +/- 0.25.  Preserve the decimal precision of the centre.
            decimals = len(value[1].split(".", 1)[1])
            error = int(value[2]) * 10.0 ** (-decimals)
            values.extend((float(value[1]), error))
        if len(values) == 8:
            p, dp, s, ds, e, de, trace, dtrace = values
            rows.append((float(match[1])/1000, s, ds, p, dp, e, de,
                         trace, dtrace))
    if len(rows) != 36:
        raise ValueError(f"Expected 36 published EOS rows, found {len(rows)}")
    with target.open("w") as output:
        output.write("T,s_over_T3,ds_over_T3,p_over_T4,dp_over_T4,"
                     "e_over_T4,de_over_T4,I_over_T4,dI_over_T4\n")
        output.write("# Borsanyi et al. 2025, arXiv:2502.10267, Table 1 "
                     "(4stout Nf=2+1+1, mu=0)\n")
        for row in rows:
            output.write(("%.6f," + ",".join("%.8e" for _ in row[1:]) + "\n") % row)
    print(f"Saved {len(rows)} LQCD EOS rows to {target}")


if __name__ == "__main__":
    main()
